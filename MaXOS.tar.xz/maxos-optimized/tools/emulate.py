#!/usr/bin/env python3
"""tools/emulate.py -- прогнать ядро MaXOS в эмуляторе (unicorn) без QEMU.

Зачем: в песочнице нет ни qemu, ни даже gcc, а проверить ядро хочется по
настоящему -- не «на глаз», а чтобы оно само нарисовало себе рабочий стол.

Что делает стенд:
  * маппит память и framebuffer, кладёт kernel.bin на 0x100000;
  * пишет в 0x30400 тот самый VBE boot info, который оставил бы stage2;
  * эмулирует порты: UART (ловим лог ядра), PIC, PIT, CMOS/RTC и
    контроллер 8042 (клавиатура + PS/2 мышь: command byte, 0xA8, 0xD4,
    ACK 0xFA, handshake Intellimouse);
  * вручную инжектит IRQ0 (тик), IRQ1 (клавиатура) и IRQ12 (мышь), строя
    на стеке кадр прерывания в том порядке, в котором его снимает iretq;
  * в нужные моменты «двигает мышь», нажимает клавиши и снимает
    framebuffer в PNG.

    python3 tools/emulate.py --ticks 1850 --ins 12000000

Ограничение: unicorn не эмулирует HLT (считает его nop), поэтому idle-задача
крутится вхолостую и в мониторе выглядит загруженной. На железе/QEMU она
честно спит.
"""
import argparse
import os
import struct
import sys
import time

from unicorn import *
from unicorn.x86_const import *

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

RAM_SIZE  = 96 * 1024 * 1024
FB_BASE   = 0xFD000000
FB_SIZE   = 4 * 1024 * 1024
VBE_INFO  = 0x30400
KERN_BASE = 0x100000

WIDTH, HEIGHT, BPP = 1024, 768, 32
VEC_TIMER, VEC_KBD, VEC_MOUSE = 32, 33, 44


# ---------------------------------------------------------------------------
#  ELF: адреса статических символов (idt, sys_ticks, ...)
# ---------------------------------------------------------------------------
def elf_symbols(path):
    d = open(path, "rb").read()
    (e_shoff,) = struct.unpack_from("<Q", d, 0x28)
    (e_shentsize,) = struct.unpack_from("<H", d, 0x3A)
    (e_shnum,) = struct.unpack_from("<H", d, 0x3C)
    shs = [struct.unpack_from("<IIQQQQIIQQ", d, e_shoff + i * e_shentsize)
           for i in range(e_shnum)]
    out = {}
    for s in shs:
        if s[1] != 2:            # SHT_SYMTAB
            continue
        strtab = shs[s[6]][4]
        entsz = s[9] or 24
        for i in range(s[5] // entsz):
            off = s[4] + i * entsz
            st_name, st_info, _o, _shndx, st_value, _sz = \
                struct.unpack_from("<IBBHQQ", d, off)
            nm = d[strtab + st_name:d.index(b"\0", strtab + st_name)].decode()
            if nm:
                out[nm] = st_value
    return out


# ---------------------------------------------------------------------------
#  Клавиатура: scancode set 1
# ---------------------------------------------------------------------------
SCAN = {
    'a': 0x1E, 'b': 0x30, 'c': 0x2E, 'd': 0x20, 'e': 0x12, 'f': 0x21, 'g': 0x22,
    'h': 0x23, 'i': 0x17, 'j': 0x24, 'k': 0x25, 'l': 0x26, 'm': 0x32, 'n': 0x31,
    'o': 0x18, 'p': 0x19, 'q': 0x10, 'r': 0x13, 's': 0x1F, 't': 0x14, 'u': 0x16,
    'v': 0x2F, 'w': 0x11, 'x': 0x2D, 'y': 0x15, 'z': 0x2C,
    '1': 0x02, '2': 0x03, '3': 0x04, '4': 0x05, '5': 0x06, '6': 0x07, '7': 0x08,
    '8': 0x09, '9': 0x0A, '0': 0x0B,
    ' ': 0x39, '-': 0x0C, '=': 0x0D, '[': 0x1A, ']': 0x1B, ';': 0x27, "'": 0x28,
    '`': 0x29, '\\': 0x2B, ',': 0x33, '.': 0x34, '/': 0x35, '*': 0x37, '+': 0x4E,
    '\n': 0x1C, '\t': 0x0F, '\b': 0x0E,
}
SHIFTED = {'!': 0x02, '@': 0x03, '#': 0x04, '$': 0x05, '%': 0x06, '^': 0x07,
           '&': 0x08, '*': 0x09, '(': 0x0A, ')': 0x0B, '_': 0x0C, '+': 0x0D,
           ':': 0x27, '"': 0x28, '~': 0x29, '|': 0x2B, '<': 0x33, '>': 0x34,
           '?': 0x35}
FUNC = {'esc': 0x01, 'f1': 0x3B, 'f2': 0x3C, 'f3': 0x3D, 'f4': 0x3E, 'f5': 0x3F,
        'f6': 0x40, 'up': (0xE0, 0x48), 'down': (0xE0, 0x50),
        'left': (0xE0, 0x4B), 'right': (0xE0, 0x4D)}


def key_scancodes(tok):
    tok_l = tok.lower()
    if tok_l in FUNC:
        v = FUNC[tok_l]
        if isinstance(v, tuple):      # E0-префикс: make = E0 xx, break = E0 xx|80
            return [v[0], v[1], v[0], v[1] | 0x80]
        return [v, v | 0x80]
    if tok in SCAN:
        c = SCAN[tok]
        return [c, c | 0x80]
    if tok in SHIFTED:
        c = SHIFTED[tok]
        return [0x2A, c, c | 0x80, 0xAA]
    if tok.isalpha() and tok.isupper():
        c = SCAN[tok.lower()]
        return [0x2A, c, c | 0x80, 0xAA]
    raise SystemExit("unknown key token: %r" % tok)


# ---------------------------------------------------------------------------
class Machine(object):
    def __init__(self, kernel_bin, kernel_elf, verbose=True):
        self.uc = Uc(UC_ARCH_X86, UC_MODE_64)
        # В песочницах/контейнерах дефолтный TCG-буфер unicorn (сотни MiB
        # exec-памяти) не маппится: "Could not allocate dynamic translator
        # buffer". 16 MiB хватает с запасом, на скорость почти не влияет.
        try:
            self.uc.ctl_set_tcg_buffer_size(int(os.environ.get("UC_TCG_BUF", 16 * 1024 * 1024)))
        except UcError:
            pass
        self.verbose = verbose
        self.serial = []
        self.tick = 0          # гостевые тики (sys_ticks ядра)
        self.loop = 0
        self.halted = False

        # 8042: devq = байты устройств (скан-коды/пакеты мыши), которые ждут
        # инжекта IRQ; outq = то, что контроллер отдаёт по IN 0x60.
        self.devq = []
        self.outq = []
        self.pending = None       # 'cmd' | 'aux'
        self.expect_rate = False
        self.cmd_byte = 0x01
        self.aux_en = False

        # мышь
        self.mx, self.my = WIDTH // 2, HEIGHT // 2
        self.mbtn = 0

        uc = self.uc
        uc.mem_map(0, RAM_SIZE)
        uc.mem_map(FB_BASE, FB_SIZE)
        uc.mem_write(KERN_BASE, open(kernel_bin, "rb").read())

        info = struct.pack("<IIIIIIQBBBBBB",
                           0x31454256, 1, WIDTH, HEIGHT, BPP, WIDTH * 4,
                           FB_BASE, 16, 8, 0, 8, 8, 8)
        uc.mem_write(VBE_INFO, info)

        self.syms = elf_symbols(kernel_elf)
        for need in ("idt", "sys_ticks"):
            if need not in self.syms:
                raise SystemExit("no '%s' symbol in %s (собери с -g, без strip)"
                                 % (need, kernel_elf))
        self.idt = self.syms["idt"]
        self.sym_ticks = self.syms["sys_ticks"]

        uc.hook_add(UC_HOOK_INSN, self.hook_in, None, 1, 0, UC_X86_INS_IN)
        uc.hook_add(UC_HOOK_INSN, self.hook_out, None, 1, 0, UC_X86_INS_OUT)

        uc.reg_write(UC_X86_REG_RSP, 0x80000)   # временный стек от stage2
        uc.reg_write(UC_X86_REG_RBP, 0)
        uc.reg_write(UC_X86_REG_RIP, KERN_BASE)

        # RTC: 2026-10-09 15:42:07, четверг; binary, 24h
        self.rtc = {0: 7, 2: 42, 4: 15, 6: 4, 7: 9, 8: 10, 9: 26,
                    0x0A: 0x26, 0x0B: 0x06, 0x0C: 0x00, 0x0D: 0x80}
        self.cmos_sel = 0

    # ---- порты ----------------------------------------------------------
    def hook_in(self, uc, port, size, ud=None):
        if port in (0x3FD, 0x2FD):          # UART LSR: передатчик всегда свободен
            return 0x60
        if port == 0x3F8:
            return 0
        if port == 0x64:                    # статус 8042
            return 0x10 | (0x01 if self.outq else 0)
        if port == 0x60:
            return self.outq.pop(0) if self.outq else 0
        if port == 0x71:
            return self.rtc.get(self.cmos_sel & 0x7F, 0)
        return 0

    def hook_out(self, uc, port, size, value, ud=None):
        if port == 0x3F8:
            c = value & 0xFF
            self.serial.append(c)
            if self.verbose:
                if c == 0x0D:
                    pass
                elif c == 0x0A:
                    sys.stdout.write("\n")
                else:
                    sys.stdout.write(chr(c))
                sys.stdout.flush()
        elif port == 0x70:
            self.cmos_sel = value
        elif port == 0x64:
            self.port64(value)
        elif port == 0x60:
            self.port60(value)
        elif port in (0x604, 0xB004, 0x4004):
            if value in (0x2000, 0x3400):
                print("\n*** GUEST POWEROFF (port 0x%x <- 0x%x)" % (port, value))
                self.halted = True
                uc.emu_stop()
        elif port == 0x61 or port == 0x43 or port == 0x42 or port == 0x80:
            pass                            # speaker/PIT/io_wait -- принимаем молча
        elif port in (0x20, 0x21, 0xA0, 0xA1):
            pass                            # PIC
        # прочие порты игнорируем

    def port64(self, v):
        if v == 0x20:
            self.outq.append(self.cmd_byte)          # read command byte
        elif v == 0x60:
            self.pending = 'cmd'                     # write command byte
        elif v == 0xA8:
            self.aux_en = True                       # enable aux (мышь)
        elif v == 0xA7:
            self.aux_en = False
        elif v == 0xD4:
            self.pending = 'aux'                     # write to aux device
        elif v == 0xFE:
            print("\n*** GUEST REBOOT (kbd controller reset)")
            self.halted = True
            self.uc.emu_stop()

    def port60(self, v):
        if self.pending == 'cmd':
            self.cmd_byte = v
            self.pending = None
        elif self.pending == 'aux':
            self.pending = None
            self.aux_cmd(v)
        # иначе -- запись в клавиатуру, нам не интересна

    def aux_cmd(self, v):
        if self.expect_rate:                  # байт sample rate после 0xF3
            self.expect_rate = False
            self.outq.append(0xFA)
        elif v == 0xF3:                       # set sample rate: ACK + ждём байт
            self.outq.append(0xFA)
            self.expect_rate = True
        elif v == 0xF2:                       # get device id
            self.outq.append(0xFA)
            self.outq.append(0x00)            # стандартная мышь, 3-байтные пакеты
        else:                                 # F6/F4/F5/E6..: просто ACK
            self.outq.append(0xFA)

    # ---- прерывания -----------------------------------------------------
    def idt_handler(self, vector):
        raw = bytes(self.uc.mem_read(self.idt + vector * 16, 16))
        lo, sel, ist, attr, mid, hi, _ = struct.unpack("<HHBBHII", raw)
        if not (attr & 0x80):
            return None
        return lo | (mid << 16) | (hi << 32)

    def inject(self, vector):
        uc = self.uc
        rfl = uc.reg_read(UC_X86_REG_RFLAGS)
        if not (rfl & 0x200):
            return False                      # IF=0 -- как на железе, откладываем
        handler = self.idt_handler(vector)
        if handler is None:
            return False
        rsp = uc.reg_read(UC_X86_REG_RSP)
        rip = uc.reg_read(UC_X86_REG_RIP)
        # Кадр ring0->ring0: [rsp+0]=RIP, +8=CS, +16=RFLAGS, +24=RSP, +32=SS
        frame = struct.pack("<QQQQQ", rip, 0x08, rfl, rsp, 0x10)
        uc.mem_write(rsp - 40, frame)
        uc.reg_write(UC_X86_REG_RSP, rsp - 40)
        uc.reg_write(UC_X86_REG_RFLAGS, rfl & ~0x200)
        uc.reg_write(UC_X86_REG_RIP, handler)
        return True

    # ---- ввод -----------------------------------------------------------
    def press(self, token):
        for b in key_scancodes(token):
            self.devq.append((b, VEC_KBD))

    def type_text(self, text):
        for ch in text:
            self.press(ch)

    def press_combo(self, mods, key):
        MAKE = {'alt': 0x38, 'ctrl': 0x1D, 'shift': 0x2A}
        for md in mods:
            self.devq.append((MAKE[md], VEC_KBD))
        for b in key_scancodes(key):
            self.devq.append((b, VEC_KBD))
        for md in reversed(mods):
            self.devq.append((MAKE[md] | 0x80, VEC_KBD))

    def mouse_packet(self, dx, dys, buttons):
        """dys -- в экранных координатах (вниз положительно)."""
        dy = -dys
        b0 = 0x08 | (0x10 if dx < 0 else 0) | (0x20 if dy < 0 else 0) | (buttons & 7)
        for b in (b0, dx & 0xFF, dy & 0xFF):
            self.devq.append((b, VEC_MOUSE))
        self.mbtn = buttons

    def mouse_move_to(self, x, y, steps=8, buttons=0):
        x = max(0, min(WIDTH - 1, x)); y = max(0, min(HEIGHT - 1, y))
        dx, dy = x - self.mx, y - self.my
        n = max(steps, 1)
        for i in range(n):
            sx = dx * (i + 1) // n - dx * i // n
            sy = dy * (i + 1) // n - dy * i // n
            self.mouse_packet(sx, sy, buttons)
        self.mx, self.my = x, y

    def mouse_click(self, x, y, button=1):
        self.mouse_move_to(x, y)
        self.mouse_packet(0, 0, button)
        self.mouse_packet(0, 0, 0)

    def mouse_drag(self, x0, y0, x1, y1):
        self.mouse_move_to(x0, y0)
        self.mouse_packet(0, 0, 1)
        self.mouse_move_to(x1, y1, steps=10, buttons=1)
        self.mouse_packet(0, 0, 0)

    def pump_dev(self, budget=1):
        sent = 0
        while self.devq and sent < budget:
            b, vec = self.devq[0]
            if not self.inject(vec):
                break
            self.devq.pop(0)
            self.outq.append(b)
            sent += 1
        return sent

    # ---- запуск ---------------------------------------------------------
    def guest_ticks(self):
        return struct.unpack("<Q", bytes(self.uc.mem_read(self.sym_ticks, 8)))[0]

    def run_ticks(self, ticks, ins_per_tick, on_tick=None):
        uc = self.uc
        t0 = time.time()
        for i in range(ticks):
            if self.halted:
                print("-- guest halted at guest tick %d" % self.tick)
                break
            self.loop = i
            self.pump_dev()
            self.inject(VEC_TIMER)
            uc.emu_start(uc.reg_read(UC_X86_REG_RIP), 0, count=ins_per_tick)
            self.tick = self.guest_ticks()
            if on_tick:
                on_tick(self, self.tick)
        print("-- emulated %d ticks (%.1f s guest time), %.1f s wall"
              % (self.tick, self.tick / 100.0, time.time() - t0))

    def screenshot(self, path):
        from PIL import Image
        raw = bytes(self.uc.mem_read(FB_BASE, WIDTH * HEIGHT * 4))
        im = Image.frombytes("RGB", (WIDTH, HEIGHT), raw, "raw", "BGRX")
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        im.save(path)
        print("-- screenshot -> %s" % path)

    def serial_text(self):
        return "".join(chr(c) for c in self.serial)


# ---------------------------------------------------------------------------
def build_script(name, out):
    """События по ГОСТЕВЫМ тикам: [тик, подпись, функция, выполнено?]."""
    ev = []

    def at(t, fn, label=""):
        ev.append([t, label, fn, False])

    def shot(n):
        return lambda m: m.screenshot(os.path.join(out, n))

    if name == "demo":
        # Хореография подобрана так, чтобы точки кликов не накрывались
        # другими окнами: каждое действие проверено по z-порядку.
        at(120, shot("01_boot.png"), "boot")
        at(150, lambda m: m.type_text("neofetch\n"), "type neofetch")
        at(240, shot("02_terminal.png"))
        at(270, lambda m: m.press("f4"), "launch bounce")
        at(310, lambda m: m.mouse_drag(650, 311, 250, 430), "drag bounce by title")
        at(400, shot("03_drag.png"))
        at(430, lambda m: m.press("f5"), "launch calc")
        at(470, lambda m: m.type_text("12*34=\n"), "calc math (keyboard)")
        at(560, shot("04_calc_kbd.png"))
        at(600, lambda m: m.mouse_click(825, 181), "click Clear")
        at(645, lambda m: m.mouse_click(884, 234), "click 9")
        at(690, lambda m: m.mouse_click(943, 234), "click *")
        at(735, lambda m: m.mouse_click(884, 340), "click 3")
        at(780, lambda m: m.mouse_click(884, 393), "click =")
        at(840, shot("05_calc_mouse.png"))
        at(880, lambda m: m.mouse_click(204, 430), "click close light -> genie")
        at(960, shot("06_genie.png"))
        at(1060, shot("07_closed.png"))
        at(1090, lambda m: m.press("esc"), "shutdown dialog")
        at(1190, shot("08_shutdown.png"))
        at(1230, lambda m: m.mouse_click(365, 410), "click Cancel")
        at(1320, shot("09_after_cancel.png"))
        at(1350, lambda m: m.press_combo(['alt'], 'b'), "hog stress")
        at(1450, lambda m: m.mouse_move_to(700, 300, steps=6), "move during hog")
        at(1520, shot("10_hog.png"))
        at(1660, shot("11_final.png"))
        at(1560, lambda m: m.press("f1"), "launch about")
        at(1600, shot("12_about.png"))
    if name == "stats":
        at(250, lambda m: m.type_text("gfx\n"), "gfx stats")
        at(330, lambda m: m.type_text("gfx\n"), "gfx stats 2")
    return ev


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bin", default=os.path.join(ROOT, "build/kernel.bin"))
    ap.add_argument("--elf", default=os.path.join(ROOT, "build/kernel.elf"))
    ap.add_argument("--ticks", type=int, default=1950)
    ap.add_argument("--ins", type=int, default=12000000, help="инструкций на тик")
    ap.add_argument("--script", default="demo")
    ap.add_argument("--out", default=os.path.join(ROOT, "build/shots"))
    args = ap.parse_args()

    m = Machine(args.bin, args.elf)
    script = build_script(args.script, args.out)

    def on_tick(mach, gt):
        for ev in script:
            if not ev[3] and gt >= ev[0]:
                ev[3] = True
                print("[gt=%d] %s" % (gt, ev[1]))
                ev[2](mach)

    print("== booting MaXOS in unicorn (idt @ 0x%x) ==" % m.idt)
    m.run_ticks(args.ticks, args.ins, on_tick=on_tick)
    print("\n== end of run, %d serial bytes, %d device bytes pending =="
          % (len(m.serial), len(m.devq)))

    # ---- debug: dump guest buffers (symbol -> PNG) ----
    import struct as _st
    from PIL import Image as _Im
    syms = m.syms
    mu = m.uc
    def dump_surf_ptr(sym_ptr, w, h, path):
        p = syms.get(sym_ptr)
        if p is None:
            print("no symbol", sym_ptr); return
        ptr = _st.unpack("<Q", mu.mem_read(p, 8))[0]
        if not ptr:
            print("null", sym_ptr); return
        raw = bytes(mu.mem_read(ptr, w * h * 4))
        _Im.frombytes("RGBX", (w, h), raw).convert("RGB").save(path)
        print("dumped", sym_ptr, "->", path)
    st = syms.get("sys_ticks")
    print("sys_ticks =", int.from_bytes(bytes(mu.mem_read(st, 8)), "little"))
    for nm in ("canvas", "wallpaper", "icon_ss", "icon_px", "icon_al", "icon_have"):
        p = syms.get(nm)
        if p is None:
            print("nosym", nm); continue
        raw = bytes(mu.mem_read(p, 64))
        import struct as _s2
        vals = _s2.unpack("<8Q", raw)
        print("sym", nm, [hex(v) for v in vals[:6]])
    crops = os.path.join(ROOT, "build", "crops")
    dump_surf_ptr("icon_ss", 320, 320, os.path.join(crops, "g_icon_ss.png"))
    ip, ia = syms.get("icon_px"), syms.get("icon_al")
    if ip is not None and ia is not None:
        ptr = _st.unpack("<Q", mu.mem_read(ip, 8))[0]
        aptr = _st.unpack("<Q", mu.mem_read(ia, 8))[0]
        if ptr and aptr:
            raw = bytes(mu.mem_read(ptr, 80 * 80 * 4))
            araw = bytes(mu.mem_read(aptr, 80 * 80))
            _Im.frombytes("RGBX", (80, 80), raw).convert("RGB").save(
                os.path.join(crops, "g_icon_px.png"))
            _Im.frombytes("L", (80, 80), araw).save(
                os.path.join(crops, "g_icon_al.png"))
            print("dumped icon_px/al[0]")


if __name__ == "__main__":
    main()
