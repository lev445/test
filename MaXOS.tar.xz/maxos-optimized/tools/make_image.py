#!/usr/bin/env python3
"""tools/make_image.py -- сборка загрузочного образа диска.

    python3 tools/make_image.py OUT.img SIZE_MB KERNEL_LBA boot.bin stage2.bin kernel.bin

Раскладка (ровно так, как её читают boot.asm и stage2.asm):
    LBA 0        (offset 0x000000) : stage1, MBR, 512 байт, сигнатура 0xAA55
    LBA 1        (offset 0x000200) : stage2, до 16 секторов
    LBA 2048     (offset 0x100000) : kernel.bin, ровно 512 секторов (256 KiB)
"""
import struct
import sys
import os

SECT = 512


def fail(msg):
    print("make_image: " + msg)
    sys.exit(1)


def check_dap(blob, prefix, name, lba_bytes, lba_kind):
    """DAP читается BIOS-ом как ровно 16 байт: size, reserved, count,
    off, seg и QWORD LBA. Исторически тут была дыра: dw+dd вместо dq
    давали 14-байтную структуру, и старшие байты LBA дочитывались из
    соседних данных (boot_drive=0x80) -> LBA=0x0080000000000001 -> AH=01.
    Проверяем, что пакет на месте, целиком и с вменяемой LBA."""
    i = blob.find(prefix)
    if i < 0:
        fail("%s: DAP not found by signature %s" % (name, prefix.hex()))
    if i + 16 > len(blob) or (name == "stage1" and i + 16 > 446):
        fail("%s: DAP at %d does not fit (16 bytes required)" % (name, i))
    if lba_kind == "q":
        lba = struct.unpack_from("<Q", blob, i + 8)[0]
    else:
        lba = struct.unpack_from("<I", blob, i + 8)[0]
        if struct.unpack_from("<I", blob, i + 12)[0] != 0:
            fail("%s: high dword of LBA is not zero" % name)
    if lba != lba_bytes:
        fail("%s: DAP LBA = %d, expected %d (поле LBA собрано криво?)"
             % (name, lba, lba_bytes))
    cnt = struct.unpack_from("<H", blob, i + 2)[0]
    if cnt == 0:
        fail("%s: DAP sector count is 0" % name)
    print("  %-7s : DAP ok (16 bytes, count=%u, lba=%d, buf=%04x:%04x)"
          % (name, cnt, lba,
             struct.unpack_from("<H", blob, i + 6)[0],
             struct.unpack_from("<H", blob, i + 4)[0]))


def main():
    if len(sys.argv) != 7:
        print(__doc__)
        return 2
    out, size_mb, kernel_lba, boot, stage2, kernel = sys.argv[1:7]
    size_mb = int(size_mb)
    kernel_lba = int(kernel_lba)

    total = size_mb * 1024 * 1024
    if kernel_lba * SECT + os.path.getsize(kernel) > total:
        fail("image too small: %d MiB" % size_mb)

    img = bytearray(total)

    b = open(boot, "rb").read()
    if len(b) != SECT:
        fail("stage1 must be exactly 512 bytes, got %d" % len(b))
    if b[510:512] != b"\x55\xAA":
        fail("stage1 has no 0xAA55 boot signature")
    img[0:SECT] = b
    # DAP stage1: size=16, rsv=0, count=16, off=0x8000, seg=0x0000, lba(q)=1
    check_dap(b, bytes([0x10, 0x00, 0x10, 0x00, 0x00, 0x80, 0x00, 0x00]),
              "stage1", 1, "q")

    s = open(stage2, "rb").read()
    if len(s) > 16 * SECT:
        fail("stage2 is %d bytes, stage1 loads only 16 sectors (%d)"
             % (len(s), 16 * SECT))
    img[SECT:SECT + len(s)] = s
    # DAP stage2: size=16, rsv=0, count=64, off=0, seg=0x4000, lba(dd)=KERNEL_LBA
    check_dap(s, bytes([0x10, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00, 0x40]),
              "stage2", kernel_lba, "d")

    k = open(kernel, "rb").read()
    off = kernel_lba * SECT
    img[off:off + len(k)] = k

    with open(out, "wb") as f:
        f.write(img)

    print("make_image: %s" % out)
    print("  size      : %d MiB" % size_mb)
    print("  stage1    : LBA 0,      %5d bytes" % len(b))
    print("  stage2    : LBA 1,      %5d bytes (limit 8192)" % len(s))
    print("  kernel    : LBA %-5d %7d bytes at offset 0x%x" % (kernel_lba, len(k), off))
    return 0


if __name__ == "__main__":
    sys.exit(main())
