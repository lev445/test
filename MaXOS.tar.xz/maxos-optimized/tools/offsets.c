/* Хост-утилита: печатает смещения полей структур ядра (для отладочных дампов). */
#include <stdio.h>
#include "../kernel/types.h"
#include "../kernel/gfx.h"
#include "../kernel/input.h"
#include "../kernel/gui.h"
#include "../kernel/sched.h"
#define P(s,f) printf("%s.%s %d\n", #s, #f, (int)__builtin_offsetof(s,f))
int main(void){
    printf("task_t.size %zu\n", sizeof(task_t));
    P(task_t,ctx); P(task_t,stack); P(task_t,stack_size); P(task_t,name);
    P(task_t,state); P(task_t,wake_tick); P(task_t,cpu_ticks); P(task_t,cpu_last);
    P(task_t,cpu_pct); P(task_t,switches); P(task_t,id);
    printf("win_t.size %zu\n", sizeof(win_t));
    P(win_t,used); P(win_t,id); P(win_t,title); P(win_t,x); P(win_t,y); P(win_t,w);
    P(win_t,h); P(win_t,cw); P(win_t,ch); P(win_t,buf); P(win_t,surf); P(win_t,style);
    P(win_t,app); P(win_t,focused); P(win_t,alive); P(win_t,repaint); P(win_t,task_done);
    P(win_t,period); P(win_t,paint); P(win_t,on_key); P(win_t,udata);
    return 0;
}
