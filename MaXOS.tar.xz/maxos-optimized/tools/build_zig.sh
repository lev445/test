#!/usr/bin/env bash
# tools/build_zig.sh -- собрать ядро без gcc/ld/objcopy, одним zig cc.
#
#   python3 -m pip install ziglang
#   ./tools/build_zig.sh            -> build/kernel.bin
#
# nasm для stage1/stage2 всё равно нужен (или готовый образ), а вот само
# ядро zig собирает честно: clang + lld, тот же linker.ld.
set -euo pipefail
cd "$(dirname "$0")/.."

ZIG="${ZIG:-python3 -m ziglang}"
OUT=build
mkdir -p "$OUT/kernel/arch"

CFLAGS="-target x86_64-freestanding-none -std=gnu11 -O2 -g \
 -ffreestanding -fno-builtin -fno-stack-protector -fno-sanitize=undefined \
 -fno-asynchronous-unwind-tables -fno-strict-aliasing \
 -fno-delete-null-pointer-checks -fwrapv -fno-pic \
 -mno-red-zone -mno-sse -mno-mmx -mno-80387 -Ikernel \
 -Wall -Wextra -Wno-unused-parameter -Wno-unused-function"

OBJS=()
for f in kernel/arch/*.S; do
    o="$OUT/${f%.S}.o"
    echo "  CC  $f"
    $ZIG cc $CFLAGS -c "$f" -o "$o"
    OBJS+=("$o")
done
for f in kernel/*.c; do
    o="$OUT/${f%.c}.o"
    extra=""
    [ "$f" = "kernel/gfx.c" ] && extra="-msse2"   # зона SSE2 (см. Makefile)
    echo "  CC  $f $extra"
    $ZIG cc $CFLAGS $extra -c "$f" -o "$o"
    OBJS+=("$o")
done

echo "  LD  $OUT/kernel.elf"
$ZIG cc $CFLAGS -nostdlib -T linker.ld -Wl,-z,max-page-size=0x1000 \
        -Wl,--no-dynamic-linker \
        -o "$OUT/kernel.elf" "${OBJS[@]}"

echo "  BIN $OUT/kernel.bin"
$ZIG objcopy -O binary "$OUT/kernel.elf" "$OUT/kernel.raw"
python3 tools/pack_kernel.py "$OUT/kernel.elf" "$OUT/kernel.raw" "$OUT/kernel.bin" 512
