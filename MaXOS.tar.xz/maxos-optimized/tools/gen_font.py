#!/usr/bin/env python3
# MaXOS: генератор растровых шрифтов для ядра.
#
#   python3 tools/gen_font.py     -> kernel/font.c, docs/font_proof.png
#
import os
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "kernel", "font.c")
PROOF = os.path.join(HERE, "..", "docs", "font_proof.png")

# Пути к стандартным векторным шрифтам в Arch Linux / большинстве дистрибутивов
SYSTEM_FONTS = [
    "/usr/share/fonts/TTF/DejaVuSans.ttf",
    "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/noto/NotoSans-Regular.ttf",
    "/usr/share/fonts/noto/NotoSans-Bold.ttf",
    "/usr/share/fonts/liberation/LiberationSans-Regular.ttf",
    "/usr/share/fonts/liberation/LiberationSans-Bold.ttf",
]

CHARS = [chr(c) for c in range(32, 127)]
IDX = {c: i for i, c in enumerate(CHARS)}
N = len(CHARS)

# имя, кегль, высота ячейки, advance (0 = пропорц.), макс. ширина глифа, bpp
# TITLE: bpp изменён на 4. Для крупного шрифта 2 бита дают ужасные "лесенки". 
# 4 бита (16 градаций) дают идеальное сглаживание, а вес для заголовка окна ничтожен.
FACES = [
    ("MONO",  14, 16, 8,  8, 4),
    ("UI",    16, 20, 0, 16, 4), # Чуть больше высоты для хвостиков букв (g, p, y)
    ("TITLE", 26, 32, 0, 32, 4), # Крупный, жирный (если найдётся Bold), гладкий
]

SAMPLE = "MaXOS Aqua 0.1 Handgofy W@#$% 0123456789"


def get_system_font(name, size):
    """Ищет подходящий векторный шрифт в системе и загружает его."""
    is_title = (name == "TITLE")
    
    for font_path in SYSTEM_FONTS:
        if os.path.exists(font_path):
            # Для титлбара стараемся взять Bold версию для сочности
            if is_title and "Bold" in font_path:
                try:
                    return ImageFont.truetype(font_path, size)
                except Exception:
                    pass
            elif not is_title and "Bold" not in font_path:
                try:
                    return ImageFont.truetype(font_path, size)
                except Exception:
                    pass
                    
    # Fallback на последний попавшийся или дефолтный
    for font_path in SYSTEM_FONTS:
        if os.path.exists(font_path):
            try:
                return ImageFont.truetype(font_path, size)
            except Exception:
                pass
                
    print(f"[WARN] Системные шрифты не найдены. Использую fallback PIL (будет мыльно).")
    print("       Установи ttf-dejavu или noto-fonts в своей Arch Linux.")
    return ImageFont.load_default()


def bake(name, size, h, mono_adv, maxw, bpp):
    # Основной шрифт
    f = get_system_font(name, size)
    # Шрифт для суперсэмплинга (в 4 раза больше для идеального сглаживания)
    f4 = get_system_font(name, size * 4)
    
    asc, desc = f.getmetrics()
    
    # Оптическое центрирование по заглавной букве (важно для титлбара!)
    bbox_caps = f.getbbox("H")
    cap_height = (bbox_caps[3] - bbox_caps[1]) if bbox_caps else asc
    baseline = (h - cap_height) // 2 + cap_height
    baseline = max(1, min(h - 2, baseline))

    probe = ImageDraw.Draw(Image.new("L", (1, 1)))
    cellw = mono_adv if mono_adv else maxw

    advs, cells, imgs = [], [], []
    for ch in CHARS:
        if mono_adv:
            adv = mono_adv
        else:
            try:
                adv = max(1, int(round(f.textlength(ch))))
            except AttributeError:
                bb = f.getbbox(ch)
                adv = max(1, int(round(bb[2] - bb[0]))) if bb else 1

        advs.append(adv)
        if ch == " " or adv == 0:
            cells.append(None)
            imgs.append(None)
            continue

        # 1. Рендерим в 4-кратном разрешении (векторный шрифт даёт идеальные кривые)
        bb4 = f4.getbbox(ch)
        if not bb4:
            cells.append(None)
            imgs.append(None)
            continue
            
        w4 = max(bb4[2] - bb4[0], 1)
        im4 = Image.new("L", (w4, 4 * h), 0)
        draw4 = ImageDraw.Draw(im4)
        draw4.text((-bb4[0], 4 * baseline), ch, font=f4, fill=255, anchor="ls")
        
        # 2. Сжимаем до целевого размера фильтром LANCZOS (лучший для уменьшения)
        # Это и есть "нормальный суперсэмплинг", который убирает алиасинг
        im = im4.resize((cellw, h), Image.Resampling.LANCZOS)
        w = cellw
        
        xoff = 0
        if mono_adv:
            bb = f.getbbox(ch)
            inkw = (bb[2] - bb[0]) if bb else 1
            xoff = max(0, (cellw - inkw) // 2)

        px = im.load()
        stride = (maxw * bpp + 7) // 8
        cell = bytearray(h * stride)
        for y in range(h):
            row = pack_row([0] * xoff + [px[x, y] for x in range(w)], bpp)
            cell[y * stride:y * stride + len(row)] = row
        cells.append(bytes(cell))
        
        full = Image.new("L", (cellw, h), 0)
        full.paste(im, (xoff, 0))
        imgs.append(full)

    stride = (maxw * bpp + 7) // 8
    fixed = []
    for c in cells:
        if c is None:
            fixed.append(bytes(h * stride))
        else:
            fixed.append(c)
    return advs, stride, fixed, imgs, baseline


def pack_row(row_cov, bpp):
    """row_cov: список coverage 0..255 слева направо -> байты, ppb пикселей на байт."""
    ppb = 8 // bpp
    out = bytearray()
    for i in range(0, len(row_cov), ppb):
        b = 0
        for k in range(ppb):
            v = row_cov[i + k] if i + k < len(row_cov) else 0
            shifted_v = v >> (8 - bpp)
            b |= shifted_v << (bpp * (ppb - 1 - k))
        out.append(b)
    return out


def main():
    src = ["/* font.c -- СГЕНЕРИРОВАН tools/gen_font.py, руками не править!",
           " * Растровые шрифты ядра MaXOS: coverage-глифы с градациями серого.",
           " * bpp=4: два пикселя на байт (старший nibble -- левый),",
           " * bpp=2: четыре пикселя на байт.",
           " * Глиф i (ASCII 32..126) лежит по смещению i*h*stride.",
           " */",
           '#include "font.h"', ""]
    metas = []
    proof = []
    
    for name, size, h, mono, maxw, bpp in FACES:
        advs, stride, bits, imgs, baseline = bake(name, size, h, mono, maxw, bpp)
        low = name.lower()
        src.append(f"/* ---- FONT_{name}: kegl={size} h={h} stride={stride} "
                   f"baseline={baseline} bpp={bpp} ---- */")
        src.append(f"static const u8 adv_{low}[{N}] = {{")
        for i in range(0, N, 19):
            src.append("    " + ",".join(str(a) for a in advs[i:i + 19]) + ",")
        src.append("};")
        blob = b"".join(bits)
        src.append(f"static const u8 bits_{low}[{len(blob)}] = {{")
        for i in range(0, len(blob), 24):
            src.append("    " + ",".join("0x%02x" % b for b in blob[i:i + 24]) + ",")
        src.append("};")
        src.append("")
        metas.append((name, h, stride, baseline, low, bpp))
        proof.append((name, h, advs, imgs))

    src.append(f"const font_t fonts[FONT_COUNT] = {{")
    for name, h, stride, baseline, low, bpp in metas:
        src.append(f"    {{ bits_{low}, adv_{low}, {h}, {stride}, {baseline}, {bpp} }},")
    src.append("};")

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as fh:
        fh.write("\n".join(src) + "\n")
    print(f"wrote {os.path.normpath(OUT):<28} {os.path.getsize(OUT):>7} bytes")

    # ---- proof sheet -------------------------------------------------
    sheets = []
    for name, h, advs, imgs in proof:
        w = sum(advs[IDX[c]] for c in SAMPLE) + 20
        im = Image.new("L", (w, h + 4), 36)
        x = 10
        for c in SAMPLE:
            g = imgs[IDX[c]]
            if g is not None:
                im.paste(255, (x, 2, x + g.width, 2 + g.height), g)
            x += advs[IDX[c]]
        sheets.append((name, im))
        
    W = max(im.width for _, im in sheets) + 20
    H = sum(im.height + 26 for _, im in sheets) + 10
    sheet = Image.new("RGB", (W, H), (246, 246, 250))
    d = ImageDraw.Draw(sheet)
    y = 8
    for name, im in sheets:
        d.text((10, y), f"FONT_{name}: {SAMPLE}", fill=(190, 40, 40))
        y += 20
        sheet.paste(im.convert("RGB"), (10, y))
        y += im.height + 6
        
    os.makedirs(os.path.dirname(PROOF), exist_ok=True)
    sheet.save(PROOF)
    print(f"wrote {os.path.normpath(PROOF)}")

if __name__ == "__main__":
    main()
