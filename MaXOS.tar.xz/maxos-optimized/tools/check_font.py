#!/usr/bin/env python3
# Проверка сгенерированного kernel/font.c: печатает глифы ASCII-артом.
#   python3 tools/check_font.py [имя_лица] [строка]
import re
import sys
import os

SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "kernel", "font.c")


def load():
    src = open(SRC).read()
    faces = {}
    for n, h, st, bl in re.findall(r"\{ bits_(\w+), adv_\w+, (\d+), (\d+), (\d+) \}", src):
        bm = re.search(r"static const u8 bits_%s\[\d+\] = \{(.*?)\n\};" % n, src, re.S)
        am = re.search(r"static const u8 adv_%s\[\d+\] = \{(.*?)\n\};" % n, src, re.S)
        blob = bytes(int(x, 16) for x in re.findall(r"0x([0-9a-f]{2})", bm.group(1)))
        adv = [int(x) for x in re.findall(r"\d+", am.group(1))]
        faces[n] = dict(h=int(h), stride=int(st), baseline=int(bl), bits=blob, adv=adv)
    return faces


def main():
    faces = load()
    want = sys.argv[1] if len(sys.argv) > 1 else None
    text = sys.argv[2] if len(sys.argv) > 2 else "MaXOS Aqua 0.1"
    for name, f in faces.items():
        if want and name != want:
            continue
        h, st = f["h"], f["stride"]
        print("=== FONT_%s  h=%d stride=%d baseline=%d  bytes=%d" %
              (name.upper(), h, st, f["baseline"], len(f["bits"])))
        rows = [""] * h
        for ch in text:
            i = ord(ch) - 32
            if not 0 <= i < 95:
                continue
            adv = f["adv"][i]
            for y in range(h):
                line = f["bits"][i * h * st + y * st: i * h * st + (y + 1) * st]
                px = "".join(
                    "#" if (line[x >> 3] >> (7 - (x & 7))) & 1 else "."
                    for x in range(st * 8)
                )
                rows[y] += px + "|"
        for r in rows:
            print("   " + r)
        print()


if __name__ == "__main__":
    main()
