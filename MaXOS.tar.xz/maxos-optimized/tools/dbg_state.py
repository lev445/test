import importlib.util
import struct
import sys

spec = importlib.util.spec_from_file_location("em", "tools/emulate.py")
em = importlib.util.module_from_spec(spec)
spec.loader.exec_module(em)
from unicorn import UcError

m = em.Machine('build/kernel.bin', 'build/kernel.elf', verbose=False)
try:
    m.run_ticks(150, 3000000)
except UcError as e:
    print("UcError:", e, "rip=%#x" % m.uc.reg_read(0x11 | 8))

T, W = m.syms["tasks"], m.syms["wins"]
states = {0: "free", 1: "ready", 2: "running", 3: "sleep", 4: "dead"}

print("\n== tasks ==")
for i in range(8):
    base = T + i * 96
    raw = bytes(m.uc.mem_read(base, 96))
    ctx, stack, ssize = struct.unpack_from("<QQI", raw, 0)
    name = raw[20:44].split(b"\0")[0].decode()
    (state,) = struct.unpack_from("<i", raw, 44)
    wake, ct, cl = struct.unpack_from("<QQQ", raw, 48)
    (pct,) = struct.unpack_from("<I", raw, 72)
    (sw,) = struct.unpack_from("<Q", raw, 80)
    (tid,) = struct.unpack_from("<i", raw, 88)
    print("  #%-2d %-14s %-8s ctx=%#-10x stack=%#-10x switches=%-6u pct=%u" % (
        tid, name, states.get(state, "?"), ctx, stack, sw, pct))

print("\n== windows ==")
for i in range(4):
    base = W + i * 168
    raw = bytes(m.uc.mem_read(base, 168))
    used, wid = struct.unpack_from("<ii", raw, 0)
    title = raw[8:56].split(b"\0")[0].decode()
    x, y, w, h, cw, ch = struct.unpack_from("<iiiiii", raw, 56)
    (buf,) = struct.unpack_from("<Q", raw, 80)
    style, app, focused, alive, repaint, tdone = struct.unpack_from("<iiiiii", raw, 112)
    (period,) = struct.unpack_from("<I", raw, 136)
    paint, = struct.unpack_from("<Q", raw, 144)
    px = None
    if buf and used:
        mid = bytes(m.uc.mem_read(buf + (cw // 2 + (ch // 2) * cw) * 4, 4))
        px = mid.hex()
    print("  win %d %-24s used=%d alive=%d repaint=%d style=%d paint=%#x buf=%#x center=%s" % (
        wid, title, used, alive, repaint, style, paint, buf, px))
