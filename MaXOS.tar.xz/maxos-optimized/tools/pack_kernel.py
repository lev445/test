#!/usr/bin/env python3
"""tools/pack_kernel.py -- проверка и упаковка kernel.bin.

    python3 tools/pack_kernel.py kernel.elf kernel.raw kernel.bin SECTORS

Делает три вещи:
  1. проверяет по ELF, что _start лежит ровно на 0x100000 (иначе stage2
     своим `jmp 0x100000` попадёт не в код, а в .eh_frame_hdr);
  2. проверяет, что образ влезает в SECTORS*512 байт (бюджет stage2);
  3. добивает нулями до SECTORS*512 -- stage2 читает с диска фиксированное
     число секторов, и недобитый хвост означал бы мусор в памяти.
"""
import struct
import sys
import os

BASE = 0x100000


def elf_symbols(data):
    (e_shoff,) = struct.unpack_from("<Q", data, 0x28)
    (e_shentsize,) = struct.unpack_from("<H", data, 0x3A)
    (e_shnum,) = struct.unpack_from("<H", data, 0x3C)
    (e_shstrndx,) = struct.unpack_from("<H", data, 0x3E)
    shs = [struct.unpack_from("<IIQQQQIIQQ", data, e_shoff + i * e_shentsize)
           for i in range(e_shnum)]
    stroff = shs[e_shstrndx][4]

    def secname(s):
        return data[stroff + s[0]:data.index(b"\0", stroff + s[0])].decode()

    syms = {}
    sections = []
    for s in shs:
        name = secname(s)
        if name.startswith("."):
            sections.append((name, s[3], s[5]))
    for s in shs:
        if secname(s) != ".symtab":
            continue
        strtab = shs[s[6]][4]          # sh_link -> .strtab
        entsz = s[9] or 24
        for i in range(s[5] // entsz):
            off = s[4] + i * entsz
            st_name, st_info, st_other, st_shndx, st_value, st_size = \
                struct.unpack_from("<IBBHQQ", data, off)
            nm = data[strtab + st_name:data.index(b"\0", strtab + st_name)].decode()
            if nm:
                syms[nm] = st_value
    return syms, sections


def main():
    if len(sys.argv) != 5:
        print(__doc__)
        return 2
    elf, raw, out, sectors = sys.argv[1:5]
    budget = int(sectors) * 512

    data = open(elf, "rb").read()
    syms, sections = elf_symbols(data)
    blob = bytearray(open(raw, "rb").read())

    print("--- sections -------------------------------------------------")
    for name, addr, size in sections:
        if size:
            print("  %-16s 0x%08x  %8d bytes" % (name, addr, size))

    print("--- checks ---------------------------------------------------")
    ok = True
    start = syms.get("_start")
    if start is None:
        print("  !! symbol _start not found"); ok = False
    elif start != BASE:
        print("  !! _start = 0x%x, expected 0x%x  (линкер положил что-то перед .text)"
              % (start, BASE)); ok = False
    else:
        print("  ok: _start = 0x%x (ровно там, куда прыгает stage2)" % start)

    for s in ("kmain", "kernel_end", "__bss_start", "__bss_end"):
        if s in syms:
            print("  ok: %-12s = 0x%x" % (s, syms[s]))
        else:
            print("  !! symbol %s missing" % s); ok = False

    bss_sz = syms.get("__bss_end", 0) - syms.get("__bss_start", 0)
    load_sz = len(blob)
    print("  image (file)  : %d bytes" % load_sz)
    print("  .bss (zeroed) : %d bytes" % bss_sz)
    print("  budget        : %d bytes (%d sectors)" % (budget, budget // 512))

    if load_sz > budget:
        print("  !! kernel image is too big for stage2 (max %d bytes)" % budget)
        ok = False
    else:
        print("  ok: %d bytes of headroom left" % (budget - load_sz))

    end = syms.get("kernel_end", 0)
    if end and end > BASE + budget:
        print("  !! kernel_end 0x%x is past the 256 KiB window (bss does not fit)" % end)
        ok = False
    elif end:
        print("  ok: kernel_end = 0x%x (bss inside the loaded window)" % end)

    if blob[:4] == b"\x7fELF":
        print("  !! raw image starts with an ELF header -- entry point is not at offset 0")
        ok = False

    if not ok:
        print("FAILED")
        return 1

    blob.extend(b"\0" * (budget - len(blob)))
    with open(out, "wb") as f:
        f.write(blob)
    print("wrote %s (%d bytes)" % (out, len(blob)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
