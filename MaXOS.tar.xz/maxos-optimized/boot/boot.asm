; MaXOS - the stage 1 bootloader, mbr, 512bytes and real mode
; the BIOS load MaXOS bootloader at 0x0000:0x7C00
; about job bootloader: call stage 2 and load him: to 0x0000:0x8000, jump to him, and passing the boot drive in DL

BITS 16
org 0x7C00

stage_2_lba equ 1
stage_2_sect equ 16
stage2_off equ 0x8000
stage2_seg equ 0x0000

start:
	cli
	xor ax, ax
	mov ds, ax
	mov es, ax
	mov ss, ax
	mov sp, 0x7C00
	sti
	mov [boot_drive], dl
	mov si, msg_hello
	call print16
	
	; check if bios supports int 13h extensions
	mov ah, 0x41
	mov bx, 0x55AA
	mov dl, [boot_drive]
	int 0x13
	jc no_ext_support
	cmp bx, 0xAA55
	jne no_ext_support
	
	; extended read (int 13h, ah=42h)
	mov ah, 0x42
	mov dl, [boot_drive]
	mov si, dap_stage2
	int 0x13
	jc disk_error
	mov dl, [boot_drive]
	jmp stage2_seg:stage2_off

no_ext_support:
	mov si, msg_no_ext
	call print16
	jmp halt

disk_error:
	mov si, disk_err
	call print16
	mov al, ah
	call print_hex
	jmp halt

halt:
	cli
	hlt
	jmp halt

; TOOLS
print16:
	pusha
	mov ah, 0x0E
	mov bx, 0x0007
.loop:
	lodsb
	test al, al
	jz .done
	int 0x10
	jmp .loop
.done:
	popa
	ret

print_hex:
	pusha
	mov bl, al
	shr al, 4
	call print_nibble
	mov al, bl
	and al, 0x0F
	call print_nibble
	popa
	ret

print_nibble:
	cmp al, 9
	jbe .num
	add al, 7
.num:
	add al, '0'
	mov ah, 0x0E
	int 0x10
	ret

msg_hello: db "MaXOS stage1. I'm load stage2 (wait pls)...", 13,10,0
disk_err: db "Disk error code, exception: ",0
msg_no_ext: db "error! the BIOS is not support int 13h! Loading not possible.",13,10,0

align 4
dap_stage2:
	db 0x10
	db 0
	dw stage_2_sect
	dw stage2_off
	dw stage2_seg
	dq stage_2_lba        ; LBA -- это QWORD (8 байт). Было dw+dd: структура
	                        ; получалась 14 байт, и в 64-битное поле LBA дочиты-
	                        ; вался байт boot_drive (0x80) -> LBA=0x0080000000000001
	                        ; -> SeaBIOS disk.c: extended_access() -> EPARAM(01).

boot_drive: db 0

times 446 - ($ - $$) db 0
times 64 db 0
times 510 - ($ - $$) db 0
dw 0xAA55
