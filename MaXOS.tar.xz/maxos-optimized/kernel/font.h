#ifndef MAXOS_FONT_H
#define MAXOS_FONT_H

#include "types.h"

/* Лица шрифта (индексы в массиве fonts[]). */
enum {
    FONT_MONO = 0, /* 8x16, равноширинный: терминал, ранняя консоль */
    FONT_UI   = 1, /* пропорциональный ~18px: интерфейс Aqua        */
    FONT_TITLE= 2, /* пропорциональный ~36px: крупные заголовки      */
    FONT_COUNT= 3
};

#define FONT_GLYPHS 95 /* ASCII 32..126 */

typedef struct {
    const u8 *bits;   /* [95][h*stride], bpp=1: 1bpp MSB слева;
                       *               bpp=4: два пикселя на байт,
                       *               старший nibble -- левый (coverage) */
    const u8 *adv;    /* [95] ширина глифа (advance)               */
    u8 h;             /* высота ячейки в пикселях                  */
    u8 stride;        /* байт на строку глифа                      */
    u8 baseline;      /* строка базовой линии                      */
    u8 bpp;           /* 1 или 4: биты на пиксель (4 = сглаживание) */
} font_t;

extern const font_t fonts[FONT_COUNT];

#endif
