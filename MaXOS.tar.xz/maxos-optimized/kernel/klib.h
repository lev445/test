#ifndef MAXOS_KLIB_H
#define MAXOS_KLIB_H

#include "types.h"
#include <stdarg.h>

/* Память и строки. Свои, потому что freestanding не даёт никакой libc. */
void *memcpy(void *dst, const void *src, usize n);
void *memmove(void *dst, const void *src, usize n);
void *memset(void *dst, int c, usize n);
int   memcmp(const void *a, const void *b, usize n);

usize strlen(const char *s);
int   strcmp(const char *a, const char *b);
int   strncmp(const char *a, const char *b, usize n);
char *strcpy(char *dst, const char *src);
char *strncpy(char *dst, const char *src, usize n);
char *strcat(char *dst, const char *src);
const char *strchr(const char *s, int c);

/* Форматтер: %d %i %u %x %X %c %s %p %% , ширина, '-', '0'. */
int kvsprintf(char *buf, const char *fmt, va_list ap);
int kvsnprintf(char *buf, usize size, const char *fmt, va_list ap);
int ksnprintf(char *buf, usize size, const char *fmt, ...);

/* Числа -> строка (buf должен быть достаточным). */
char *itoa(i64 v, char *buf, int base);
char *utoa(u64 v, char *buf, int base);

#endif
