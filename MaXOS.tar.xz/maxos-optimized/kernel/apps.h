#ifndef MAXOS_APPS_H
#define MAXOS_APPS_H

#include "gui.h"

/* Приложения в доке. Порядок совпадает с порядком иконок. */
enum {
    APP_ABOUT = 0,
    APP_TERMINAL,
    APP_ACTIVITY,
    APP_BOUNCE,
    APP_CALC,
    APP_COUNT
};

extern const char *app_names[APP_COUNT];
extern volatile u32 app_bounce_ms;   /* сколько ещё прыгать иконке в доке */
extern const char *app_menus[APP_COUNT];

void   apps_init(void);          /* стартовые окна */
void   apps_tick(void);          /* зовётся потоком композитора каждый кадр */
win_t *app_launch(int id);       /* открыть (или поднять, если уже открыто) */
win_t *app_find(int id);
void   app_hog(void *arg);       /* демо: тяжёлая задача для beachball */

#endif
