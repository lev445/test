#include "gfx.h"
#include "font.h"
#include "klib.h"
#include <emmintrin.h>   /* gfx.c -- единственный файл ядра с -msse2 */

/* =====================================================================
 *  Примитивы рисования. Всё считается в 0x00RRGGBB и пишется в
 *  surf_t. Никакого MMIO здесь нет -- поверхностью может быть и канвас
 *  композитора, и буфер окна, и сам фреймбуфер (для ранней консоли).
 *
 *  Внутренние горячие циклы -- на SSE2 (копирование/заливка строк) и на
 *  SWAR (alpha-блендинг по два пикселя за операцию в 64-битном слове).
 * =================================================================== */

u32 mixc(u32 d, u32 s, u32 a)
{
    if (a == 0)   return d;
    if (a >= 256) return s;
    u32 ia = 256 - a;
    u32 r = ((d >> 16 & 0xFF) * ia + (s >> 16 & 0xFF) * a) >> 8;
    u32 g = ((d >>  8 & 0xFF) * ia + (s >>  8 & 0xFF) * a) >> 8;
    u32 b = ((d       & 0xFF) * ia + (s       & 0xFF) * a) >> 8;
    return (r << 16) | (g << 8) | b;
}

/* Заливка строки: 16 пикселей за итерацию SSE2. */
static inline void row_fill(u32 *p, i32 w, u32 c)
{
    __m128i v = _mm_set1_epi32((int)c);
    i32 i = 0;
    for (; i + 16 <= w; i += 16) {
        _mm_storeu_si128((__m128i *)(p + i),      v);
        _mm_storeu_si128((__m128i *)(p + i + 4),  v);
        _mm_storeu_si128((__m128i *)(p + i + 8),  v);
        _mm_storeu_si128((__m128i *)(p + i + 12), v);
    }
    if (i + 8 <= w) {
        _mm_storeu_si128((__m128i *)(p + i), v);
        _mm_storeu_si128((__m128i *)(p + i + 4), v);
        i += 8;
    }
    if (i + 4 <= w) { _mm_storeu_si128((__m128i *)(p + i), v); i += 4; }
    for (; i < w; i++) p[i] = c;
}

/* Копирование строки: 16 пикселей за итерацию SSE2. */
static inline void row_copy(u32 *d, const u32 *s, i32 w)
{
    i32 i = 0;
    for (; i + 16 <= w; i += 16) {
        __m128i a = _mm_loadu_si128((const __m128i *)(s + i));
        __m128i b = _mm_loadu_si128((const __m128i *)(s + i + 4));
        __m128i c = _mm_loadu_si128((const __m128i *)(s + i + 8));
        __m128i e = _mm_loadu_si128((const __m128i *)(s + i + 12));
        _mm_storeu_si128((__m128i *)(d + i),      a);
        _mm_storeu_si128((__m128i *)(d + i + 4),  b);
        _mm_storeu_si128((__m128i *)(d + i + 8),  c);
        _mm_storeu_si128((__m128i *)(d + i + 12), e);
    }
    if (i + 8 <= w) {
        _mm_storeu_si128((__m128i *)(d + i),     _mm_loadu_si128((const __m128i *)(s + i)));
        _mm_storeu_si128((__m128i *)(d + i + 4), _mm_loadu_si128((const __m128i *)(s + i + 4)));
        i += 8;
    }
    if (i + 4 <= w) {
        _mm_storeu_si128((__m128i *)(d + i), _mm_loadu_si128((const __m128i *)(s + i)));
        i += 4;
    }
    for (; i < w; i++) d[i] = s[i];
}

/* Блендинг строки постоянным alpha (развёрнуто, без переносов между
 * пикселями: mixc считает каждый канал отдельно). */
static inline void row_blend(u32 *p, i32 w, u32 c, u32 a)
{
    if (a >= 256) { row_fill(p, w, c); return; }
    i32 i = 0;
    for (; i + 4 <= w; i += 4) {
        p[i]     = mixc(p[i],     c, a);
        p[i + 1] = mixc(p[i + 1], c, a);
        p[i + 2] = mixc(p[i + 2], c, a);
        p[i + 3] = mixc(p[i + 3], c, a);
    }
    for (; i < w; i++) p[i] = mixc(p[i], c, a);
}

/* Публичные строковые примитивы (ими пользуется и fb.c). */
void gfx_row_fill(u32 *p, i32 w, u32 c)      { row_fill(p, w, c); }
void gfx_row_copy(u32 *d, const u32 *s, i32 w){ row_copy(d, s, w); }

void gfx_copy_rows(u32 *dst, u32 dstride, const u32 *src, u32 sstride,
                   u32 w, u32 y0, u32 y1)
{
    for (u32 y = y0; y < y1; y++)
        row_copy(dst + (usize)y * dstride, src + (usize)y * sstride, (i32)w);
}

int gfx_clip(i32 *x, i32 *y, i32 *w, i32 *h, i32 cw, i32 ch)
{
    if (*w <= 0 || *h <= 0) return 0;
    if (*x < 0) { *w += *x; *x = 0; }
    if (*y < 0) { *h += *y; *y = 0; }
    if (*x + *w > cw) *w = cw - *x;
    if (*y + *h > ch) *h = ch - *y;
    return (*w > 0 && *h > 0);
}

void gfx_fill(surf_t *s, i32 x, i32 y, i32 w, i32 h, u32 c)
{
    if (!gfx_clip(&x, &y, &w, &h, (i32)s->w, (i32)s->h)) return;
    u32 *p = s->px + (u32)y * s->stride + (u32)x;
    for (i32 j = 0; j < h; j++) {
        row_fill(p, w, c);
        p += s->stride;
    }
}

void gfx_blend(surf_t *s, i32 x, i32 y, i32 w, i32 h, u32 c, u32 a)
{
    if (a >= 256) { gfx_fill(s, x, y, w, h, c); return; }
    if (a == 0)   return;
    if (!gfx_clip(&x, &y, &w, &h, (i32)s->w, (i32)s->h)) return;
    u32 *p = s->px + (u32)y * s->stride + (u32)x;
    for (i32 j = 0; j < h; j++) {
        row_blend(p, w, c, a);
        p += s->stride;
    }
}

void gfx_hline(surf_t *s, i32 x, i32 y, i32 w, u32 c) { gfx_fill(s, x, y, w, 1, c); }
void gfx_vline(surf_t *s, i32 x, i32 y, i32 h, u32 c) { gfx_fill(s, x, y, 1, h, c); }

void gfx_rect(surf_t *s, i32 x, i32 y, i32 w, i32 h, u32 c)
{
    gfx_hline(s, x, y, w, c);
    gfx_hline(s, x, y + h - 1, w, c);
    gfx_vline(s, x, y, h, c);
    gfx_vline(s, x + w - 1, y, h, c);
}

/* ---------------------------------------------------------------------
 *  Скруглённые углы. inset(y) -- сколько пикселей съесть слева/справа
 *  на строке с расстоянием y от края.
 * ------------------------------------------------------------------- */
static i32 isqrt(i32 v)
{
    if (v <= 0) return 0;
    i32 r = 1;
    while (r * r <= v && r < 46341) r++;
    return r - 1;
}

i32 gfx_corner_inset(i32 y, i32 r)
{
    /* y = 0..r-1 от края; dy = r - y = 1..r */
    i32 dy = r - y;
    i32 t = r * r - dy * dy;
    return r - isqrt(t);
}

static void round_rows(surf_t *s, i32 x, i32 y, i32 w, i32 h, i32 r,
                       u32 c, u32 alpha, int outline)
{
    if (r * 2 > w) r = w / 2;
    if (r * 2 > h) r = h / 2;
    if (r < 1) {
        if (outline) gfx_rect(s, x, y, w, h, c);
        else gfx_blend(s, x, y, w, h, c, alpha);
        return;
    }
    for (i32 j = 0; j < h; j++) {
        i32 in = 0;
        if (j < r)          in = gfx_corner_inset(j, r);
        else if (j >= h - r) in = gfx_corner_inset(h - 1 - j, r);
        if (outline) {
            /* только крайние пиксели строки + верх/низ целиком */
            if (j == 0 || j == h - 1) {
                gfx_blend(s, x + in, y + j, w - 2 * in, 1, c, alpha);
            } else {
                i32 span = w - 2 * in;
                if (span > 0) {
                    gfx_blend(s, x + in, y + j, 1, 1, c, alpha);
                    gfx_blend(s, x + in + span - 1, y + j, 1, 1, c, alpha);
                }
            }
        } else {
            gfx_blend(s, x + in, y + j, w - 2 * in, 1, c, alpha);
        }
    }
}

void gfx_round(surf_t *s, i32 x, i32 y, i32 w, i32 h, i32 r, u32 c)
{
    round_rows(s, x, y, w, h, r, c, 256, 0);
}
void gfx_round_blend(surf_t *s, i32 x, i32 y, i32 w, i32 h, i32 r, u32 c, u32 a)
{
    round_rows(s, x, y, w, h, r, c, a, 0);
}
void gfx_round_outline(surf_t *s, i32 x, i32 y, i32 w, i32 h, i32 r, u32 c, u32 a)
{
    round_rows(s, x, y, w, h, r, c, a, 1);
}

void gfx_grad_v(surf_t *s, i32 x, i32 y, i32 w, i32 h, u32 top, u32 bot)
{
    if (h <= 1) { gfx_fill(s, x, y, w, h, top); return; }
    for (i32 j = 0; j < h; j++) {
        u32 t = (u32)(j * 256) / (u32)(h - 1);
        gfx_hline(s, x, y + j, w, mixc(top, bot, t));
    }
}

void gfx_grad_stops(surf_t *s, i32 x, i32 y, i32 w, i32 h, const u32 *stops, u32 n)
{
    if (n == 0) return;
    if (n == 1 || h <= 1) { gfx_fill(s, x, y, w, h, stops[0]); return; }
    for (i32 j = 0; j < h; j++) {
        u32 t = (u32)(j * 256 * (n - 1)) / (u32)(h - 1);  /* 0..256*(n-1) */
        u32 seg = t >> 8;
        if (seg >= n - 1) seg = n - 2;
        u32 frac = t - (seg << 8);
        gfx_hline(s, x, y + j, w, mixc(stops[seg], stops[seg + 1], frac));
    }
}

void gfx_pinstripe(surf_t *s, i32 x, i32 y, i32 w, i32 h, u32 base, u32 line)
{
    gfx_fill(s, x, y, w, h, base);
    for (i32 i = 0; i < w; i += 2) gfx_vline(s, x + i, y, h, line);
}

void gfx_circle(surf_t *s, i32 cx, i32 cy, i32 r, u32 c)
{
    gfx_circle_blend(s, cx, cy, r, c, 256);
}


/* coverage пикселя (16 сэмплов) для скруглённого прямоугольника --
 * целочисленный SDF в 1/8 пикселя. Для сглаженных углов. */
u32 gfx_rr_cov(i32 X, i32 Y, i32 W, i32 H, i32 R, i32 px, i32 py)
{
    if (R < 1) return 16;
    i64 rr = (i64)8 * R;
    i64 hx = 4 * (W - 2 * R), hy = 4 * (H - 2 * R);
    i64 cx = 8 * (i64)X + 4 * W, cy = 8 * (i64)Y + 4 * H;
    u32 hits = 0;
    for (u32 ty = 0; ty < 4; ty++) {
        i64 dy = 8 * (i64)py + 1 + 2 * ty - cy;
        if (dy < 0) dy = -dy;
        dy -= hy; if (dy < 0) dy = 0;
        for (u32 tx = 0; tx < 4; tx++) {
            i64 dx = 8 * (i64)px + 1 + 2 * tx - cx;
            if (dx < 0) dx = -dx;
            dx -= hx; if (dx < 0) dx = 0;
            if (dx * dx + dy * dy <= rr * rr) hits++;
        }
    }
    return hits;
}

/* Скруглённый прямоугольник со сглаженными углами: середина строки --
 * быстрой заливкой, краевые пиксели -- по coverage. */
void gfx_aa_round_blend(surf_t *s, i32 x, i32 y, i32 w, i32 h, i32 r, u32 c, u32 a)
{
    if (r < 1) { gfx_blend(s, x, y, w, h, c, a); return; }
    for (i32 j = 0; j < h; j++) {
        i32 yy = y + j;
        if (yy < 0 || yy >= (i32)s->h) continue;
        i32 e0;
        if (j >= r && j < h - r) e0 = 0;
        else e0 = gfx_corner_inset((j < r) ? j : h - 1 - j, r);
        i32 f = e0, l = w - 1 - e0;
        while (f > 0) {
            u32 cov = gfx_rr_cov(x, y, w, h, r, x + f - 1, yy);
            if (!cov) break;
            f--;
            gfx_blend(s, x + f, yy, 1, 1, c, (a * cov) >> 4);
        }
        while (l < w - 1) {
            u32 cov = gfx_rr_cov(x, y, w, h, r, x + l + 1, yy);
            if (!cov) break;
            l++;
            gfx_blend(s, x + l, yy, 1, 1, c, (a * cov) >> 4);
        }
        if (f <= l) {
            u32 cov = gfx_rr_cov(x, y, w, h, r, x + f, yy);
            if (cov < 16) { gfx_blend(s, x + f, yy, 1, 1, c, (a * cov) >> 4); f++; }
        }
        if (l >= f) {
            u32 cov = gfx_rr_cov(x, y, w, h, r, x + l, yy);
            if (cov < 16) { gfx_blend(s, x + l, yy, 1, 1, c, (a * cov) >> 4); l--; }
        }
        if (f <= l) gfx_blend(s, x + f, yy, l - f + 1, 1, c, a);
    }
}

void gfx_aa_round(surf_t *s, i32 x, i32 y, i32 w, i32 h, i32 r, u32 c)
{
    gfx_aa_round_blend(s, x, y, w, h, r, c, 256);
}

/* Сглаженный круг: 4x4 сэмпла на пиксель в 1/8 долях пикселя, целочисленно.
 * Для мелких фигур (светофоры, точки дока) лесенка слишком заметна. */

/* Контур скруглённого прямоугольника со сглаживанием: только краевые
 * пиксели строки (верх/низ -- целиком), альфа по coverage. */
void gfx_aa_round_outline(surf_t *s, i32 x, i32 y, i32 w, i32 h, i32 r, u32 c, u32 a)
{
    if (r < 1) { gfx_rect(s, x, y, w, h, c); return; }
    for (i32 j = 0; j < h; j++) {
        i32 yy = y + j;
        if (yy < 0 || yy >= (i32)s->h) continue;
        i32 e0;
        if (j >= r && j < h - r) e0 = 0;
        else e0 = gfx_corner_inset((j < r) ? j : h - 1 - j, r);
        i32 f = e0, l = w - 1 - e0;
        while (f > 0 && gfx_rr_cov(x, y, w, h, r, x + f - 1, yy)) f--;
        while (l < w - 1 && gfx_rr_cov(x, y, w, h, r, x + l + 1, yy)) l++;
        if (j == 0 || j == h - 1) {
            for (i32 i = f; i <= l; i++) {
                u32 cov = gfx_rr_cov(x, y, w, h, r, x + i, yy);
                gfx_blend(s, x + i, yy, 1, 1, c, (a * cov) >> 4);
            }
        } else {
            u32 cf = gfx_rr_cov(x, y, w, h, r, x + f, yy);
            u32 cl = gfx_rr_cov(x, y, w, h, r, x + l, yy);
            gfx_blend(s, x + f, yy, 1, 1, c, (a * cf) >> 4);
            if (l > f) gfx_blend(s, x + l, yy, 1, 1, c, (a * cl) >> 4);
        }
    }
}

void gfx_aa_circle_blend(surf_t *s, i32 cx, i32 cy, i32 r, u32 c, u32 a)
{
    if (r <= 0) return;
    i32 rr = 8 * r;                       /* радиус в 1/8 пикселя */
    for (i32 y = cy - r; y <= cy + r; y++) {
        if (y < 0 || y >= (i32)s->h) continue;
        for (i32 x = cx - r; x <= cx + r; x++) {
            if (x < 0 || x >= (i32)s->w) continue;
            u32 hits = 0;
            for (u32 ty = 0; ty < 4; ty++) {
                i32 dy = 8 * (y - cy) + 1 + 2 * (i32)ty;
                for (u32 tx = 0; tx < 4; tx++) {
                    i32 dx = 8 * (x - cx) + 1 + 2 * (i32)tx;
                    if (dx * dx + dy * dy <= rr * rr) hits++;
                }
            }
            if (!hits) continue;
            u32 al = (a * hits) >> 4;
            u32 *p = &s->px[(usize)y * s->stride + (u32)x];
            *p = (al >= 256) ? c : mixc(*p, c, al);
        }
    }
}

void gfx_aa_circle(surf_t *s, i32 cx, i32 cy, i32 r, u32 c)
{
    gfx_aa_circle_blend(s, cx, cy, r, c, 256);
}

void gfx_circle_blend(surf_t *s, i32 cx, i32 cy, i32 r, u32 c, u32 a)
{
    i32 r2 = r * r;
    for (i32 dy = -r; dy <= r; dy++) {
        i32 y = cy + dy;
        if (y < 0 || y >= (i32)s->h) continue;
        for (i32 dx = -r; dx <= r; dx++) {
            i32 x = cx + dx;
            if (x < 0 || x >= (i32)s->w) continue;
            if (dx * dx + dy * dy <= r2)
                s->px[y * s->stride + x] = mixc(s->px[y * s->stride + x], c, a);
        }
    }
}

void gfx_line(surf_t *s, i32 x0, i32 y0, i32 x1, i32 y1, u32 c)
{
    i32 dx = x1 - x0, dy = y1 - y0;
    i32 sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1;
    if (dx < 0) dx = -dx;
    if (dy < 0) dy = -dy;
    i32 err = dx - dy;
    for (;;) {
        if ((u32)x0 < s->w && (u32)y0 < s->h) s->px[y0 * s->stride + x0] = c;
        if (x0 == x1 && y0 == y1) break;
        i32 e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x0 += sx; }
        if (e2 <  dx) { err += dx; y0 += sy; }
    }
}

void gfx_fill_tri(surf_t *s, i32 x0, i32 y0, i32 x1, i32 y1, i32 x2, i32 y2, u32 c)
{
    i32 miny = MIN(y0, MIN(y1, y2)), maxy = MAX(y0, MAX(y1, y2));
    if (miny < 0) miny = 0;
    if (maxy >= (i32)s->h) maxy = (i32)s->h - 1;
    for (i32 y = miny; y <= maxy; y++) {
        i32 xa = -1, xb = -1;
        i32 px[3] = { x0, x1, x2 }, py[3] = { y0, y1, y2 };
        for (int e = 0; e < 3; e++) {
            i32 a = e, b = (e + 1) % 3;
            if ((py[a] <= y && py[b] > y) || (py[b] <= y && py[a] > y)) {
                i32 x = px[a] + (i32)(((i64)(y - py[a]) * (px[b] - px[a])) / (py[b] - py[a]));
                if (xa < 0) xa = x; else xb = x;
            }
        }
        if (xa < 0 || xb < 0) continue;
        if (xa > xb) { i32 t = xa; xa = xb; xb = t; }
        gfx_hline(s, xa, y, xb - xa + 1, c);
    }
}

void gfx_blit(surf_t *d, const u32 *src, u32 sw, u32 sh, i32 dx, i32 dy, i32 w, i32 h)
{
    if (w <= 0 || h <= 0) return;
    if (w > (i32)sw) w = (i32)sw;
    if (h > (i32)sh) h = (i32)sh;
    /* ВАЖНО: при обрезке.destination нужно СДВИГАТЬ И ИСТОЧНИК. Раньше
     * источник всегда брался с (0,0), и при отрицательных dx/dy (окно
     * частично вне damage-региона) в кадр приезжал чужой угол буфера. */
    i32 sx = 0, sy = 0;
    if (dx < 0) { sx = -dx; w += dx; dx = 0; }
    if (dy < 0) { sy = -dy; h += dy; dy = 0; }
    if (dx + w > (i32)d->w) w = (i32)d->w - dx;
    if (dy + h > (i32)d->h) h = (i32)d->h - dy;
    if (w <= 0 || h <= 0) return;
    for (i32 j = 0; j < h; j++) {
        const u32 *srow = src + (usize)(sy + j) * sw + sx;
        u32 *p = d->px + (usize)(dy + j) * d->stride + (u32)dx;
        row_copy(p, srow, w);
    }
}



/* =====================================================================
 *  Текст
 * =================================================================== */
/* coverage 0..255 -> пиксель текста с учётом alpha строки */
static inline void put_px(surf_t *s, i32 xx, i32 yy, u32 c, u32 cov, u32 alpha)
{
    if (cov == 0) return;
    u32 a = (cov >= 255) ? alpha : (cov * alpha) >> 8;
    if (a == 0) return;
    u32 *dst = &s->px[(usize)yy * s->stride + (u32)xx];
    *dst = (a >= 256) ? c : mixc(*dst, c, a);
}

static void text_blit(surf_t *s, i32 x, i32 y, const char *str, u32 c, u32 alpha,
                      int face, int bold)
{
    if (face < 0 || face >= FONT_COUNT) face = FONT_UI;
    const font_t *f = &fonts[face];
    u32 stride = f->stride, h = f->h;
    /* bpp бит на пиксель: 4 -> 2 пикселя на байт, 2 -> 4, 1 -> 8 */
    u32 bpp = f->bpp ? f->bpp : 1;
    u32 ppb = 8 / bpp;                 /* пикселей на байт   */
    u32 nmask = (1u << bpp) - 1;       /* маска поля пикселя */
    u32 scale = 255 / nmask;           /* -> coverage 0..255 */
    u32 gw = stride * ppb;             /* ширина глифа в пикселях (с паддингом) */

    for (const char *p = str; *p; p++) {
        unsigned char ch = (unsigned char)*p;
        if (ch == '\n') { y += (i32)h; continue; }
        if (ch < 32 || ch > 126) ch = '?';
        u32 idx = ch - 32;
        const u8 *g = f->bits + (usize)idx * h * stride;

        /* клиппинг по вертикали разу на весь глиф */
        i32 y0 = y < 0 ? 0 : y;
        i32 y1 = y + (i32)h;
        if (y1 > (i32)s->h) y1 = (i32)s->h;
        if (x >= (i32)s->w) { x += (i32)f->adv[idx]; continue; }

        for (i32 yy = y0; yy < y1; yy++) {
            const u8 *grow = g + (usize)(yy - y) * stride;
            u32 prev = 0;                 /* coverage слева (для фейк-болда) */
            for (u32 i = 0; i < gw; i++) {
                u8 b = grow[i / ppb];
                if (b == 0) {             /* весь байт пуст -- прыгаем за него */
                    prev = 0;
                    i += ppb - 1 - (i % ppb);
                    continue;
                }
                u32 sh = bpp * (ppb - 1 - (i % ppb));
                u32 cov = ((u32)(b >> sh) & nmask) * scale;
                if (bold) {
                    /* синтетическая жирность: пиксель = max(свой, сосед слева) */
                    if (prev > cov) cov = prev;
                }
                prev = cov;
                if (cov == 0) continue;
                i32 xx = x + (i32)i;
                if (xx < 0) continue;
                if (xx >= (i32)s->w) break;
                put_px(s, xx, yy, c, cov, alpha);
            }
        }
        x += (i32)f->adv[idx];
    }
}

void gfx_text(surf_t *s, i32 x, i32 y, const char *str, u32 c, int face, int bold)
{
    text_blit(s, x, y, str, c, 256, face, bold);
}

void gfx_text_blend(surf_t *s, i32 x, i32 y, const char *str, u32 c, u32 a,
                    int face, int bold)
{
    text_blit(s, x, y, str, c, a, face, bold);
}

u32 gfx_text_width(const char *str, int face)
{
    if (face < 0 || face >= FONT_COUNT) face = FONT_UI;
    const font_t *f = &fonts[face];
    u32 w = 0;
    for (const char *p = str; *p; p++) {
        unsigned char ch = (unsigned char)*p;
        if (ch < 32 || ch > 126) ch = '?';
        w += f->adv[ch - 32];
    }
    return w;
}

u32 gfx_text_height(int face)
{
    if (face < 0 || face >= FONT_COUNT) face = FONT_UI;
    return fonts[face].h;
}


