#ifndef MAXOS_GFX_H
#define MAXOS_GFX_H

#include "types.h"

/* Поверхность: просто кусок памяти с 32-битными пикселями 0x00RRGGBB.
 * Это может быть канвас композитора, буфер окна или сам фреймбуфер. */
typedef struct {
    u32 *px;
    u32  w, h;
    u32  stride;   /* пикселей в строке (не байт!) */
} surf_t;

#define R(c) (((c) >> 16) & 0xFF)
#define G(c) (((c) >>  8) & 0xFF)
#define B(c) ( (c)        & 0xFF)

static inline u32 rgb(u8 r, u8 g, u8 b) { return ((u32)r << 16) | ((u32)g << 8) | b; }
u32 mixc(u32 dst, u32 src, u32 alpha);   /* alpha 0..256 */

void gfx_fill(surf_t *s, i32 x, i32 y, i32 w, i32 h, u32 c);
void gfx_blend(surf_t *s, i32 x, i32 y, i32 w, i32 h, u32 c, u32 alpha);
void gfx_hline(surf_t *s, i32 x, i32 y, i32 w, u32 c);
void gfx_vline(surf_t *s, i32 x, i32 y, i32 h, u32 c);
void gfx_rect(surf_t *s, i32 x, i32 y, i32 w, i32 h, u32 c);      /* контур */
void gfx_round(surf_t *s, i32 x, i32 y, i32 w, i32 h, i32 r, u32 c);
void gfx_round_blend(surf_t *s, i32 x, i32 y, i32 w, i32 h, i32 r, u32 c, u32 a);
void gfx_round_outline(surf_t *s, i32 x, i32 y, i32 w, i32 h, i32 r, u32 c, u32 a);
void gfx_grad_v(surf_t *s, i32 x, i32 y, i32 w, i32 h, u32 top, u32 bot);
void gfx_grad_stops(surf_t *s, i32 x, i32 y, i32 w, i32 h, const u32 *stops, u32 n);
void gfx_pinstripe(surf_t *s, i32 x, i32 y, i32 w, i32 h, u32 base, u32 line);
void gfx_circle(surf_t *s, i32 cx, i32 cy, i32 r, u32 c);
void gfx_circle_blend(surf_t *s, i32 cx, i32 cy, i32 r, u32 c, u32 a);
/* то же со сглаживанием (4x4 сэмпла): для мелких фигур */
u32  gfx_rr_cov(i32 X, i32 Y, i32 W, i32 H, i32 R, i32 px, i32 py);
void gfx_aa_round(surf_t *s, i32 x, i32 y, i32 w, i32 h, i32 r, u32 c);
void gfx_aa_round_blend(surf_t *s, i32 x, i32 y, i32 w, i32 h, i32 r, u32 c, u32 a);
void gfx_aa_round_outline(surf_t *s, i32 x, i32 y, i32 w, i32 h, i32 r, u32 c, u32 a);
void gfx_aa_circle(surf_t *s, i32 cx, i32 cy, i32 r, u32 c);
void gfx_aa_circle_blend(surf_t *s, i32 cx, i32 cy, i32 r, u32 c, u32 a);
void gfx_line(surf_t *s, i32 x0, i32 y0, i32 x1, i32 y1, u32 c);
void gfx_fill_tri(surf_t *s, i32 x0, i32 y0, i32 x1, i32 y1, i32 x2, i32 y2, u32 c);
i32  gfx_corner_inset(i32 y, i32 r);   /* скругление: сколько пикселей съесть слева */
void gfx_blit(surf_t *d, const u32 *src, u32 sw, u32 sh, i32 dx, i32 dy, i32 w, i32 h);
/* То же, но пиксели, равные key, считаются прозрачными. */
#define GFX_KEY 0xFF00FFu

/* Текст. face -- индекс из font.h, bold синтезируется сдвигом на 1px. */
void gfx_text(surf_t *s, i32 x, i32 y, const char *str, u32 c, int face, int bold);
void gfx_text_blend(surf_t *s, i32 x, i32 y, const char *str, u32 c, u32 a,
                    int face, int bold);
u32  gfx_text_width(const char *str, int face);
u32  gfx_text_height(int face);

/* Клип-прямоугольник: пересечение двух прямоугольников (возвращает 0, если пусто). */
int  gfx_clip(i32 *x, i32 *y, i32 *w, i32 *h, i32 cw, i32 ch);

/* Быстрые строковые примитивы (SSE2/SWAR), живут в gfx.c (-msse2):
 * ими пользуется fb.c для выгона канваса во фреймбуфер. */
void gfx_row_fill(u32 *p, i32 w, u32 c);
void gfx_row_copy(u32 *d, const u32 *s, i32 w);
void gfx_copy_rows(u32 *dst, u32 dstride, const u32 *src, u32 sstride,
                   u32 w, u32 y0, u32 y1);

#endif
