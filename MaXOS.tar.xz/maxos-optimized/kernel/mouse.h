#ifndef MAXOS_MOUSE_H
#define MAXOS_MOUSE_H

#include "types.h"

/* Событие мыши: относительное смещение + состояние кнопок.
 * dy положителен ВВЕРХ (так устроена PS/2), GUI сам перевернёт. */
typedef struct {
    i32 dx, dy;
    i8  wheel;
    u8  buttons;      /* MB_* */
} mouse_evt_t;

#define MB_LEFT   0x01
#define MB_RIGHT  0x02
#define MB_MIDDLE 0x04

int  mouse_init(void);        /* 1 = устройство отвечало */
int  mouse_present(void);
void mouse_irq(void);         /* IRQ12 */
int  mouse_poll(mouse_evt_t *e);
int  mouse_pending(void);

#endif
