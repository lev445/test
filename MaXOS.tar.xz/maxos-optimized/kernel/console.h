#ifndef MAXOS_CONSOLE_H
#define MAXOS_CONSOLE_H

#include "types.h"

/* Текстовая консоль 8x16 прямо по фреймбуферу. Живёт до запуска GUI,
 * плюс остаётся аварийным каналом, если графика не поднялась. */
void console_init(void);
void console_putc(char c);
void console_write(const char *s);
void console_printf(const char *fmt, ...);
void console_clear(void);
void console_set_fg(u32 c);
void console_disable(void);
int  console_enabled(void);

#endif
