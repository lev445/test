#include "fb.h"
#include "klib.h"

fb_info_t fb;

/* То, что нам оставил stage2 по адресу 0x30400 (см. boot/stage2.asm).
 * Упаковано ровно так, как писала 16-битная часть: 6 dword, qword, 6 byte. */
typedef struct __attribute__((packed)) {
    u32 magic;
    u32 ok;
    u32 width;
    u32 height;
    u32 bpp;
    u32 pitch;
    u64 base;
    u8  rpos, gpos, bpos;
    u8  rsize, gsize, bsize;
} vbe_boot_info_t;

#define VBE_INFO ((volatile const vbe_boot_info_t *)0x30400)

void fb_init(u32 w, u32 h, u32 bpp, u32 pitch, u64 base, u32 ok)
{
    memset(&fb, 0, sizeof(fb));
    fb.width  = w  ? w  : 1024;
    fb.height = h  ? h  : 768;
    fb.bpp    = bpp ? bpp : 32;
    fb.pitch  = pitch ? pitch : fb.width * 4;
    fb.base   = base;
    fb.ok     = ok;

    /* маска цвета: по умолчанию XRGB (так у 99% VBE-режимов) */
    fb.rpos = 16; fb.rsize = 8;
    fb.gpos = 8;  fb.gsize = 8;
    fb.bpos = 0;  fb.bsize = 8;
    if (ok && VBE_INFO->magic == 0x31454256u && VBE_INFO->rsize) {
        fb.rpos = VBE_INFO->rpos; fb.rsize = VBE_INFO->rsize;
        fb.gpos = VBE_INFO->gpos; fb.gsize = VBE_INFO->gsize;
        fb.bpos = VBE_INFO->bpos; fb.bsize = VBE_INFO->bsize;
    }
    if (fb.bpp != 32) fb.ok = 0;   /* GUI рассчитан строго на 32 bpp */
}

int fb_surface(surf_t *out)
{
    if (!fb.ok) return 0;
    out->px     = (u32 *)(usize)fb.base;
    out->w      = fb.width;
    out->h      = fb.height;
    out->stride = fb.pitch / 4;
    return 1;
}

void fb_flush_rows(const u32 *canvas, u32 y0, u32 y1)
{
    if (!fb.ok) return;
    if (y1 > fb.height) y1 = fb.height;
    if (y0 >= y1) return;
    u32 *dst = (u32 *)(usize)fb.base;
    u32 dstride = fb.pitch / 4;
    u32 w = fb.width;

    if (fb.rpos == 16 && fb.gpos == 8 && fb.bpos == 0 &&
        fb.rsize == 8 && fb.gsize == 8 && fb.bsize == 8) {
        /* SSE2-копирование строк из gfx.c (fb.c собран без -msse2) */
        gfx_copy_rows(dst, dstride, canvas, w, w, y0, y1);
        return;
    }
    for (u32 y = y0; y < y1; y++) {
        const u32 *s = canvas + (usize)y * w;
        u32 *d = dst + (usize)y * dstride;
        for (u32 x = 0; x < w; x++) {
            u32 c = s[x];
            d[x] = (((c >> 16) & 0xFF) << fb.rpos) |
                   (((c >>  8) & 0xFF) << fb.gpos) |
                   (( c        & 0xFF) << fb.bpos);
        }
    }
}

void fb_flush(const u32 *canvas)
{
    fb_flush_rows(canvas, 0, fb.height);
}
