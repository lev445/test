#ifndef MAXOS_FB_H
#define MAXOS_FB_H

#include "types.h"
#include "gfx.h"

typedef struct {
    u64  base;          /* физический (=виртуальный, identity) адрес LFB */
    u32  width, height;
    u32  pitch;         /* байт на строку */
    u32  bpp;
    u32  ok;            /* 1 = VBE отдал линейный фреймбуфер */
    u8   rpos, gpos, bpos;
    u8   rsize, gsize, bsize;
} fb_info_t;

extern fb_info_t fb;

void fb_init(u32 w, u32 h, u32 bpp, u32 pitch, u64 base, u32 ok);
/* Поверхность самого фреймбуфера (для ранней консоли, до появления канваса). */
int   fb_surface(surf_t *out);
/* Канвас 0x00RRGGBB (w*h) -> железо с учётом маски цвета. */
void fb_flush(const u32 *canvas);
/* То же, но только строки [y0, y1): композитор с damage-rects перерисовывает
 * не весь экран, и гнать 3 MiB по шине ради пары строк -- расточительно. */
void fb_flush_rows(const u32 *canvas, u32 y0, u32 y1);

#endif
