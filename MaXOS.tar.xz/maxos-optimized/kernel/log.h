#ifndef MAXOS_LOG_H
#define MAXOS_LOG_H

#include "types.h"

/* Журнал ядра: строки попадают в serial, в текстовую консоль (пока она
 * жива) и в кольцевой буфер, который читает окно «Терминал». */
void klog(const char *fmt, ...);
int  log_count(void);
const char *log_get(int i);   /* 0 = самая старая строка */

#endif
