#include "gui.h"
#include "apps.h"
#include "fb.h"
#include "font.h"
#include "klib.h"
#include "log.h"
#include "mm.h"
#include "sched.h"
#include "rtc.h"
#include "idt.h"
#include "mouse.h"

/* =====================================================================
 *  Композитор Aqua.
 *
 *  Порядок слоёв в кадре:
 *      1. обои (кэш, memcpy)
 *      2. окна в z-порядке (тень -> корпус -> заголовок -> содержимое)
 *      3. Dock
 *      4. строка меню
 *      5. модальные диалоги / beachball
 * =================================================================== */

#define MAX_WINDOWS  12
#define SHADOW_STEPS 6
#define DOCK_PAD     12
#define DOCK_GAP     8
#define DOCK_ICON    48
#define DOCK_BIG     64
#define DOCK_BOTTOM  8

/* ---- палитра ---- */
static const u32 title_act[6]   = { 0xF4F9FE, 0xDAE9FB, 0xB6D6F7, 0x93C1F3, 0x71ACEF, 0x5596E3 };
static const u32 title_inact[6] = { 0xFCFCFC, 0xF4F4F4, 0xECECEC, 0xE4E4E4, 0xDCDCDC, 0xD5D5D5 };

static const u32 traffic_fill[3] = { 0xFF5F57, 0xFFBD2E, 0x28C840 };
static const u32 traffic_rim[3]  = { 0xDF4A41, 0xDEA123, 0x1EAA2C };
static const u32 traffic_ink[3]  = { 0x99382F, 0x9A6B12, 0x1B7A28 };
static const u32 traffic_off[3]  = { 0xE4E4E4, 0xDCDCDC, 0xD8D8D8 };

static const u32 spin_colors[6] = { 0xE8574A, 0xF5A623, 0xF8E71C, 0x7ED321, 0x4A90D9, 0x9B59B6 };

/* яблочко рисуется векторно: gui_apple() ниже */

/* Курсор-стрелка 16x16: msk=1 -- пиксель курсора, img=1 -- чёрный, 0 -- белый */
static const u16 cursor_img[16] = {
    0x8000, 0xc000, 0xa000, 0x9000, 0x8800, 0x8400, 0x8200, 0x8100,
    0x8080, 0x87c0, 0x9400, 0xb200, 0xca00, 0x8900, 0x0700, 0x0400,
};
static const u16 cursor_msk[16] = {
    0x8000, 0xc000, 0xe000, 0xf000, 0xf800, 0xfc00, 0xfe00, 0xff00,
    0xff80, 0xffc0, 0xfc00, 0xfe00, 0xce00, 0x8f00, 0x0700, 0x0400,
};

static const char *wday[7] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
static const char *mon[12] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                               "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

/* ---- состояние ---- */
surf_t screen;
static u32 *canvas, *wallpaper;
static win_t wins[MAX_WINDOWS];
static win_t *zorder[MAX_WINDOWS];
static int nz;
static win_t *focused;
static volatile int lock;
static volatile int dirty = 1;
static int busy_flag, spin_phase;
static u32 spin_ms, clock_ms, beep_until;
static datetime_t wall_clock;
static int clock_ok;
static int shutdown_open;

/* мышь */
static i32 mx, my;
static u8  mbtn;
static win_t *drag_win;
static i32 drag_ox, drag_oy;

/* отложенные действия: выполнять их надо ВНЕ спинлока */
static win_t *pending_close;
static int pending_launch = -1;
static int pending_hog;

enum { ACT_NONE = 0, ACT_SHUTDOWN, ACT_RESTART };
static int pending_action;

/* абсолютные размеры экрана: `screen` во время композита региона
 * временно указывает на под-поверхность, поэтому для layout нужен
 * отдельный неизменяемый размер. */
static u32 abs_w, abs_h;

/*damage-прямоугольники: пересобираем и flush'им только их */
#define MAX_DIRTY 24
static rect_t drects[MAX_DIRTY];
static int ndirty;
static int dirty_full;
static u32 flush_y0, flush_y1;

/* начало координат текущего региона композита */
static i32 cox, coy;

/* кэш раскладки дока (нужен джинну, чтобы знать, куда лететь) */
static int dock_px, dock_py, dock_pw, dock_ph;
static int dock_xs[APP_COUNT + 1], dock_sz[APP_COUNT + 1], dock_n;

/* =====================================================================
 *  Спинлок. Держим недолго: на время рисования окна или кадра.
 * =================================================================== */
void gui_lock(void)
{
    while (__atomic_exchange_n(&lock, 1, __ATOMIC_ACQUIRE))
        sched_yield();
}

void gui_unlock(void)
{
    __atomic_store_n(&lock, 0, __ATOMIC_RELEASE);
}

static void gui_damage(i32 x, i32 y, i32 w, i32 h);
static void gui_damage_full(void);
static void gui_damage_win(win_t *w);
static void gui_damage_dock(void);
static void gui_damage_menubar(void);

void gui_invalidate(void) { gui_damage_full(); }
void gui_set_busy(int on) { busy_flag = on; gui_damage_menubar(); }
int  gui_busy(void) { return busy_flag; }
win_t *gui_focused(void) { return focused; }
int  gui_window_count(void) { return nz; }

void gui_redraw(win_t *w) { if (w) { w->repaint = 1; gui_damage_win(w); } }

void gui_damage_surf(win_t *w, i32 x, i32 y, i32 w2, i32 h2)
{
    if (!w || w2 <= 0 || h2 <= 0) return;
    if (w->pdmg) {
        i32 x0 = MIN(w->pd_x, x), y0 = MIN(w->pd_y, y);
        i32 x1 = MAX(w->pd_x + w->pd_w, x + w2);
        i32 y1 = MAX(w->pd_y + w->pd_h, y + h2);
        w->pd_x = x0; w->pd_y = y0; w->pd_w = x1 - x0; w->pd_h = y1 - y0;
    } else {
        w->pd_x = x; w->pd_y = y; w->pd_w = w2; w->pd_h = h2; w->pdmg = 1;
    }
}

static void gui_damage(i32 x, i32 y, i32 w, i32 h)
{
    if (dirty_full) return;
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (w <= 0 || h <= 0 || x >= (i32)abs_w || y >= (i32)abs_h) return;
    if (x + w > (i32)abs_w) w = (i32)abs_w - x;
    if (y + h > (i32)abs_h) h = (i32)abs_h - y;
    if (ndirty >= MAX_DIRTY) { dirty_full = 1; ndirty = 0; dirty = 1; return; }
    drects[ndirty].x = x; drects[ndirty].y = y;
    drects[ndirty].w = w; drects[ndirty].h = h;
    ndirty++;
    dirty = 1;
    sched_wake_gui();          /* композитор просыпается сразу, а не через 16мс */
}

static void gui_damage_full(void) { dirty_full = 1; ndirty = 0; dirty = 1; }

static void gui_damage_win(win_t *w)
{
    if (!w) return;
    gui_damage(w->x - 16, w->y - 14, w->w + 32, w->h + 30);   /* с запасом на тень */
    w->dmg_x = w->x;
    w->dmg_y = w->y;
}

static void gui_damage_dock(void)
{
    gui_damage(dock_px - 6, dock_py - 36, dock_pw + 12, dock_ph + 44);
}

static void gui_damage_menubar(void)
{
    gui_damage(0, 0, (i32)abs_w, MENU_H + 2);
}

/* =====================================================================
 *  Обои
 * =================================================================== */
/* Мягкое радиальное пятно: alpha спадает как (1-v)^2 от центра к краю.
 * Считается один раз на старте в кэш обоев. */
static void wp_glow(surf_t *w, i32 cx, i32 cy, i32 r, u32 c, u32 a)
{
    i32 x0 = cx - r, y0 = cy - r, bw = r * 2, bh = r * 2;
    if (!gfx_clip(&x0, &y0, &bw, &bh, (i32)w->w, (i32)w->h)) return;
    i32 x1 = x0 + bw, y1 = y0 + bh;
    u64 r2 = (u64)r * r;
    for (i32 y = y0; y < y1; y++) {
        i64 dy = y - cy;
        u32 *row = w->px + (usize)y * w->stride;
        for (i32 x = x0; x < x1; x++) {
            i64 dx = x - cx;
            u64 v = (u64)(dx * dx + dy * dy) * 1000u / r2;
            if (v < 1000) {
                u32 t = (u32)(1000 - v);
                row[x] = mixc(row[x], c, a * t * t / 1000000u);
            }
        }
    }
}

static void build_wallpaper(void)
{
    surf_t w = { wallpaper, screen.w, screen.h, screen.w };
    static const u32 st[5] = { 0x6E9BD4, 0x5B87C6, 0x4A72B4, 0x3A5E9C, 0x2C4A80 };

    gfx_grad_stops(&w, 0, 0, (i32)w.w, (i32)w.h, st, 5);

    /* пинстрайпы -- визитная карточка Aqua */
    for (u32 x = 0; x < w.w; x += 2)
        gfx_blend(&w, (i32)x, 0, 1, (i32)w.h, 0xFFFFFF, 14);

    /* объём: тёплый свет слева-сверху, глубокая тень справа-снизу,
     * холодный блик у верхнего края -- плоскость перестаёт быть плоской */
    wp_glow(&w, (i32)(w.w * 26 / 100), (i32)(w.h * 24 / 100),
            (i32)(w.w * 62 / 100), 0xA8CCF2, 78);
    wp_glow(&w, (i32)(w.w * 60 / 100), (i32)(w.h * 4 / 100),
            (i32)(w.w * 34 / 100), 0xD6E8FB, 52);
    wp_glow(&w, (i32)(w.w * 84 / 100), (i32)(w.h * 86 / 100),
            (i32)(w.w * 66 / 100), 0x12294E, 96);
    wp_glow(&w, (i32)(w.w * 8 / 100),  (i32)(w.h * 92 / 100),
            (i32)(w.w * 46 / 100), 0x1B3A6B, 60);

    /* виньетка по углам */
    u32 cx = w.w / 2, cy = w.h / 2 - 30;
    u32 rx = (w.w * 2) / 3, ry = (w.h * 2) / 3;
    u32 rx2 = rx * rx, ry2 = ry * ry;
    for (u32 y = 0; y < w.h; y++) {
        i32 dy = (i32)y - (i32)cy;
        u32 vy = (u32)(dy * dy) * 1000u / ry2;
        u32 *row = wallpaper + (usize)y * w.stride;
        for (u32 x = 0; x < w.w; x++) {
            i32 dx = (i32)x - (i32)cx;
            u32 v = (u32)(dx * dx) * 1000u / rx2 + vy;
            if (v > 1000) row[x] = mixc(row[x], 0x0A1B33, (v - 1000u) * 70u / 1000u);
        }
    }

    gfx_text_blend(&w, 15, (i32)w.h - 41,
                   "MaXOS. (C) lev445.",
                   0x0A1B33, 90, FONT_UI, 0);
}

/* =====================================================================
 *  Мелкие рисовалки
 * =================================================================== */
static void draw_apple(surf_t *s, i32 x, i32 y, u32 c)
{
    gui_apple(s, x, y, 14, 16, c);
}

static int angle_deg(int dx, int dy)
{
    /* 0..359, 0 = вправо, по часовой стрелке (y вниз) */
    int adx = dx < 0 ? -dx : dx, ady = dy < 0 ? -dy : dy;
    int a = (adx >= ady) ? (45 * ady) / (adx ? adx : 1)
                         : 90 - (45 * adx) / (ady ? ady : 1);
    if (dx >= 0 && dy >= 0) return a;            /* четверть 1 */
    if (dx <  0 && dy >= 0) return 180 - a;      /* четверть 2 */
    if (dx <  0 && dy <  0) return 180 + a;      /* четверть 3 */
    return 360 - a;                              /* четверть 4 */
}

static void draw_spinner(surf_t *s, int cx, int cy, int r, int phase)
{
    int r2 = r * r;
    for (int dy = -r; dy <= r; dy++) {
        for (int dx = -r; dx <= r; dx++) {
            int d2 = dx * dx + dy * dy;
            if (d2 > r2 || d2 < 9) continue;
            int idx = (angle_deg(dx, dy) / 60 + phase) % 6;
            u32 c = spin_colors[idx];
            i32 x = cx + dx, y = cy + dy;
            if (x < 0 || y < 0 || x >= (i32)s->w || y >= (i32)s->h) continue;
            s->px[y * s->stride + x] = c;
        }
    }
    /* белое колечко и серединка */
    for (int dy = -r - 1; dy <= r + 1; dy++)
        for (int dx = -r - 1; dx <= r + 1; dx++) {
            int d2 = dx * dx + dy * dy;
            if (d2 <= (r + 1) * (r + 1) && d2 > r2) {
                i32 x = cx + dx, y = cy + dy;
                if (x < 0 || y < 0 || x >= (i32)s->w || y >= (i32)s->h) continue;
                s->px[y * s->stride + x] = mixc(s->px[y * s->stride + x], 0xFFFFFF, 200);
            }
        }
    gfx_circle(s, cx, cy, 2, 0xFFFFFF);
}

/* =====================================================================
 *  Заголовок окна
 * =================================================================== */
static u32 grad_at(const u32 *stops, int n, int j, int h)
{
    if (h <= 1) return stops[0];
    u32 t = (u32)(j * 256 * (n - 1)) / (u32)(h - 1);
    u32 seg = t >> 8;
    if (seg >= (u32)(n - 1)) seg = (u32)(n - 2);
    return mixc(stops[seg], stops[seg + 1], t - (seg << 8));
}

static void draw_traffic(win_t *w)
{
    int d = 13, y = w->y - coy + (WIN_TITLE_H - d) / 2, r = d / 2;
    for (int i = 0; i < 3; i++) {
        int x = w->x - cox + 8 + i * 19, cx = x + r, cy = y + r;
        if (!w->focused) {
            gfx_aa_circle(&screen, cx, cy, r, traffic_off[i]);
            gfx_aa_circle(&screen, cx, cy, r - 1, 0xEDEDED);
            continue;
        }
        gfx_aa_circle(&screen, cx, cy, r, traffic_rim[i]);
        gfx_aa_circle(&screen, cx, cy, r - 1, traffic_fill[i]);
        /* блик */
        gfx_aa_circle_blend(&screen, cx, cy - 2, r - 4, 0xFFFFFF, 90);
        /* глиф */
        if (i == 0) {
            gfx_line(&screen, cx - 3, cy - 3, cx + 3, cy + 3, traffic_ink[0]);
            gfx_line(&screen, cx - 2, cy - 3, cx + 4, cy + 3, traffic_ink[0]);
            gfx_line(&screen, cx + 3, cy - 3, cx - 3, cy + 3, traffic_ink[0]);
            gfx_line(&screen, cx + 2, cy - 3, cx - 4, cy + 3, traffic_ink[0]);
        } else if (i == 1) {
            gfx_fill(&screen, cx - 3, cy, 7, 2, traffic_ink[1]);
        } else {
            gfx_fill_tri(&screen, cx - 4, cy - 4, cx + 1, cy - 4, cx - 4, cy + 1, traffic_ink[2]);
            gfx_fill_tri(&screen, cx + 4, cy + 4, cx - 1, cy + 4, cx + 4, cy - 1, traffic_ink[2]);
        }
    }
}

static void tb_row_aa(i32 x, i32 y, i32 W, i32 j, i32 r, u32 c)
{
    i32 in = (j < r) ? gfx_corner_inset(j, r) : 0;
    gfx_hline(&screen, x + in, y + j, W - 2 * in, c);
    if (j >= r) return;
    for (i32 d = 1; d <= 2; d++) {
        u32 cov = gfx_rr_cov(x, y, W, 4 * r, r, x + in - d, y + j);
        if (!cov) break;
        gfx_blend(&screen, x + in - d, y + j, 1, 1, c, cov * 16);
    }
    for (i32 d = 1; d <= 2; d++) {
        u32 cov = gfx_rr_cov(x, y, W, 4 * r, r, x + W - 1 - in + d, y + j);
        if (!cov) break;
        gfx_blend(&screen, x + W - 1 - in + d, y + j, 1, 1, c, cov * 16);
    }
}

static void draw_titlebar(win_t *w)
{
    int x = w->x - cox, y = w->y - coy, W = w->w;
    const int r = 8;

    const int half = WIN_TITLE_H / 2;

    if (w->style == WIN_TERM) {
        static const u32 st[3] = { 0x6A6A6A, 0x4A4A4A, 0x333333 };
        for (int j = 0; j < WIN_TITLE_H; j++) {
            tb_row_aa(x, y, W, j, r, grad_at(st, 3, j, WIN_TITLE_H));
        }
        /* стеклянный блик сверху и слабый глянец верхней половины */
        gfx_blend(&screen, x + r - 2, y, W - 2 * (r - 2), 1, 0xFFFFFF, 80);
        for (int j = 1; j < half; j++) {
            int in = (j < r) ? gfx_corner_inset(j, r) : 0;
            gfx_blend(&screen, x + in, y + j, W - 2 * in, 1, 0xFFFFFF,
                      26u - (u32)j * 14u / (u32)half);
        }
    } else if (w->style == WIN_METAL) {
        /* «шлифованный металл»: база + горизонтальные штрихи + пинстрайп */
        for (int j = 0; j < WIN_TITLE_H; j++) {
            u32 c = grad_at((const u32[]){ 0xFDFDFD, 0xEDEDED, 0xDDDDDD, 0xD0D0D0 },
                            4, j, WIN_TITLE_H);
            tb_row_aa(x, y, W, j, r, c);
        }
        for (int j = 0; j < WIN_TITLE_H; j++) {
            u32 a = (u32)(((j * 37) % 11) * 3);
            if (a) {
                int in = (j < r) ? gfx_corner_inset(j, r) : 0;
                gfx_blend(&screen, x + in, y + j, W - 2 * in, 1,
                          (j & 1) ? 0x000000 : 0xFFFFFF, a);
            }
        }
        for (int i = 0; i < W; i += 2)
            gfx_blend(&screen, x + i, y, 1, WIN_TITLE_H, 0xFFFFFF, 16);
    } else {
        const u32 *st = w->focused ? title_act : title_inact;
        for (int j = 0; j < WIN_TITLE_H; j++) {
            tb_row_aa(x, y, W, j, r, grad_at(st, 6, j, WIN_TITLE_H));
        }
        /* глянцевая верхняя половина с резким срезом -- сигнатура Aqua */
        for (int j = 0; j < half; j++) {
            int in = (j < r) ? gfx_corner_inset(j, r) : 0;
            u32 a = w->focused ? (60u - (u32)j * 26u / (u32)half)
                               : (42u - (u32)j * 18u / (u32)half);
            gfx_blend(&screen, x + in, y + j, W - 2 * in, 1, 0xFFFFFF, a);
        }
        gfx_blend(&screen, x, y + half, W, 1,
                  w->focused ? 0x2F66B0 : 0x9A9A9A, 60);
        /* верхний блик 1px */
        gfx_blend(&screen, x + r - 2, y, W - 2 * (r - 2), 1, 0xFFFFFF,
                  w->focused ? 160 : 120);
        /* тонкие пинстрайпы на активном заголовке */
        if (w->focused)
            for (int i = 0; i < W; i += 2)
                gfx_blend(&screen, x + i, y, 1, WIN_TITLE_H, 0xFFFFFF, 12);
    }

    /* разделитель под заголовком */
    u32 edge = w->focused ? (w->style == WIN_TERM ? 0x1A1A1A : 0x3A76C4) : 0xB4B4B4;
    gfx_hline(&screen, x, y + WIN_TITLE_H - 1, W, edge);

    draw_traffic(w);

    /* название окна */
    i32 tw = (i32)gfx_text_width(w->title, FONT_UI);
    i32 tx = x + (W - tw) / 2;
    i32 ty = y + (WIN_TITLE_H - (int)fonts[FONT_UI].h) / 2 + 1;
    if (tx < x + 70) tx = x + 70;
    if (w->focused) {
        if (w->style == WIN_AQUA) {
            gfx_text(&screen, tx + 1, ty + 1, w->title, 0x2C5F9E, FONT_UI, 1);
            gfx_text(&screen, tx, ty, w->title, 0xFFFFFF, FONT_UI, 1);
        } else {
            gfx_text(&screen, tx + 1, ty + 1, w->title, 0xFFFFFF, FONT_UI, 1);
            gfx_text(&screen, tx, ty, w->title, 0x2A2A2A, FONT_UI, 1);
        }
    } else {
        gfx_text(&screen, tx, ty, w->title, w->style == WIN_TERM ? 0x9A9A9A : 0x777777,
                 FONT_UI, 0);
    }
}

/* ---------------------------------------------------------------------
 *  Мягкая тень окна: сепарабельное затухание alpha(x,y) = fx(x)*fy(y).
 *  Профиль sh_prof[] -- квадратичный спад к нулю за SHADOW_R пикселей.
 *  Полосы сверху/снизу блендятся целыми строками (constant alpha),
 *  боковины и углы -- поточечно, но их всего SHADOW_R пикселей шириной.
 * ------------------------------------------------------------------- */
#define SHADOW_R 14
#define SHADOW_A 110
#define SHADOW_DY 4
static u8 sh_prof[SHADOW_R];

static void shadow_init(void)
{
    for (int i = 0; i < SHADOW_R; i++) {
        int t = SHADOW_R - i;
        sh_prof[i] = (u8)(SHADOW_A * t * t / (SHADOW_R * SHADOW_R));
    }
}

static inline void px_blend(i32 xx, i32 yy, u32 a)
{
    if (a == 0) return;
    if ((u32)xx >= screen.w || (u32)yy >= screen.h) return;
    u32 *p = &screen.px[(usize)yy * screen.stride + (u32)xx];
    *p = mixc(*p, 0x000000, a);
}

static void draw_shadow(int x, int y, int W, int H)
{
    const int S = SHADOW_R;
    /* верхняя и нижняя полосы: alpha постоянна вдоль строки */
    for (int j = 0; j < S; j++) {
        gfx_blend(&screen, x, y + SHADOW_DY - S + j, W, 1, 0x000000,
                  sh_prof[S - 1 - j]);
        gfx_blend(&screen, x, y + H + SHADOW_DY + j, W, 1, 0x000000,
                  sh_prof[j]);
    }
    /* боковины в теле окна */
    for (int d = 1; d <= S; d++) {
        u32 a = sh_prof[d - 1];
        gfx_blend(&screen, x - d, y + SHADOW_DY, 1, H, 0x000000, a);
        gfx_blend(&screen, x + W - 1 + d, y + SHADOW_DY, 1, H, 0x000000, a);
    }
    /* четыре угловых квадрата: произведение профилей */
    for (int j = 0; j < S; j++) {
        u32 av = sh_prof[S - 1 - j], bv = sh_prof[j];
        i32 yt = y + SHADOW_DY - S + j;
        i32 yb = y + H + SHADOW_DY + j;
        for (int d = 1; d <= S; d++) {
            u32 ah = sh_prof[d - 1];
            px_blend(x - d,         yt, av * ah / 256);
            px_blend(x + W - 1 + d, yt, av * ah / 256);
            px_blend(x - d,         yb, bv * ah / 256);
            px_blend(x + W - 1 + d, yb, bv * ah / 256);
        }
    }
}

static void draw_window(win_t *w)
{
    int x = w->x - cox, y = w->y - coy, W = w->w, H = w->h;

    draw_shadow(x, y, W, H);

    /* корпус */
    gfx_aa_round(&screen, x, y, W, H, 8,
                 w->focused ? 0xFFFFFF : 0xF6F6F6);

    draw_titlebar(w);

    /* содержимое */
    gfx_blit(&screen, w->buf, (u32)w->cw, (u32)w->ch, x, y + WIN_TITLE_H, w->cw, w->ch);

    /* обводка: снаружи волоссяная тёмная, изнутри светлый блик */
    gfx_aa_round_outline(&screen, x, y, W, H, 8,
                         w->focused ? 0x2E4A6E : 0x6E6E6E, 150);
}

/* =====================================================================
 *  Иконки приложений: суперсэмплинг 4x + box-даунскейл с альфой
 *
 *  Иконка рисуется обычными примитивами в скретч в 4 раза больше, затем
 *  сжимается box-фильтром: каждый финальный пиксель накапливает 16
 *  сэмплов, а доля сэмплов вне силуэта (фон GFX_KEY) становится альфой
 *  пикселя. Лесенка исчезает со всех краёв сразу, включая внутренние
 *  элементы (круги, столбики, глифы). Результат кэшируется на иконку и
 *  размер: magnification дока меняется редко, а blit -- каждый кадр.
 * =================================================================== */
#define ICON_SS   4
#define ICON_MAX  80
static u32 *icon_ss;                       /* (ICON_MAX*ICON_SS)^2, фон GFX_KEY */
static u32 *icon_px[APP_COUNT + 1];        /* кэш даунскейла: цвет */
static u8  *icon_al[APP_COUNT + 1];        /* ...и альфа 0..256 */
static int  icon_have[APP_COUNT + 1];      /* закэшированный размер */

/* цифра семисегментником: масштабируется куда угодно, в отличие шрифта */
static void seg_digit(surf_t *s, int x, int y, int w, int h, int d, u32 c)
{
    static const u8 segs[10] = { 0x3F, 0x06, 0x5B, 0x4F, 0x66,
                                 0x6D, 0x7D, 0x07, 0x7F, 0x6F };
    u8 m = segs[d % 10];
    int t = h / 10 ? h / 10 : 1;
    if (m & 0x01) gfx_fill(s, x + t, y, w - 2 * t, t, c);
    if (m & 0x02) gfx_fill(s, x + w - t, y + t, t, h / 2 - t, c);
    if (m & 0x04) gfx_fill(s, x + w - t, y + h / 2, t, h / 2 - t, c);
    if (m & 0x08) gfx_fill(s, x + t, y + h - t, w - 2 * t, t, c);
    if (m & 0x10) gfx_fill(s, x, y + h / 2, t, h / 2 - t, c);
    if (m & 0x20) gfx_fill(s, x, y + t, t, h / 2 - t, c);
    if (m & 0x40) gfx_fill(s, x + t, y + h / 2 - t / 2, w - 2 * t, t, c);
}

static void draw_app_icon(surf_t *s, int item, int size)
{
    int r = size / 5;
    gfx_fill(s, 0, 0, size, size, GFX_KEY);   /* всё, что равно ключу, -- прозрачно */

    switch (item) {
    case APP_ABOUT:
        gfx_round(s, 0, 0, size, size, r, 0x3D7CC8);
        gfx_grad_v(s, 1, 1, size - 2, size - 2, 0x6FA9E8, 0x2C5F9E);
        /* буква i: точка и скруглённый стебель */
        gfx_circle(s, size / 2, size / 4, size / 10, 0xFFFFFF);
        gfx_round(s, size / 2 - size / 14, size / 2 - size / 10,
                  size / 7, size / 2 + size / 10, size / 14, 0xFFFFFF);
        break;
    case APP_TERMINAL: {
        gfx_round(s, 0, 0, size, size, r, 0x2B2B2B);
        gfx_grad_v(s, 1, 1, size - 2, size - 2, 0x4A4A4A, 0x141414);
        /* prompt «>_» штрихами: масштабируется, в отличие от шрифта */
        int px = size / 5, py = size / 2, a = size / 5, th = size / 16 + 1;
        for (int k = 0; k < th; k++) {
            gfx_line(s, px, py - a / 2 + k, px + a / 2, py + k, 0x7CFC7C);
            gfx_line(s, px, py + a / 2 + k, px + a / 2, py + k, 0x7CFC7C);
            gfx_line(s, px + a, py + a / 2 + k, px + a + a, py + a / 2 + k, 0x7CFC7C);
        }
        break;
    }
    case APP_ACTIVITY:
        gfx_round(s, 0, 0, size, size, r, 0xF4F6F8);
        gfx_grad_v(s, 1, 1, size - 2, size - 2, 0xFFFFFF, 0xD8DEE6);
        {
            int bw = size / 8, gap = size / 12;
            int hs[4];
            hs[0] = size / 3; hs[1] = size / 2; hs[2] = size / 5; hs[3] = size * 2 / 3;
            int x = size / 2 - (4 * bw + 3 * gap) / 2;
            for (int i = 0; i < 4; i++) {
                u32 c = (i == 3) ? 0xE8574A : ((i == 1) ? 0x4A90D9 : 0x7ED321);
                /* столбик-пилюля: скруглённая вершинка читается «иконочно» */
                gfx_round(s, x, size - size / 6 - hs[i], bw, hs[i], bw / 2, c);
                gfx_grad_v(s, x, size - size / 6 - hs[i], bw, hs[i] / 2,
                           mixc(c, 0xFFFFFF, 90), c);
                x += bw + gap;
            }
            gfx_hline(s, size / 8, size - size / 6, size * 3 / 4, 0x6A7A8A);
        }
        break;
    case APP_BOUNCE: {
        gfx_round(s, 0, 0, size, size, r, 0xF5A623);
        gfx_grad_v(s, 1, 1, size - 2, size - 2, 0xFBCB5A, 0xE8574A);
        int br = size / 4;
        gfx_circle_blend(s, size / 2, size * 3 / 4, size / 5, 0x000000, 50);
        gfx_circle(s, size / 2, size / 2, br, 0xFFFFFF);
        /* пляжный мяч: три доли с радиальными швами */
        for (i32 j = -br; j <= br; j++)
            for (i32 i = -br; i <= br; i++) {
                if (i * i + j * j > br * br) continue;
                i32 px_ = size / 2 + i, py_ = size / 2 + j;
                if (px_ < 0 || py_ < 0 || px_ >= size || py_ >= size) continue;
                int a = angle_deg(i, j);
                u32 cc = 0xFFFFFF;
                if (a >= 115 && a <= 245) cc = 0xE8574A;
                else if (a <= 65 || a >= 295) cc = 0x4A90D9;
                if (cc != 0xFFFFFF)
                    s->px[(u32)py_ * (u32)size + (u32)px_] = cc;
            }
        gfx_circle_blend(s, size / 2 - size / 12, size / 2 - size / 12,
                         size / 10, 0xBFE4FF, 220);
        break;
    }
    case APP_CALC:
        gfx_round(s, 0, 0, size, size, r, 0xE8E8E8);
        gfx_grad_v(s, 1, 1, size - 2, size - 2, 0xFDFDFD, 0xC4C8CC);
        gfx_round(s, size / 8, size / 8, size * 3 / 4, size / 5, size / 20, 0x2C3E50);
        {
            int dw = size / 8, dh = size / 5 - size / 12;
            int dx0 = size / 2 - dw - size / 28;
            seg_digit(s, dx0, size / 8 + size / 24, dw, dh, 4, 0x9BE89B);
            seg_digit(s, dx0 + dw + size / 14, size / 8 + size / 24, dw, dh,
                      2, 0x9BE89B);
        }
        for (int row = 0; row < 3; row++)
            for (int col = 0; col < 3; col++) {
                int bx = size / 8 + col * (size * 3 / 4 / 3);
                int by = size / 2 + row * (size / 8);
                u32 c = (col == 2) ? 0xF5A623 : 0xFFFFFF;
                gfx_round(s, bx + 1, by, size * 3 / 4 / 3 - 3, size / 12,
                          size / 40, c);
                if (c == 0xFFFFFF)
                    gfx_round_outline(s, bx + 1, by, size * 3 / 4 / 3 - 3,
                                      size / 12, size / 40, 0xB8BEC4, 160);
            }
        break;
    default: /* корзина */
        gfx_round(s, size / 4, size / 4 + size / 14, size / 2, size * 3 / 5,
                  size / 10, 0xC8D2DC);
        gfx_grad_v(s, size / 4, size / 4 + size / 14, size / 2, size * 3 / 5,
                   0xDDE6EE, 0xAEBCC8);
        gfx_round(s, size / 4 - size / 20, size / 4, size / 2 + size / 10,
                  size / 12, size / 24, 0x8A98A8);
        for (int i = 1; i < 4; i++)
            gfx_blend(s, size / 4 + i * size / 8 - size / 40,
                      size / 3 + size / 12, size / 24, size * 5 / 12,
                      0x6A7888, 130);
        break;
    }

    /* углы вне скругления -- в прозрачность: силуэт иконки круглый,
     * а градиенты выше мазали квадратом */
    for (int c = 0; c < 4; c++) {
        i32 cx = (c & 1) ? size - 1 - r : r;
        i32 cy = (c & 2) ? size - 1 - r : r;
        for (i32 j = cy - r; j <= cy + r; j++) {
            if (j < 0 || j >= size) continue;
            for (i32 i = cx - r; i <= cx + r; i++) {
                if (i < 0 || i >= size) continue;
                i32 dx = i - cx, dy = j - cy;
                if ((c & 1) ? (dx < 0) : (dx > 0)) continue;
                if ((c & 2) ? (dy < 0) : (dy > 0)) continue;
                if (dx * dx + dy * dy > r * r)
                    s->px[(u32)j * (u32)size + (u32)i] = GFX_KEY;
            }
        }
    }

    /* общий для всех глянцевый блик и обводка */
    if (item != APP_COUNT) {
        gfx_round_blend(s, 1, 1, size - 2, size / 2, r, 0xFFFFFF, 46);
        gfx_round_outline(s, 0, 0, size, size, r, 0x000000, 70);
        gfx_round_outline(s, 1, 1, size - 2, size - 2, r - 1, 0xFFFFFF, 60);
    }
}

/* ---- даунскейл 4x -> 1x с альфой и кэш ---- */
static void icon_bake(int item, int size)
{
    int s4 = size * ICON_SS;
    surf_t ss = { icon_ss, (u32)s4, (u32)s4, (u32)s4 };
    draw_app_icon(&ss, item, s4);
    u32 *px = icon_px[item];
    u8 *al = icon_al[item];
    for (int j = 0; j < size; j++) {
        for (int i = 0; i < size; i++) {
            u32 r = 0, g = 0, b = 0, hits = 0;
            for (int ty = 0; ty < ICON_SS; ty++) {
                const u32 *row = &icon_ss[(usize)(j * ICON_SS + ty) * (usize)s4
                                          + (u32)(i * ICON_SS)];
                for (int tx = 0; tx < ICON_SS; tx++) {
                    u32 p = row[tx];
                    if (p == GFX_KEY) continue;
                    r += R(p); g += G(p); b += B(p); hits++;
                }
            }
            u32 o = (u32)j * (u32)size + (u32)i;
            if (hits) {
                px[o] = rgb((u8)(r / hits), (u8)(g / hits), (u8)(b / hits));
                /* альфа 0..255 (256 в u8 не влезает -- обрежется в 0!) */
                al[o] = (u8)((hits * 255 + ICON_SS * ICON_SS / 2)
                             / (ICON_SS * ICON_SS));
            } else {
                al[o] = 0;
            }
        }
    }
    icon_have[item] = size;
}

/* alpha 0..256; reflect=1: отрисовать отражение высотой rh с затуханием */
static void icon_blit_a(int item, int size, i32 x, i32 y, u32 alpha,
                        int reflect, i32 rh)
{
    if (icon_have[item] != size) icon_bake(item, size);
    const u32 *px = icon_px[item];
    const u8 *al = icon_al[item];
    i32 n = reflect ? rh : size;
    for (i32 j = 0; j < n; j++) {
        i32 yy = y + j;
        if (yy < 0 || yy >= (i32)screen.h) continue;
        u32 fade = alpha;
        if (reflect) fade = (alpha * (u32)(rh - j)) / (u32)rh;
        if (!fade) continue;
        i32 sj = reflect ? (size - 1 - j) : j;
        u32 *dst = &screen.px[(usize)yy * screen.stride];
        const u32 *srow = &px[(u32)sj * (u32)size];
        const u8 *arow = &al[(u32)sj * (u32)size];
        for (i32 i = 0; i < size; i++) {
            i32 xx = x + i;
            if (xx < 0 || xx >= (i32)screen.w) continue;
            u32 a = ((u32)arow[i] * fade) >> 8;
            if (!a) continue;
            dst[xx] = (a >= 256) ? srow[i] : mixc(dst[xx], srow[i], a);
        }
    }
}

/* ---- яблочко: векторный силуэт (объединение/разность эллипсов), 4x ---- */
static u32 isqrt32(u32 n)
{
    u32 r = 0, bit = 1u << 30;
    while (bit > n) bit >>= 2;
    while (bit) {
        if (n >= r + bit) { n -= r + bit; r = (r >> 1) + bit; }
        else r >>= 1;
        bit >>= 2;
    }
    return r;
}

static void ss_ellipse(surf_t *t, i32 cu, i32 cv, i32 ru, i32 rv, u32 c)
{
    for (i32 y = cv - rv; y <= cv + rv; y++) {
        if (y < 0 || y >= (i32)t->h) continue;
        i32 dy = y - cv;
        u32 q = isqrt32((u32)ru * ru * (u32)(rv * rv - dy * dy) / ((u32)rv * rv));
        for (i32 x = cu - (i32)q; x <= cu + (i32)q; x++)
            if (x >= 0 && x < (i32)t->w) t->px[(usize)y * t->stride + (u32)x] = c;
    }
}

/* u, v, r -- в промилях ширины/высоты; r<0 = вычесть */
static const i32 apple_geo[10][3] = {
    { 350, 500,  240 }, { 650, 500,  240 }, { 500, 620,  300 },
    { 360, 680,  220 }, { 640, 680,  220 }, { 500, 460,  260 },
    { 500, 185, -105 }, { 1020, 560, -300 },
    { 615, 115,   95 }, { 700,  60,   65 },
};

void gui_apple(surf_t *s, i32 x, i32 y, i32 w, i32 h, u32 c)
{
    i32 sw = w * ICON_SS, sh = h * ICON_SS;
    if (sw > ICON_MAX * ICON_SS) sw = ICON_MAX * ICON_SS;
    if (sh > ICON_MAX * ICON_SS) sh = ICON_MAX * ICON_SS;
    surf_t t = { icon_ss, (u32)sw, (u32)sh, (u32)sw };
    gfx_fill(&t, 0, 0, sw, sh, GFX_KEY);
    for (u32 i = 0; i < sizeof(apple_geo) / sizeof(apple_geo[0]); i++) {
        i32 rr = apple_geo[i][2];
        i32 ar = rr < 0 ? -rr : rr;
        i32 cu = (i32)(((i64)sw * apple_geo[i][0]) / 1000);
        i32 cv = (i32)(((i64)sh * apple_geo[i][1]) / 1000);
        i32 ru = (i32)(((i64)sw * ar) / 1000);
        i32 rv = (i32)(((i64)sh * ar) / 1000);
        ss_ellipse(&t, cu, cv, ru, rv, (rr < 0) ? GFX_KEY : 0xFFFFFF);
    }
    for (i32 j = 0; j < h; j++) {
        i32 yy = y + j;
        if (yy < 0 || yy >= (i32)s->h) continue;
        for (i32 i = 0; i < w; i++) {
            i32 xx = x + i;
            if (xx < 0 || xx >= (i32)s->w) continue;
            u32 hits = 0;
            for (i32 ty = 0; ty < ICON_SS; ty++) {
                const u32 *row = &icon_ss[(usize)(j * ICON_SS + ty) * (usize)sw
                                          + (u32)(i * ICON_SS)];
                for (i32 tx = 0; tx < ICON_SS; tx++)
                    if (row[tx] != GFX_KEY) hits++;
            }
            if (!hits) continue;
            u32 a = hits * (256 / (ICON_SS * ICON_SS));
            u32 *p = &s->px[(usize)yy * s->stride + (u32)xx];
            *p = (a >= 256) ? c : mixc(*p, c, a);
        }
    }
}

static int dock_item_size(int i)
{
    int sel = (focused && focused->app >= 0) ? focused->app : -1;
    int d = (sel < 0) ? 99 : (i > sel ? i - sel : sel - i);
    if (d == 0) return DOCK_BIG;
    if (d == 1) return (DOCK_ICON + DOCK_BIG) / 2;
    return DOCK_ICON;
}

static int dock_bounce_offset(void)
{
    if (!app_bounce_ms) return 0;
    u32 e = app_bounce_ms % 300;
    return (e < 150) ? (int)(e * 12 / 150) : (int)((300 - e) * 12 / 150);
}

static void dock_layout(void)
{
    dock_n = APP_COUNT + 1;
    int total = 0;
    for (int i = 0; i < dock_n; i++) {
        dock_sz[i] = (i == APP_COUNT) ? DOCK_ICON : dock_item_size(i);
        total += dock_sz[i] + (i ? DOCK_GAP : 0);
    }
    dock_pw = total + DOCK_PAD * 2 + 10;      /* +10 под разделитель */
    dock_ph = DOCK_PANEL_H;
    /* ВАЖНО: layout считаем по абсолюту: во время композита региона
     * `screen` -- под-поверхность, и центрирование по ней уводило бы
     * dock в центрDamage-прямоугольника. */
    dock_px = ((i32)abs_w - dock_pw) / 2;
    dock_py = (i32)abs_h - dock_ph - DOCK_BOTTOM;

    int x = dock_px + DOCK_PAD;
    for (int i = 0; i < dock_n; i++) {
        if (i == APP_COUNT) x += 10;          /* разделитель перед корзиной */
        dock_xs[i] = x;
        x += dock_sz[i] + DOCK_GAP;
    }
}

static void draw_dock(void)
{
    i32 ox = cox, oy = coy;
    i32 dpx = dock_px - ox, dpy = dock_py - oy;
    dock_layout();
    dpx = dock_px - ox; dpy = dock_py - oy;

    /* стеклянная подложка */
    gfx_aa_round_blend(&screen, dpx - 3, dpy - 3, dock_pw + 6, dock_ph + 6,
                       20, 0x0A1B33, 60);
    gfx_aa_round_blend(&screen, dpx, dpy, dock_pw, dock_ph, 18, 0xBBD6F2, 110);
    gfx_aa_round_blend(&screen, dpx + 2, dpy + 1, dock_pw - 4, dock_ph / 2,
                       17, 0xFFFFFF, 46);
    gfx_aa_round_outline(&screen, dpx, dpy, dock_pw, dock_ph, 18,
                         0xFFFFFF, 200);

    /* разделитель перед корзиной */
    int sep = dock_xs[APP_COUNT] - DOCK_GAP / 2 - 5 - ox;
    gfx_blend(&screen, sep, dpy + 12, 1, dock_ph - 24, 0x2A4A72, 70);
    gfx_blend(&screen, sep + 1, dpy + 12, 1, dock_ph - 24, 0xFFFFFF, 90);

    int bounce = dock_bounce_offset();
    for (int i = 0; i < dock_n; i++) {
        int sz = dock_sz[i];
        int x = dock_xs[i] - ox;
        int y = dpy + dock_ph - 22 - sz;
        if (i < APP_COUNT && focused && focused->app == i) y -= bounce;

        icon_blit_a(i, sz, x, y, 256, 0, 0);
        icon_blit_a(i, sz, x, y + sz + 1, 110, 1, MIN(14, sz / 3));
        if (i < APP_COUNT && app_find(i))
            gfx_aa_circle(&screen, x + sz / 2, dpy + dock_ph - 9, 2, 0xFFFFFF);
    }

    if (focused && focused->app >= 0) {
        const char *nm = app_names[focused->app];
        i32 tw = (i32)gfx_text_width(nm, FONT_UI);
        int bx = dock_xs[focused->app] - ox + dock_sz[focused->app] / 2 - tw / 2 - 9;
        int by = dpy - 30;
        gfx_aa_round_blend(&screen, bx, by, tw + 18, 24, 8, 0x1A1A1A, 200);
        gfx_aa_round_outline(&screen, bx, by, tw + 18, 24, 8, 0xFFFFFF, 120);
        gfx_text(&screen, bx + 9, by + 4, nm, 0xFFFFFF, FONT_UI, 0);
        gfx_fill_tri(&screen, bx + tw / 2 + 4, by + 24, bx + tw / 2 + 14, by + 24,
                     bx + tw / 2 + 9, by + 30, 0x1A1A1A);
    }
}

/* =====================================================================
 *  Строка меню
 * =================================================================== */
static void draw_menubar(void)
{
    i32 ox = cox, oy = coy;
    static const u32 st[4] = { 0xF8FBFF, 0xDFEAF9, 0xC8DBF3, 0xB6CEEC };
    gfx_grad_stops(&screen, -ox, -oy, (i32)abs_w, MENU_H, st, 4);
    for (i32 x = -(ox & 1); x < (i32)screen.w; x += 2)
        gfx_blend(&screen, x, -oy, 1, MENU_H, 0xFFFFFF, 18);
    gfx_hline(&screen, -ox, MENU_H - 1 - oy, (i32)abs_w, 0x8FA9C8);
    gfx_blend(&screen, -ox, MENU_H - oy, (i32)abs_w, 1, 0x000000, 46);

    int ty = (MENU_H - (int)fonts[FONT_UI].h) / 2 + 1 - oy;
    //draw_apple(&screen, 9 - ox, (MENU_H - 16) / 2 - oy, 0x1F2933);

    int x = 4 + 5 + 5 - ox;
    const char *name = (focused && focused->app >= 0) ? app_names[focused->app]
                                                      : "MaXOS Desktop";
    gfx_text(&screen, x, ty, name, 0x101820, FONT_UI, 1);
    x += (int)gfx_text_width(name, FONT_UI) + 20;
    const char *menus = (focused && focused->app >= 0) ? app_menus[focused->app]
                                                       : "MaXOS is beta";
    gfx_text(&screen, x, ty, menus, 0x101820, FONT_UI, 0);

    char buf[96];
    if (clock_ok)
        ksnprintf(buf, sizeof(buf), "%s %u %s   %02u:%02u",
                  wday[wall_clock.weekday % 7], wall_clock.day,
                  mon[(wall_clock.month - 1) % 12], wall_clock.hour, wall_clock.min);
    else
        ksnprintf(buf, sizeof(buf), "--:--");
    char left[48];
    ksnprintf(left, sizeof(left), "%d tasks   %u%% CPU",
              sched_count(), (unsigned)sched_load());

    int tw = (int)gfx_text_width(buf, FONT_UI);
    int lw = (int)gfx_text_width(left, FONT_UI);
    int rx = (int)abs_w - 12 - tw - ox;
    gfx_text(&screen, rx, ty, buf, 0x101820, FONT_UI, 0);
    rx -= lw + 22;
    gfx_text(&screen, rx, ty, left, 0x101820, FONT_UI, 0);
    gfx_blend(&screen, rx + lw + 10, 5 - oy, 1, MENU_H - 10, 0x6A86A8, 120);

    if (busy_flag)
        draw_spinner(&screen, rx - 20, MENU_H / 2 - oy, 8, spin_phase);
}

/* =====================================================================
 *  Диалог выключения
 * =================================================================== */
static void dialog_rect(i32 *x, i32 *y, i32 *w, i32 *h)
{
    *w = 420; *h = 150;
    *x = ((i32)abs_w - *w) / 2;
    *y = ((i32)abs_h - *h) / 2 - 20;
}

static void aqua_button(int x, int y, int w, int h, const char *label, int def)
{
    if (def) {
        static const u32 st[3] = { 0x8FC1F5, 0x5C9BE4, 0x3D7CC8 };
        gfx_grad_stops(&screen, x, y, w, h, st, 3);
        gfx_round_outline(&screen, x, y, w, h, h / 2, 0x2C5F9E, 256);
        gfx_round_outline(&screen, x - 2, y - 2, w + 4, h + 4, h / 2 + 2, 0x9FC9F2, 160);
        gfx_blend(&screen, x + 3, y + 2, w - 6, h / 3, 0xFFFFFF, 70);
    } else {
        static const u32 st[3] = { 0xFFFFFF, 0xF0F0F0, 0xDCDCDC };
        gfx_grad_stops(&screen, x, y, w, h, st, 3);
        gfx_round_outline(&screen, x, y, w, h, h / 2, 0x9A9A9A, 256);
        gfx_blend(&screen, x + 3, y + 2, w - 6, h / 3, 0xFFFFFF, 120);
    }
    i32 tw = (i32)gfx_text_width(label, FONT_UI);
    gfx_text(&screen, x + (w - tw) / 2, y + (h - (int)fonts[FONT_UI].h) / 2 + 1,
             label, def ? 0xFFFFFF : 0x1A1A1A, FONT_UI, def);
}

static void draw_shutdown_dialog(void)
{
    i32 ox = cox, oy = coy;
    gfx_blend(&screen, -ox, MENU_H - oy, (i32)abs_w, (i32)abs_h - MENU_H, 0x000000, 70);

    i32 w, h, x, y;
    dialog_rect(&x, &y, &w, &h);
    x -= ox; y -= oy;

    for (int i = SHADOW_STEPS; i >= 1; i--)
        gfx_round_outline(&screen, x - i * 2, y - i + 3, w + i * 4, h + i * 2,
                          10 + i, 0x000000, (u32)(50 * (SHADOW_STEPS - i + 1) / SHADOW_STEPS));

    gfx_aa_round(&screen, x, y, w, h, 10, 0xF4F4F4);
    gfx_grad_v(&screen, x + 1, y + 1, w - 2, 34, 0xFBFBFB, 0xEDEDED);
    gfx_hline(&screen, x, y + 36, w, 0xC8C8C8);
    gfx_round_outline(&screen, x, y, w, h, 10, 0x4A4A4A, 256);

    gui_apple(&screen, x + 14, y + 38, 26, 30, 0x2A2A2A);
    gfx_text(&screen, x + 46, y + 12, "Are you sure you want to shut down?",
             0x1A1A1A, FONT_UI, 1);
    char msg[96];
    ksnprintf(msg, sizeof(msg),
              "%d window(s) are open. Uptime %u s.",
              nz, (u32)(sched_uptime_ms() / 1000));
    gfx_text(&screen, x + 46, y + 44, msg, 0x3A3A3A, FONT_UI, 0);
    gfx_text(&screen, x + 46, y + 62, "Press S to shut down, R to restart,",
             0x3A3A3A, FONT_UI, 0);
    gfx_text(&screen, x + 46, y + 78, "Esc to cancel.", 0x3A3A3A, FONT_UI, 0);

    aqua_button(x + w - 130, y + h - 42, 112, 26, "Shut Down", 1);
    aqua_button(x + w - 250, y + h - 42, 100, 26, "Restart", 0);
    aqua_button(x + 18, y + h - 42, 90, 26, "Cancel", 0);
}

/* =====================================================================
 *  Курсор
 * =================================================================== */
static void draw_cursor(void)
{
    if (!mouse_present()) return;
    for (int j = 0; j < 16; j++) {
        i32 y = my - coy + j;
        if (y < 0 || y >= (i32)screen.h) continue;
        for (int i = 0; i < 16; i++) {
            if (!(cursor_msk[j] & (1 << (15 - i)))) continue;
            i32 x = mx - cox + i;
            if (x < 0 || x >= (i32)screen.w) continue;
            screen.px[y * screen.stride + x] =
                (cursor_img[j] & (1 << (15 - i))) ? 0x000000 : 0xFFFFFF;
        }
    }
}

/* =====================================================================
 *  Сборка кадра по damage-прямоугольникам
 * =================================================================== */
static u64 st_compose_n, st_compose_tot, st_compose_last;
static u64 st_flush_tot, st_flush_last;
static u64 st_px;

void gui_stats(u64 *n, u64 *c_avg, u64 *c_last, u64 *f_avg, u64 *f_last, u64 *px)
{
    if (n) *n = st_compose_n;
    if (c_avg) *c_avg = st_compose_n ? st_compose_tot / st_compose_n : 0;
    if (c_last) *c_last = st_compose_last;
    if (f_avg) *f_avg = st_compose_n ? st_flush_tot / st_compose_n : 0;
    if (f_last) *f_last = st_flush_last;
    if (px) *px = st_px;
}

static int rects_hit(i32 ax, i32 ay, i32 aw, i32 ah,
                     i32 bx, i32 by, i32 bw, i32 bh)
{
    return ax < bx + bw && bx < ax + aw && ay < by + bh && by < ay + ah;
}

static void compose_region(i32 rx, i32 ry, i32 rw, i32 rh, int with_cursor)
{
    surf_t sub;
    sub.px = canvas + (usize)ry * abs_w + rx;
    sub.w = (u32)rw; sub.h = (u32)rh; sub.stride = abs_w;
    surf_t saved = screen;
    screen = sub;
    cox = rx; coy = ry;

    gfx_blit(&screen, wallpaper + (usize)ry * abs_w + rx, abs_w, rh, 0, 0, rw, rh);

    for (int i = 0; i < nz; i++) {
        win_t *w = zorder[i];
        if (!w || !w->used || w->minimized) continue;
        if (!rects_hit(rx, ry, rw, rh, w->x - 16, w->y - 14, w->w + 32, w->h + 30))
            continue;
        draw_window(w);
    }

    i32 dx, dy, dw, dh;
    dialog_rect(&dx, &dy, &dw, &dh);
    if (shutdown_open && rects_hit(rx, ry, rw, rh, dx - 16, dy - 14, dw + 32, dh + 30))
        draw_shutdown_dialog();

    if (rects_hit(rx, ry, rw, rh, dock_px - 6, dock_py - 36, dock_pw + 12, dock_ph + 44))
        draw_dock();
    if (ry < MENU_H + 2)
        draw_menubar();
    if (with_cursor && rects_hit(rx, ry, rw, rh, mx, my, 16, 16))
        draw_cursor();

    screen = saved;
    cox = coy = 0;
}

static void compose_locked(int with_cursor)
{
    /* Корректирующий проход: damage-rect окна мог быть выдан потоком
     * приложения по старой позиции (окно между paint и compose успело
     * уехать). Без этого внутри окна остаются «призраки» старого кадра. */
    for (int i = 0; i < nz; i++) {
        win_t *w = zorder[i];
        if (w && w->used && (w->x != w->dmg_x || w->y != w->dmg_y))
            gui_damage_win(w);
    }

    u64 px = 0;
    if (dirty_full || ndirty == 0) {
        compose_region(0, 0, (i32)abs_w, (i32)abs_h, with_cursor);
        px = (u64)abs_w * abs_h;
        flush_y0 = 0;
        flush_y1 = abs_h;
    } else {
        i32 y0 = (i32)abs_h, y1 = 0;
        for (int i = 0; i < ndirty; i++) {
            compose_region(drects[i].x, drects[i].y, drects[i].w, drects[i].h,
                           with_cursor);
            px += (u64)drects[i].w * drects[i].h;
            if (drects[i].y < y0) y0 = drects[i].y;
            if (drects[i].y + drects[i].h > y1) y1 = drects[i].y + drects[i].h;
        }
        flush_y0 = (u32)y0;
        flush_y1 = (u32)y1;
    }
    ndirty = 0;
    dirty_full = 0;
    st_px = px;
}

void gui_compose(void)
{
    if (!canvas) return;
    u64 t0 = rdtsc();
    gui_lock();
    compose_locked(1);
    gui_unlock();
    u64 t1 = rdtsc();
    fb_flush_rows(canvas, flush_y0, flush_y1);
    u64 t2 = rdtsc();
    st_compose_n++;
    st_compose_tot += t1 - t0;
    st_compose_last = t1 - t0;
    st_flush_tot += t2 - t1;
    st_flush_last = t2 - t1;
}

/* =====================================================================
 *  Джинн: окно улетает в иконку дока
 * =================================================================== */
static void genie_frame(const win_t *w, const u32 *snap, int tx, int ty, int f, int F)
{
    int W = w->w, H = w->h;
    int target_w = 56;
    for (int ys = 0; ys < H; ys++) {
        u32 u = (u32)((i64)ys * 1000 / (H > 1 ? H - 1 : 1));       /* 0..1000 */
        /* нижние строки уезжают первыми: прогресс строки = f/F * (1 + u) */
        i64 pf = (i64)f * (1000 + u) / F;
        if (pf > 1000) pf = 1000;
        i64 e = pf * pf / 1000;                                    /* ускорение */

        int cw = W + (int)((i64)(target_w - W) * e / 1000);
        int y_out = w->y + ys + (int)((i64)(ty - (w->y + ys)) * e / 1000);
        int x_out = w->x + (int)((i64)(tx - cw / 2 - w->x) * e / 1000);
        if (cw < 2) continue;
        if (y_out < MENU_H || y_out >= (i32)abs_h) continue;
        if (x_out < 0 || x_out + cw > (i32)abs_w) {
            if (x_out < 0) { cw += x_out; x_out = 0; }
            if (x_out + cw > (i32)abs_w) cw = (i32)abs_w - x_out;
            if (cw < 2) continue;
        }
        u32 alpha = 256 - (u32)(f * 110 / F);
        u32 *dst = canvas + (usize)y_out * screen.stride + x_out;
        for (int i = 0; i < cw; i++) {
            u32 sx = (u32)((i64)i * (W - 1) / (cw > 1 ? cw - 1 : 1));
            dst[i] = mixc(dst[i], snap[(usize)ys * W + sx], alpha);
        }
    }
}

static void genie(win_t *w, const u32 *snap)
{
    int tx = -1, ty = (i32)abs_h - 24;
    if (w->app >= 0 && w->app < dock_n) {
        tx = dock_xs[w->app] + dock_sz[w->app] / 2;
        ty = dock_py + dock_ph - 30;
    }
    if (tx < 0) tx = (i32)abs_w / 2;

    const int F = 18;
    for (int f = 1; f <= F; f++) {
        gui_damage_full();
        gui_compose();
        gui_lock();
        genie_frame(w, snap, tx, ty, f, F);
        gui_unlock();
        fb_flush(canvas);
        sched_sleep_ms(16);
    }
}

static void unlink_locked(win_t *w)
{
    for (int i = 0; i < nz; i++)
        if (zorder[i] == w) {
            for (int j = i; j < nz - 1; j++) zorder[j] = zorder[j + 1];
            zorder[--nz] = NULL;
            break;
        }
}

static void focus_locked(win_t *w);
static void focus_top_locked(void);

static void do_close(win_t *w)
{
    if (!w || !w->used) return;
    w->alive = 0;

    /* ждём, пока поток приложения гарантированно выйдет и перестанет
     * трогать свой буфер */
    int guard = 0;
    while (!w->task_done && guard++ < 400) sched_sleep_ms(4);

    u32 *snap = (u32 *)kmalloc((usize)w->w * w->h * 4);
    gui_lock();
    dirty_full = 1; ndirty = 0;
    compose_locked(0);                   /* окно ещё в z-order -> снимаем кадр */
    if (snap) {
        for (int j = 0; j < w->h; j++) {
            int y = w->y + j;
            if (y < 0 || y >= (i32)abs_h) continue;
            for (int i = 0; i < w->w; i++) {
                int x = w->x + i;
                if (x < 0 || x >= (i32)abs_w) continue;
                snap[(usize)j * w->w + i] = canvas[(usize)y * screen.stride + x];
            }
        }
    }
    unlink_locked(w);
    if (focused == w) focus_top_locked();
    gui_unlock();
    fb_flush(canvas);

    if (snap) { genie(w, snap); kfree(snap); }

    gui_lock();
    if (w->buf) { kfree(w->buf); w->buf = NULL; }
    w->used = 0;
    w->paint = NULL;
    w->on_key = NULL;
    w->udata = NULL;
    w->task_done = 0;
    gui_unlock();
    gui_damage_full();
    klog("gui: window #%d closed", w->id);
}

/* =====================================================================
 *  Управление окнами
 * =================================================================== */
static void focus_top_locked(void)
{
    focused = NULL;
    for (int i = nz - 1; i >= 0; i--)
        if (zorder[i] && zorder[i]->used && !zorder[i]->minimized) {
            focus_locked(zorder[i]);
            return;
        }
}

static void focus_locked(win_t *w)
{
    if (!w) return;
    win_t *old = focused;
    if (old && old != w) old->focused = 0;
    focused = w;
    w->focused = 1;
    if (old && old != w) gui_damage_win(old);
    gui_damage_win(w);
    gui_damage_dock();          /* magnification + tooltip едут за фокусом */
    gui_damage_menubar();       /* имя приложения в меню-баре */
    for (int i = 0; i < nz; i++)
        if (zorder[i] == w) {
            for (int j = i; j < nz - 1; j++) zorder[j] = zorder[j + 1];
            zorder[nz - 1] = w;
            break;
        }
}

void gui_focus(win_t *w)
{
    gui_lock();
    focus_locked(w);
    gui_unlock();
}

/* i-е окно в z-порядке (0 = самое нижнее). Без блокировки: предполагается,
 * что зовут либо из-под gui_lock(), либо из потока композитора. */
win_t *gui_window_by_index(int i)
{
    if (i < 0 || i >= nz) return NULL;
    return zorder[i];
}

void gui_request_shutdown(void) { pending_action = ACT_SHUTDOWN; }
void gui_request_restart(void)  { pending_action = ACT_RESTART; }


/* =====================================================================
 *  Мышь: hit-test, перетаскивание, клики
 * =================================================================== */
static win_t *win_at(i32 x, i32 y)
{
    for (int i = nz - 1; i >= 0; i--) {
        win_t *w = zorder[i];
        if (!w || !w->used || w->minimized) continue;
        if (x >= w->x && x < w->x + w->w && y >= w->y && y < w->y + w->h)
            return w;
    }
    return NULL;
}

/* какая из трёх «лампочек» под курсором: 0=close, 1=minimize, 2=zoom */
static int light_at(win_t *w, i32 x, i32 y)
{
    int d = 13, cy = w->y + (WIN_TITLE_H - d) / 2 + d / 2;
    if (y < w->y + 1 || y > w->y + WIN_TITLE_H - 1) return -1;
    for (int i = 0; i < 3; i++) {
        int cx = w->x + 8 + i * 19 + d / 2;
        int dx = x - cx, dy = y - cy;
        if (dx * dx + dy * dy <= (d / 2 + 2) * (d / 2 + 2)) return i;
    }
    return -1;
}

static int dock_hit(i32 x, i32 y)
{
    if (y < dock_py || y >= dock_py + dock_ph) return -1;
    if (x < dock_px || x >= dock_px + dock_pw) return -1;
    for (int i = 0; i < dock_n; i++) {
        int sz = dock_sz[i];
        int iy = dock_py + dock_ph - 22 - sz;
        if (x >= dock_xs[i] && x < dock_xs[i] + sz && y >= iy && y < iy + sz)
            return i;
    }
    return -1;
}

static int dialog_hit(i32 x, i32 y)
{
    int w = 420, h = 150;
    int dx = ((int)abs_w - w) / 2, dy = ((int)abs_h - h) / 2 - 20;
    if (x >= dx + 18 && x < dx + 18 + 90 && y >= dy + h - 42 && y < dy + h - 16)
        return 0;                                    /* Cancel */
    if (x >= dx + w - 250 && x < dx + w - 150 && y >= dy + h - 42 && y < dy + h - 16)
        return 1;                                    /* Restart */
    if (x >= dx + w - 130 && x < dx + w - 18 && y >= dy + h - 42 && y < dy + h - 16)
        return 2;                                    /* Shut Down */
    return -1;
}

static void dock_click(int i)
{
    if (i >= APP_COUNT) { gui_beep(); return; }      /* корзина пока декорация */
    for (int k = 0; k < MAX_WINDOWS; k++) {
        win_t *w = &wins[k];
        if (w->used && w->app == i) {
            w->minimized = 0;
            focus_locked(w);
            w->repaint = 1;
            return;
        }
    }
    pending_launch = i;                              /* запускаем вне лока */
}

/* Зелёная «лампочка» Aqua: развернуть на рабочую область / вернуть как было.
 * Клиентский буфер пересоздаётся под новый размер -- приложения рисуют
 * относительно w->cw/w->ch, так что всё адаптируется само. */
static void zoom_toggle(win_t *w)
{
    int nx, ny, nw, nh;
    if (!w->zoomed) {
        w->sx = w->x; w->sy = w->y; w->sw = w->w; w->sh = w->h;
        nx = 4; ny = MENU_H + 2;
        nw = (i32)abs_w - 8;
        nh = (i32)abs_h - MENU_H - DOCK_PANEL_H - 16;
        w->zoomed = 1;
    } else {
        nx = w->sx; ny = w->sy; nw = w->sw; nh = w->sh;
        w->zoomed = 0;
    }
    int cw = nw, ch = nh - WIN_TITLE_H;
    u32 *nb = (u32 *)kzalloc((usize)cw * ch * 4);
    if (!nb) { klog("gui: zoom failed, no memory"); return; }
    kfree(w->buf);
    w->x = nx; w->y = ny; w->w = nw; w->h = nh;
    w->cw = cw; w->ch = ch;
    w->buf = nb;
    w->surf.px = nb; w->surf.w = (u32)cw; w->surf.h = (u32)ch;
    w->surf.stride = (u32)cw;
    w->repaint = 1;
    gui_damage_full();
}

static void gui_mouse_locked(const mouse_evt_t *e)
{
    i32 nx = mx + e->dx;
    i32 ny = my - e->dy;             /* у PS/2 dy>0 означает ВВЕРХ */
    gui_damage(mx, my, 17, 17);      /* старый курсор */
    mx = CLAMP(nx, 0, (i32)abs_w - 1);
    my = CLAMP(ny, 0, (i32)abs_h - 1);
    gui_damage(mx, my, 17, 17);      /* новый курсор */

    u8 pressed  = (u8)(e->buttons & ~mbtn);
    u8 released = (u8)(mbtn & ~e->buttons);
    mbtn = e->buttons;

    if (pressed & MB_LEFT) {
        if (shutdown_open) {
            switch (dialog_hit(mx, my)) {
            case 0: shutdown_open = 0; break;
            case 1: pending_action = ACT_RESTART; break;
            case 2: pending_action = ACT_SHUTDOWN; break;
            default: gui_beep(); break;
            }
            return;
        }
        int di = dock_hit(mx, my);
        if (di >= 0) { dock_click(di); return; }

        win_t *w = win_at(mx, my);
        if (!w) return;
        focus_locked(w);
        w->repaint = 1;

        int li = light_at(w, mx, my);
        if (li == 0) { pending_close = w; return; }
        if (li == 1) { w->minimized = 1; focus_top_locked(); gui_beep(); return; }
        if (li == 2) { zoom_toggle(w); return; }

        if (my < w->y + WIN_TITLE_H) {           /* взяли за заголовок */
            drag_win = w;
            drag_ox = mx - w->x;
            drag_oy = my - w->y;
            return;
        }
        if (w->on_mouse)
            w->on_mouse(w, mx - w->x, my - w->y - WIN_TITLE_H, e->buttons, 1);
        return;
    }

    if ((mbtn & MB_LEFT) && drag_win) {          /* тащим окно */
        i32 ox = drag_win->x, oy = drag_win->y;
        drag_win->x = CLAMP(mx - drag_ox, 60 - drag_win->w, (i32)abs_w - 60);
        drag_win->y = CLAMP(my - drag_oy, MENU_H + 1, (i32)abs_h - WIN_TITLE_H - 8);
        if (ox != drag_win->x || oy != drag_win->y) {
            gui_damage(ox - 16, oy - 14, drag_win->w + 32, drag_win->h + 30);
            gui_damage_win(drag_win);
        }
        return;
    }

    if (released & MB_LEFT) {
        if (drag_win) { drag_win = NULL; return; }
        win_t *w = win_at(mx, my);
        if (w && w->on_mouse) {
            w->on_mouse(w, mx - w->x, my - w->y - WIN_TITLE_H, e->buttons, 0);
            w->repaint = 1;
        }
    }
}

void gui_mouse_pos(int *x, int *y) { if (x) *x = mx; if (y) *y = my; }

static void gui_app_task(void *arg)
{
    win_t *w = (win_t *)arg;
    w->task_done = 0;
    while (w->alive) {
        if (w->repaint && w->paint) {
            w->repaint = 0;
            gui_lock();
            if (w->alive) w->paint(w);
            gui_unlock();
            if (w->pdmg) {
                /* приложение перерисовало только кусок клиентской области --
                 * композитору хватит прямоугольника вокруг него */
                gui_damage(w->x + w->pd_x, w->y + WIN_TITLE_H + w->pd_y,
                           w->pd_w, w->pd_h);
                w->dmg_x = w->x;
                w->dmg_y = w->y;
                w->pdmg = 0;
            } else {
                gui_damage_win(w);
            }
        }
        sched_sleep_ms(w->period);
    }
    w->task_done = 1;
    task_exit();
}

win_t *gui_window(const char *title, int x, int y, int w, int h, int style,
                  void (*paint)(win_t *), void (*on_key)(win_t *, const key_t *),
                  void *udata, u32 period, const char *taskname)
{
    if (!canvas) return NULL;
    if (h < WIN_TITLE_H + 40) h = WIN_TITLE_H + 40;
    if (w < 160) w = 160;
    if (x + w > (i32)abs_w - 8) x = (i32)abs_w - 8 - w;
    if (x < 4) x = 4;
    if (y < MENU_H + 4) y = MENU_H + 4;
    if (y + h > (i32)abs_h - 24) y = (i32)abs_h - 24 - h;

    int cw = w, ch = h - WIN_TITLE_H;
    u32 *buf = (u32 *)kzalloc((usize)cw * ch * 4);
    if (!buf) { klog("gui: no memory for window buffer"); return NULL; }

    gui_lock();
    win_t *fw = NULL;
    for (int i = 0; i < MAX_WINDOWS; i++)
        if (!wins[i].used) { fw = &wins[i]; break; }
    if (!fw) {
        gui_unlock();
        kfree(buf);
        klog("gui: window table full");
        return NULL;
    }

    memset(fw, 0, sizeof(*fw));
    fw->used = 1;
    fw->id = (int)(fw - wins);
    strncpy(fw->title, title ? title : "window", sizeof(fw->title) - 1);
    fw->x = x; fw->y = y; fw->w = w; fw->h = h;
    fw->cw = cw; fw->ch = ch;
    fw->buf = buf;
    fw->surf.px = buf; fw->surf.w = (u32)cw; fw->surf.h = (u32)ch;
    fw->surf.stride = (u32)cw;
    fw->style = style;
    fw->app = -1;
    fw->alive = 1;
    fw->repaint = 1;
    fw->period = period ? period : 40;
    fw->paint = paint;
    fw->on_key = on_key;
    fw->udata = udata;
    fw->dmg_x = x;
    fw->dmg_y = y;
    zorder[nz++] = fw;
    focus_locked(fw);
    gui_unlock();

    if (task_create(taskname ? taskname : "app", gui_app_task, fw) < 0)
        klog("gui: cannot create task for '%s'", title);

    gui_damage_full();
    klog("gui: window '%s' %dx%d at (%d,%d)", fw->title, w, h, x, y);
    return fw;
}

void gui_close(win_t *w) { if (w) pending_close = w; }

void gui_shutdown_dialog(int on) { shutdown_open = on; gui_damage_full(); }

/* =====================================================================
 *  Клавиатура
 * =================================================================== */
static void move_window(int dx, int dy)
{
    if (!focused) return;
    i32 ox = focused->x, oy = focused->y;
    focused->x += dx;
    focused->y += dy;
    if (focused->x + focused->w > (i32)abs_w - 4) focused->x = (i32)abs_w - 4 - focused->w;
    if (focused->x < -(focused->w - 40)) focused->x = -(focused->w - 40);
    if (focused->y < MENU_H + 1) focused->y = MENU_H + 1;
    if (focused->y + focused->h > (i32)abs_h - 6) focused->y = (i32)abs_h - 6 - focused->h;
    gui_damage(ox - 16, oy - 14, focused->w + 32, focused->h + 30);
    gui_damage_win(focused);
}

static void cycle_focus(void)
{
    if (nz < 2) return;
    for (int k = 1; k <= nz; k++) {
        int idx = -1;
        for (int i = 0; i < nz; i++) if (zorder[i] == focused) idx = i;
        int n = (idx - k) % nz;
        if (n < 0) n += nz;
        if (zorder[n] && !zorder[n]->minimized) {
            focus_locked(zorder[n]);
            gui_beep();
            return;
        }
    }
}

static void gui_key_locked(const key_t *k)
{
    u8 m = k->mods;

    if (k->code == KEY_ESC) {
        shutdown_open = !shutdown_open;
        gui_damage_full();
        return;
    }
    if (shutdown_open) {
        char c = k->ch;
        if (c == 's' || c == 'S' || c == '\n') pending_action = ACT_SHUTDOWN;
        else if (c == 'r' || c == 'R')         pending_action = ACT_RESTART;
        else if (c == 'y' || c == 'Y')         pending_action = ACT_SHUTDOWN;
        return;
    }

    if (m & MOD_ALT) {
        int step = (m & MOD_SHIFT) ? 1 : 12;
        switch (k->code) {
        case KEY_LEFT:  move_window(-step, 0); return;
        case KEY_RIGHT: move_window(step, 0);  return;
        case KEY_UP:    move_window(0, -step); return;
        case KEY_DOWN:  move_window(0, step);  return;
        default: break;
        }
        switch (k->ch) {
        case 'w': case 'W': case 'c': case 'C':
            if (focused) pending_close = focused;
            return;
        case 'b': case 'B': pending_hog = 1; return;
        case 'a': case 'A': pending_launch = APP_ABOUT; return;
        case 't': case 'T': pending_launch = APP_TERMINAL; return;
        case 'm': case 'M': pending_launch = APP_ACTIVITY; return;
        default: return;
        }
    }

    if (k->code >= KEY_F1 && k->code <= KEY_F5) {
        pending_launch = k->code - KEY_F1;
        return;
    }
    if (k->ch == '\t') { cycle_focus(); return; }

    if (focused && focused->on_key) {
        focused->on_key(focused, k);
        gui_damage_win(focused);
    }
}

void gui_key(const key_t *k)
{
    gui_lock();
    gui_key_locked(k);
    gui_unlock();
}

/* =====================================================================
 *  Звук (PC speaker через PIT channel 2)
 * =================================================================== */
void gui_beep(void)
{
    u32 div = 1193180u / 740u;
    outb(0x43, 0xB6);
    outb(0x42, (u8)(div & 0xFF));
    outb(0x42, (u8)(div >> 8));
    outb(0x61, (u8)((inb(0x61) & 0xFC) | 0x03));
    beep_until = (u32)sched_uptime_ms() + 110;
}

static void beep_poll(void)
{
    if (beep_until && (u32)sched_uptime_ms() > beep_until) {
        outb(0x61, (u8)(inb(0x61) & 0xFC));
        beep_until = 0;
    }
}

/* =====================================================================
 *  Выключение / перезагрузка
 * =================================================================== */
static void goodbye(const char *msg)
{
    memcpy(canvas, wallpaper, (usize)abs_w * abs_h * 4);
    gfx_blend(&screen, 0, 0, (i32)abs_w, (i32)abs_h, 0x000000, 120);
    i32 tw = (i32)gfx_text_width(msg, FONT_TITLE);
    gfx_text(&screen, ((i32)abs_w - tw) / 2, (i32)abs_h / 2 - 40, msg,
             0xFFFFFF, FONT_TITLE, 0);
    fb_flush(canvas);
}

static void power_off(void)
{
    cli();
    klog("gui: shutting down");
    goodbye("It is now safe to switch off");
    outw(0x604, 0x2000);     /* ACPI PM1a_CNT.SLP_EN (QEMU pc) */
    outw(0xB004, 0x2000);    /* Bochs/QEMU legacy APM */
    outw(0x4004, 0x3400);    /* VirtualBox */
    for (;;) hlt();
}

static void restart_now(void)
{
    cli();
    klog("gui: restarting");
    goodbye("Restarting...");
    int t = 100000;
    while ((inb(0x64) & 2) && --t > 0) ;
    outb(0x64, 0xFE);        /* сброс через контроллер клавиатуры */
    for (volatile int i = 0; i < 10000000; i++) ;
    for (;;) hlt();
}

/* =====================================================================
 *  Инициализация и главный поток композитора
 * =================================================================== */
void gui_init(void)
{
    usize px = (usize)fb.width * fb.height;
    canvas    = (u32 *)kzalloc(px * 4);
    wallpaper = (u32 *)kzalloc(px * 4);
    icon_ss   = (u32 *)kzalloc((usize)ICON_MAX * ICON_SS *
                               (usize)ICON_MAX * ICON_SS * 4);
    int alloc_ok = !!icon_ss;
    for (int i = 0; i <= APP_COUNT; i++) {
        icon_px[i] = (u32 *)kzalloc((usize)ICON_MAX * ICON_MAX * 4);
        icon_al[i] = (u8 *)kzalloc((usize)ICON_MAX * ICON_MAX);
        alloc_ok = alloc_ok && !!icon_px[i] && !!icon_al[i];
    }
    if (!canvas || !wallpaper || !alloc_ok)
        panic("gui: cannot allocate framebuffers");

    screen.px = canvas;
    screen.w = fb.width;
    screen.h = fb.height;
    screen.stride = fb.width;
    abs_w = fb.width;
    abs_h = fb.height;

    shadow_init();
    build_wallpaper();
    mx = (i32)abs_w / 2;
    my = (i32)abs_h / 2;
    rtc_read(&wall_clock);
    clock_ok = wall_clock.valid;
    if (!clock_ok) rtc_fake_from_uptime(&wall_clock, 0);
    klog("gui: Aqua compositor up, %ux%u canvas (%u KiB), damage-rect compositing",
         fb.width, fb.height, (u32)(px * 8 / 1024));
    gui_damage_full();
    gui_compose();
}

void gui_task(void *arg)
{
    (void)arg;
    sched_set_wake_id(sched_current()->id);   /* будить нас по событиям ввода */
    for (;;) {
        key_t k;
        int any = 0;

        gui_lock();
        while (input_poll(&k)) { gui_key_locked(&k); any = 1; }
        mouse_evt_t me;
        while (mouse_poll(&me)) gui_mouse_locked(&me);
        gui_unlock();
        (void)any;

        /* отложенные действия -- вне спинлока */
        if (pending_close) { win_t *w = pending_close; pending_close = NULL; do_close(w); }
        if (pending_launch >= 0) { int a = pending_launch; pending_launch = -1; app_launch(a); }
        if (pending_hog) { pending_hog = 0; app_hog(NULL); }
        if (pending_action == ACT_SHUTDOWN) power_off();
        if (pending_action == ACT_RESTART)  restart_now();

        u64 ms = sched_uptime_ms();

        if (busy_flag && (u32)(ms - spin_ms) >= 70) {
            spin_ms = (u32)ms;
            spin_phase = (spin_phase + 1) % 6;
            gui_damage_menubar();
        }
        if ((u32)(ms - clock_ms) >= 500) {
            clock_ms = (u32)ms;
            if (clock_ok) rtc_read(&wall_clock);
            else rtc_fake_from_uptime(&wall_clock, ms);
            sched_account();
            gui_damage_menubar();
        }
        u32 was_bounce = app_bounce_ms;
        apps_tick();
        if (was_bounce) gui_damage_dock();
        beep_poll();

        if (dirty) { dirty = 0; gui_compose(); }

        /* адаптивный сон: если никто ничего не пометил и ввода нет --
         * спим долго (часы обновятся сами по своему дедлайну). Любое
         * событие будит нас досрочно через sched_wake_gui(). */
        u32 sl = 16;
        if (!dirty && !input_pending() && !mouse_pending())
            sl = busy_flag ? 70 : (app_bounce_ms ? 16 : 250);
        sched_sleep_ms(sl);
    }
}
