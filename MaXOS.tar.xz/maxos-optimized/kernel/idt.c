#include "idt.h"
#include "klib.h"
#include "log.h"
#include "console.h"
#include "serial.h"
#include "input.h"
#include "mouse.h"
#include "sched.h"
#include "fb.h"
#include <stdarg.h>

#define PIC1_CMD  0x20
#define PIC1_DATA 0x21
#define PIC2_CMD  0xA0
#define PIC2_DATA 0xA1
#define PIC_EOI   0x20

#define PIT_CH0   0x40
#define PIT_CMD   0x43

extern u64 isr_stub_table[];
extern void cpu_load_idt(void *desc);
extern u64 cpu_get_cr2(void);

typedef struct __attribute__((packed)) {
    u16 off_lo;
    u16 sel;
    u8  ist;
    u8  attr;
    u16 off_mid;
    u32 off_hi;
    u32 zero;
} idt_entry_t;

struct idt_desc {
    u16 limit;
    u64 base;
} __attribute__((packed));

static idt_entry_t idt[256];
static struct idt_desc idtr;

static const char *exc_names[32] = {
    "#DE Divide Error",        "#DB Debug",              "NMI",
    "#BP Breakpoint",          "#OF Overflow",           "#BR Bound Range",
    "#UD Invalid Opcode",      "#NM Device Not Available","#DF Double Fault",
    "Coprocessor Segment",     "#TS Invalid TSS",        "#NP Segment Not Present",
    "#SS Stack-Segment Fault", "#GP General Protection", "#PF Page Fault",
    "(reserved)",              "#MF x87 FPU",            "#AC Alignment Check",
    "#MC Machine Check",       "#XM SIMD FP",            "#CP Control Protection",
    "(reserved 21)",           "(reserved 22)",          "(reserved 23)",
    "(reserved 24)",           "(reserved 25)",          "(reserved 26)",
    "(reserved 27)",           "#HV Hypervisor",         "#VC VMM Communication",
    "#SX Security Control",    "(reserved 31)"
};

static void set_gate(int n, u64 handler, u8 ist)
{
    idt[n].off_lo  = (u16)(handler & 0xFFFF);
    idt[n].sel     = SEL_KCODE;
    idt[n].ist     = ist;
    idt[n].attr    = 0x8E;                 /* P=1, DPL=0, type=1110 (int gate) */
    idt[n].off_mid = (u16)((handler >> 16) & 0xFFFF);
    idt[n].off_hi  = (u32)(handler >> 32);
    idt[n].zero    = 0;
}

static void pic_remap(void)
{
    outb(PIC1_CMD, 0x11); io_wait();       /* ICW1: edge, cascade */
    outb(PIC2_CMD, 0x11); io_wait();
    outb(PIC1_DATA, 0x20); io_wait();      /* ICW2: векторы 0x20.. */
    outb(PIC2_DATA, 0x28); io_wait();      /*        и 0x28..      */
    outb(PIC1_DATA, 0x04); io_wait();      /* ICW3: на мастере висит slave по IRQ2 */
    outb(PIC2_DATA, 0x02); io_wait();      /*        slave -> cascade id 2 */
    outb(PIC1_DATA, 0x01); io_wait();      /* ICW4: 8086 mode */
    outb(PIC2_DATA, 0x01); io_wait();
    outb(PIC1_DATA, 0xFF);                 /* всё замаскировать... */
    outb(PIC2_DATA, 0xFF);
}

static void pit_init(u32 hz)
{
    u32 div = 1193180u / hz;
    outb(PIT_CMD, 0x36);                   /* ch0, lobyte/hibyte, mode 3, binary */
    outb(PIT_CH0, (u8)(div & 0xFF));
    outb(PIT_CH0, (u8)((div >> 8) & 0xFF));
}

/* =====================================================================
 *  Обработчик всего: вызывается из isr_common (lowlevel.S)
 * =================================================================== */
void isr_dispatch(regs_t *r)
{
    u64 n = r->intno;

    if (n >= 32 && n < 48) {
        int irq = (int)(n - 32);

        switch (irq) {
        case 0:  /* PIT */
            break;
        case 1:  /* клавиатура */
            input_scancode(inb(0x60));
            break;
        case 12: /* PS/2 мышь (aux-порт 8042) */
            mouse_irq();
            break;
        default:
            break;
        }

        /* EOI ОБЯЗАТЕЛЬНО до возможного переключения задач, иначе PIC
         * останется с непотверждённым IRQ и больше ничего не пришлёт. */
        if (irq >= 8) outb(PIC2_CMD, PIC_EOI);
        outb(PIC1_CMD, PIC_EOI);

        if (irq == 0) sched_tick();
        return;
    }

    if (n < 32) {
        /* Исключение. Печатаем всё, что знаем, и встаём. */
        u64 cr2 = 0;
        if (n == 14) cr2 = cpu_get_cr2();

        klog("!!! EXCEPTION %u (%s) err=%x", (unsigned)n, exc_names[n & 31],
             (unsigned)r->err);
        klog("    rip=%p cs=%x rflags=%llx", (void *)(usize)r->rip,
             (unsigned)r->cs, r->rflags);
        klog("    rsp=%p ss=%x", (void *)(usize)r->rsp, (unsigned)r->ss);
        if (n == 14) klog("    cr2=%p (address of the faulting access)", (void *)cr2);
        klog("    rax=%p rbx=%p rcx=%p rdx=%p", (void *)(usize)r->rax,
             (void *)(usize)r->rbx, (void *)(usize)r->rcx, (void *)(usize)r->rdx);
        klog("    task '%s'", sched_current() ? sched_current()->name : "?");

        if (console_enabled()) {
            console_set_fg(0xFF6B6B);
            console_printf("\nKERNEL PANIC: %s (vector %u, err=%x)\n"
                           "rip=%p  cr2=%p  task='%s'\nSystem halted.\n",
                           exc_names[n & 31], (unsigned)n, (unsigned)r->err,
                           (void *)(usize)r->rip, (void *)(usize)cr2,
                           sched_current() ? sched_current()->name : "?");
        }
        panic("exception %u", (u32)n);
    }

    /* spurious */
    outb(PIC1_CMD, PIC_EOI);
}

void idt_init(void)
{
    memset(idt, 0, sizeof(idt));
    for (int i = 0; i < 48; i++)
        set_gate(i, isr_stub_table[i], (i == 8) ? 1 : 0);   /* #DF -> IST1 */

    idtr.limit = (u16)(sizeof(idt) - 1);
    idtr.base  = (u64)(usize)idt;
    cpu_load_idt(&idtr);

    pic_remap();
    /* IRQ0 таймер, IRQ1 клавиатура, IRQ2 -- КАСКАД на slave: без него
     * всё, что висит на slave (в т.ч. мышь IRQ12), не дойдёт никогда. */
    outb(PIC1_DATA, (u8)~((1 << 0) | (1 << 1) | (1 << 2)));
    outb(PIC2_DATA, (u8)~(1 << 4));          /* IRQ12 = мышь */

    pit_init(PIT_HZ);
    klog("idt: 48 gates at %p, PIC 0x20/0x28, PIT %u Hz",
         (void *)(usize)idtr.base, (unsigned)PIT_HZ);
}

void panic(const char *fmt, ...)
{
    char buf[256];
    va_list ap;
    va_start(ap, fmt);
    kvsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    cli();
    serial_write("\n*** MaXOS PANIC: ");
    serial_write(buf);
    serial_write(" ***\n");
    if (console_enabled()) {
        console_set_fg(0xFF6B6B);
        console_printf("\n*** PANIC: %s ***\n", buf);
    }
    for (;;) hlt();
}
