#ifndef MAXOS_INPUT_H
#define MAXOS_INPUT_H

#include "types.h"

/* Специальные клавиши живут выше ASCII, чтобы key_t.ch оставался обычным
 * символом для всего печатного. */
enum {
    KEY_NONE = 0,
    KEY_ESC = 0x100,
    KEY_F1, KEY_F2, KEY_F3, KEY_F4, KEY_F5, KEY_F6,
    KEY_F7, KEY_F8, KEY_F9, KEY_F10, KEY_F11, KEY_F12,
    KEY_LEFT, KEY_RIGHT, KEY_UP, KEY_DOWN,
    KEY_HOME, KEY_END, KEY_PGUP, KEY_PGDN, KEY_INS, KEY_DEL,
    KEY_ENTER, KEY_TAB, KEY_BACKSPACE, KEY_SPACE
};

#define MOD_SHIFT 0x01
#define MOD_CTRL  0x02
#define MOD_ALT   0x04
#define MOD_CAPS  0x08

typedef struct {
    u16  code;      /* KEY_* или ASCII-код */
    char ch;        /* символ, 0 если это служебная клавиша */
    u8   mods;      /* MOD_* на момент нажатия */
} key_t;

void input_init(void);
void input_scancode(u8 sc);       /* вызывается из IRQ1 */
int  input_poll(key_t *k);        /* 1 если что-то есть в очереди */
int  input_pending(void);
u8   input_mods(void);

#endif
