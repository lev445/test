#ifndef MAXOS_GUI_H
#define MAXOS_GUI_H

#include "types.h"
#include "gfx.h"
#include "input.h"

/* ---------------------------------------------------------------------
 *  Композитор в стиле Mac OS X (Aqua).
 *
 *  Всё рисуется в канвас (screen), затем одним куском уходит во
 *  фреймбуфер. Окна живут в своих буферах: приложение рисует в
 *  win->surf, композитор собирает кадр. Потоки приложений и поток
 *  композитора разведены по времени, а общий ресурс защищён простым
 *  спинлоком gui_lock().
 * ------------------------------------------------------------------- */

#define WIN_TITLE_H 22
#define MENU_H      22
#define DOCK_PANEL_H 78

enum { WIN_AQUA = 0, WIN_METAL = 1, WIN_TERM = 2 };

typedef struct win win_t;

struct win {
    int    used, id;
    char   title[48];
    int    x, y, w, h;       /* полный размер вместе с заголовком */
    int    cw, ch;           /* клиентская область */
    u32   *buf;
    surf_t surf;             /* клиентская область */
    int    style;            /* WIN_* */
    int    app;              /* APP_* или -1 */
    int    focused, alive, repaint;
    volatile int task_done;    /* поток приложения завершился */
    int    minimized, zoomed;
    int    dmg_x, dmg_y;     /* позиция, на которой окно было повреждено */
    /* частичный damage: paint() может пометить не всё окно, а прямоугольник
     * в координатах клиентской области (мигание курсора терминала и т.п.) */
    int    pdmg;
    i32    pd_x, pd_y, pd_w, pd_h;
    int    sx, sy, sw, sh;     /* сохранённый прямоугольник для zoom */
    u32    period;             /* мс между кадрами задачи приложения */
    void (*paint)(win_t *);
    void (*on_key)(win_t *, const key_t *);
    void (*on_mouse)(win_t *, int x, int y, u8 buttons, int pressed);
    void  *udata;
};

extern surf_t screen;        /* канвас композитора */

void   gui_init(void);
void   gui_task(void *arg);  /* поток композитора */

win_t *gui_window(const char *title, int x, int y, int w, int h, int style,
                  void (*paint)(win_t *), void (*on_key)(win_t *, const key_t *),
                  void *udata, u32 period, const char *taskname);
void   gui_close(win_t *w);
void   gui_focus(win_t *w);          /* звать, держа gui_lock() */
void   gui_redraw(win_t *w);         /* попросить перерисовать содержимое */
/* из paint(): пометить повреждённым только прямоугольник клиентской
 * области (вместо всего окна) -- композитор пересоберёт лишь его */
void   gui_damage_surf(win_t *w, i32 x, i32 y, i32 w2, i32 h2);
void   gui_compose(void);
/* Мышь: позиция курсора и хит-тест доступны приложениям. */
void   gui_mouse_pos(int *x, int *y);
void   gui_stats(u64 *n, u64 *c_avg, u64 *c_last, u64 *f_avg, u64 *f_last, u64 *px);
void   gui_invalidate(void);
/* векторное сглаженное яблоко (меню-бар, About, диалоги) */
void   gui_apple(surf_t *s, i32 x, i32 y, i32 w, i32 h, u32 c);
void   gui_key(const key_t *k);
void   gui_lock(void);
void   gui_unlock(void);
void   gui_set_busy(int on);
int    gui_busy(void);
void   gui_beep(void);
void   gui_shutdown_dialog(int on);
void   gui_request_shutdown(void);
void   gui_request_restart(void);
win_t *gui_window_by_index(int i);   /* z-order; звать, держа gui_lock() */
win_t *gui_focused(void);
int    gui_window_count(void);

#endif
