#include "log.h"
#include "klib.h"
#include "serial.h"
#include "console.h"
#include "sched.h"

#define LOG_LINES 192
#define LOG_LEN   176

static char ring[LOG_LINES][LOG_LEN];
static int  head;    /* куда пишем следующую строку */
static int  count;   /* сколько строк сейчас в кольце */

void klog(const char *fmt, ...)
{
    char msg[LOG_LEN];
    char line[LOG_LEN];
    va_list ap;

    va_start(ap, fmt);
    kvsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);

    u64 ms = sched_uptime_ms();
    ksnprintf(line, sizeof(line), "[%4u.%03u] %s",
              (u32)(ms / 1000), (u32)(ms % 1000), msg);

    serial_write(line);
    serial_write("\n");
    if (console_enabled()) {
        console_write(line);
        console_write("\n");
    }

    strncpy(ring[head], line, LOG_LEN - 1);
    ring[head][LOG_LEN - 1] = 0;
    head = (head + 1) % LOG_LINES;
    if (count < LOG_LINES) count++;
}

int log_count(void) { return count; }

const char *log_get(int i)
{
    if (i < 0 || i >= count) return "";
    int idx = (head - count + i) % LOG_LINES;
    if (idx < 0) idx += LOG_LINES;
    return ring[idx];
}
