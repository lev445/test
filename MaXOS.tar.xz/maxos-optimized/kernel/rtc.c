#include "rtc.h"

/* CMOS/RTC через порты 0x70 (адрес) и 0x71 (данные).
 * Читаем дважды: во время обновления регистров RTC отдаёт мусор. */

#define CMOS_ADDR 0x70
#define CMOS_DATA 0x71

static u8 cmos(u8 reg)
{
    outb(CMOS_ADDR, (u8)(reg | 0x80));   /* 0x80 = не порождать NMI */
    io_wait();
    return inb(CMOS_DATA);
}

static int cmos_updating(void)
{
    return (cmos(0x0A) & 0x80) != 0;
}

static u8 bcd2bin(u8 v, int bcd)
{
    return bcd ? (u8)(((v >> 4) * 10) + (v & 0x0F)) : v;
}

void rtc_read(datetime_t *dt)
{
    u8 s, m, h, d, mo, y, b;
    int guard = 10000;

    while (cmos_updating() && --guard > 0) ;
    s  = cmos(0x00);
    m  = cmos(0x02);
    h  = cmos(0x04);
    d  = cmos(0x07);
    mo = cmos(0x08);
    y  = cmos(0x09);
    b  = cmos(0x0B);

    guard = 10000;
    while (cmos_updating() && --guard > 0) ;
    if (cmos(0x00) != s || cmos(0x02) != m || cmos(0x04) != h) {
        s  = cmos(0x00);
        m  = cmos(0x02);
        h  = cmos(0x04);
        d  = cmos(0x07);
        mo = cmos(0x08);
        y  = cmos(0x09);
    }

    int bcd = !(b & 0x04);
    dt->sec     = bcd2bin(s & 0x7F, bcd);
    dt->min     = bcd2bin(m & 0x7F, bcd);
    u8 raw_h    = h;
    if (!(b & 0x02) && (raw_h & 0x80)) {          /* 12-часовой режим + PM */
        raw_h = (u8)((raw_h & 0x7F) + 12);
        dt->hour = bcd2bin(raw_h, bcd) % 24;
    } else {
        dt->hour = bcd2bin(raw_h & 0x3F, bcd);
    }
    dt->day     = bcd2bin(d, bcd);
    dt->month   = bcd2bin(mo, bcd);
    dt->year    = (u16)(2000 + bcd2bin(y, bcd));
    dt->weekday = cmos(0x06) % 7;

    dt->valid = (dt->month >= 1 && dt->month <= 12 && dt->day >= 1 &&
                 dt->day <= 31 && dt->hour < 24 && dt->min < 60 && dt->sec < 61);
}

/* Запасной вариант: «время» из аптайма, стартуя с 00:00:00. */
void rtc_fake_from_uptime(datetime_t *dt, u64 ms)
{
    u64 s = ms / 1000;
    dt->sec     = (u8)(s % 60);
    dt->min     = (u8)((s / 60) % 60);
    dt->hour    = (u8)((s / 3600) % 24);
    dt->day     = 1;
    dt->month   = 1;
    dt->year    = 2026;
    dt->weekday = 4;
    dt->valid   = 0;
}
