#ifndef MAXOS_MM_H
#define MAXOS_MM_H

#include "types.h"

/* Сколько физической памяти считаем существующей. stage2 не передаёт
 * e820, поэтому берём консервативные 512 MiB -- ровно столько обычно
 * дают QEMU по умолчанию. Меняй на своё, если грузишься на железе. */
#define PHYS_MEM_MB 512

void  mm_init(void);          /* странички ядра + куча */
void *kmalloc(usize size);
void *kzalloc(usize size);
void  kfree(void *p);
void  mm_info(usize *total, usize *used, usize *kernel_img);

#endif
