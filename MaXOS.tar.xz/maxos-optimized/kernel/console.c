#include "console.h"
#include "fb.h"
#include "gfx.h"
#include "font.h"
#include "klib.h"
#include <stdarg.h>

#define CW 8    /* ширина знакоместа, FONT_MONO */
#define CH 16   /* высота знакоместа */

static surf_t s;
static int    up;
static u32    cols, rows, cx, cy;
static u32    fg = 0xE8E8E8;
static u32    bg = 0x0A0A0A;

void console_init(void)
{
    if (!fb_surface(&s)) { up = 0; return; }
    up = 1;
    cols = s.w / CW;
    rows = s.h / CH;
    cx = cy = 0;
    console_clear();
}

int console_enabled(void) { return up; }
void console_disable(void) { up = 0; }
void console_set_fg(u32 c) { fg = c; }

void console_clear(void)
{
    if (!up) return;
    gfx_fill(&s, 0, 0, (i32)s.w, (i32)s.h, bg);
    cx = cy = 0;
}

static void scroll(void)
{
    usize band = (usize)CH * s.stride;      /* пикселей в строке текста */
    memmove(s.px, s.px + band, band * (rows - 1) * 4);
    gfx_fill(&s, 0, (i32)((rows - 1) * CH), (i32)s.w, CH, bg);
}

void console_putc(char c)
{
    if (!up) return;
    if (c == '\n') { cx = 0; cy++; }
    else if (c == '\r') { cx = 0; }
    else if (c == '\t') { cx = (cx + 8) & ~3u; }
    else {
        char two[2] = { c, 0 };
        gfx_text(&s, (i32)(cx * CW), (i32)(cy * CH), two, fg, FONT_MONO, 0);
        if (++cx >= cols) { cx = 0; cy++; }
    }
    while (cy >= rows) { scroll(); cy--; }
}

void console_write(const char *str)
{
    for (; *str; str++) console_putc(*str);
}

void console_printf(const char *fmt, ...)
{
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    kvsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    console_write(buf);
}
