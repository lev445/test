#ifndef MAXOS_CPU_H
#define MAXOS_CPU_H

#include "types.h"

/* Селекторы нашей 64-битной GDT (см. kernel/arch/head.S) */
#define SEL_KCODE 0x08
#define SEL_KDATA 0x10
#define SEL_UCODE 0x18   /* +3 в RPL при переходе в ring 3 */
#define SEL_UDATA 0x20
#define SEL_TSS   0x28

/* 64-битная TSS. I/O bitmap нет, iomap указывает за конец структуры. */
typedef struct __attribute__((packed)) {
    u32 rsv0;
    u64 rsp0, rsp1, rsp2;
    u32 rsv1;
    u64 ist1, ist2, ist3, ist4, ist5, ist6, ist7;
    u32 rsv2;
    u32 rsv3;
    u16 iomap;
} tss_t;

extern tss_t tss64;

void cpu_init(void);
/* Перед каждым уходом в ring 3 и при каждом переключении задачи нужно
 * обновлять RSP0 -- стек, куда процессор прыгнет при прерывании. */
void cpu_set_kernel_stack(u64 rsp0);

#endif
