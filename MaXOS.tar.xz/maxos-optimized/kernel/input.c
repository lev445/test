#include "input.h"
#include "klib.h"
#include "sched.h"

/* ---------------------------------------------------------------------
 *  Клавиатура: scancode set 1 (PC/AT) -> key_t.
 *  Работает из прерывания: переводим скан-код сразу, кладём готовое
 *  событие в кольцо, GUI забирает его в своём потоке.
 * ------------------------------------------------------------------- */

static const char kbd_us[128] = {
    [0x02] = '1', [0x03] = '2', [0x04] = '3', [0x05] = '4', [0x06] = '5',
    [0x07] = '6', [0x08] = '7', [0x09] = '8', [0x0A] = '9', [0x0B] = '0',
    [0x0C] = '-', [0x0D] = '=',
    [0x10] = 'q', [0x11] = 'w', [0x12] = 'e', [0x13] = 'r', [0x14] = 't',
    [0x15] = 'y', [0x16] = 'u', [0x17] = 'i', [0x18] = 'o', [0x19] = 'p',
    [0x1A] = '[', [0x1B] = ']',
    [0x1E] = 'a', [0x1F] = 's', [0x20] = 'd', [0x21] = 'f', [0x22] = 'g',
    [0x23] = 'h', [0x24] = 'j', [0x25] = 'k', [0x26] = 'l',
    [0x27] = ';', [0x28] = '\'', [0x29] = '`',
    [0x2B] = '\\',
    [0x2C] = 'z', [0x2D] = 'x', [0x2E] = 'c', [0x2F] = 'v', [0x30] = 'b',
    [0x31] = 'n', [0x32] = 'm',
    [0x33] = ',', [0x34] = '.', [0x35] = '/',
    [0x39] = ' ',
};

static const char kbd_us_shift[128] = {
    [0x02] = '!', [0x03] = '@', [0x04] = '#', [0x05] = '$', [0x06] = '%',
    [0x07] = '^', [0x08] = '&', [0x09] = '*', [0x0A] = '(', [0x0B] = ')',
    [0x0C] = '_', [0x0D] = '+',
    [0x1A] = '{', [0x1B] = '}',
    [0x27] = ':', [0x28] = '"', [0x29] = '~',
    [0x2B] = '|',
    [0x33] = '<', [0x34] = '>', [0x35] = '?',
};

#define QUEUE 96
static key_t q[QUEUE];
static volatile int q_head, q_tail;

static volatile u8 mods;
static int e0;

void input_init(void)
{
    q_head = q_tail = 0;
    mods = 0;
    e0 = 0;
    /* Разрешаем IRQ1 в байте команды контроллера. Все ожидания с
     * таймаутом: если контроллера нет (редко, но бывает), мы просто
     * не будем его трогать, а не повиснем навсегда. */
    int t = 100000;
    while ((inb(0x64) & 2) && --t > 0) ;
    if (t <= 0) return;
    outb(0x64, 0x20);            /* прочитать байт команды */
    t = 100000;
    while (!(inb(0x64) & 1) && --t > 0) ;
    if (t <= 0) return;
    u8 cmd = inb(0x60);
    cmd |= 0x01;                 /* IRQ1 от клавиатуры разрешён */
    cmd &= ~0x10;                /* клавиатура не отключена */
    t = 100000; while ((inb(0x64) & 2) && --t > 0) ;
    outb(0x64, 0x60);
    t = 100000; while ((inb(0x64) & 2) && --t > 0) ;
    outb(0x60, cmd);
}

u8 input_mods(void) { return mods; }

static void push(u16 code, char ch)
{
    int next = (q_head + 1) % QUEUE;
    if (next == q_tail) return;              /* переполнение -- роняем */
    q[q_head].code = code;
    q[q_head].ch   = ch;
    q[q_head].mods = mods;
    q_head = next;
    sched_wake_gui();
}

int input_pending(void) { return q_head != q_tail; }

int input_poll(key_t *k)
{
    if (q_head == q_tail) return 0;
    *k = q[q_tail];
    q_tail = (q_tail + 1) % QUEUE;
    return 1;
}

void input_scancode(u8 sc)
{
    if (sc == 0xE0) { e0 = 1; return; }
    if (sc == 0xE1) return;                  /* Pause -- не нужен */

    int released = (sc & 0x80) != 0;
    u8 code = sc & 0x7F;

    /* модификаторы */
    if (!e0 && (code == 0x2A || code == 0x36)) {
        if (released) mods &= ~MOD_SHIFT; else mods |= MOD_SHIFT;
        return;
    }
    if (code == 0x1D) {
        if (released) mods &= ~MOD_CTRL; else mods |= MOD_CTRL;
        e0 = 0; return;
    }
    if (code == 0x38) {
        if (released) mods &= ~MOD_ALT; else mods |= MOD_ALT;
        e0 = 0; return;
    }
    if (!e0 && code == 0x3A) {
        if (!released) mods ^= MOD_CAPS;
        return;
    }
    if (released) { e0 = 0; return; }

    u16 k = 0;
    char ch = 0;

    if (e0) {
        e0 = 0;
        switch (code) {
        case 0x4B: k = KEY_LEFT;  break;
        case 0x4D: k = KEY_RIGHT; break;
        case 0x48: k = KEY_UP;    break;
        case 0x50: k = KEY_DOWN;  break;
        case 0x47: k = KEY_HOME;  break;
        case 0x4F: k = KEY_END;   break;
        case 0x49: k = KEY_PGUP;  break;
        case 0x51: k = KEY_PGDN;  break;
        case 0x52: k = KEY_INS;   break;
        case 0x53: k = KEY_DEL;   break;
        case 0x1C: k = KEY_ENTER; ch = '\n'; break;
        case 0x35: ch = '/'; k = '/'; break;
        default: return;
        }
    } else {
        switch (code) {
        case 0x01: k = KEY_ESC; break;
        case 0x0E: k = KEY_NONE; ch = '\b'; break;
        case 0x0F: k = KEY_NONE; ch = '\t'; break;
        case 0x1C: k = KEY_ENTER; ch = '\n'; break;
        case 0x37: ch = '*'; k = '*'; break;
        case 0x4A: ch = '-'; k = '-'; break;
        case 0x4E: ch = '+'; k = '+'; break;
        case 0x53: k = KEY_DEL; break;      /* Del при выключенном NumLock */
        case 0x47: k = KEY_HOME; break;
        case 0x48: k = KEY_UP; break;
        case 0x49: k = KEY_PGUP; break;
        case 0x4B: k = KEY_LEFT; break;
        case 0x4D: k = KEY_RIGHT; break;
        case 0x4F: k = KEY_END; break;
        case 0x50: k = KEY_DOWN; break;
        case 0x51: k = KEY_PGDN; break;
        case 0x52: k = KEY_INS; break;
        default:
            if (code >= 0x3B && code <= 0x44) { k = KEY_F1 + (code - 0x3B); break; }
            if (code == 0x57) { k = KEY_F11; break; }
            if (code == 0x58) { k = KEY_F12; break; }
            {
                char c = kbd_us[code];
                if (!c) return;
                if (c >= 'a' && c <= 'z') {
                    if ((mods & MOD_SHIFT) ^ (mods & MOD_CAPS)) c -= 32;
                } else if (mods & MOD_SHIFT) {
                    char s = kbd_us_shift[code];
                    if (s) c = s;
                }
                if (mods & MOD_CTRL) c = (char)(c & 0x1F);
                ch = c;
                k = (u16)(unsigned char)c;
            }
            break;
        }
    }
    push(k, ch);
}
