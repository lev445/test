#ifndef MAXOS_IDT_H
#define MAXOS_IDT_H

#include "types.h"
#include "cpu.h"

/* Кадр, который isr_common собирает на стеке перед вызовом isr_dispatch.
 * Порядок полей ОБЯЗАН совпадать с порядком push'ей в lowlevel.S. */
typedef struct {
    u64 r15, r14, r13, r12, r11, r10, r9, r8;
    u64 rbp, rdi, rsi, rdx, rcx, rbx, rax;
    u64 intno, err;              /* наш push: вектор и код ошибки */
    u64 rip, cs, rflags, rsp, ss; /* то, что положил процессор */
} regs_t;

#define PIT_HZ 100      /* частота таймерных тиков */

void idt_init(void);    /* IDT + перенастройка PIC + PIT */
void panic(const char *fmt, ...) __attribute__((noreturn));

#endif
