#include "apps.h"
#include "gui.h"
#include "gfx.h"
#include "font.h"
#include "fb.h"
#include "klib.h"
#include "log.h"
#include "mm.h"
#include "sched.h"
#include "rtc.h"
#include "idt.h"
#include "mouse.h"
#include "maxos.h"
#include <stdarg.h>

/* =====================================================================
 *  Приложения MaXOS.
 *
 *  Каждое окно -- отдельный поток ядра. Поток живёт в gui_app_task():
 *  если выставлен win->repaint, вызываем paint() (под gui_lock, только
 *  в w->surf), затем спим win->period миллисекунд. Анимированные
 *  приложения сами взводят repaint в каждом кадре, статические ждут
 *  события от on_key().
 * =================================================================== */

const char *app_names[APP_COUNT] = {
    "About MaXOS", "Terminal", "Activity Monitor", "Bounce", "Calculator"
};
const char *app_menus[APP_COUNT] = {
    "File   Window   Help",
    "MaXOS is beta",
    "File   View   Window   Help",
    "File   Window   Help",
    "Edit   View   Window   Help"
};

volatile u32 app_bounce_ms;
static u32 bounce_t0;

static win_t *w_about, *w_term, *w_act, *w_bounce, *w_calc;

win_t *app_find(int id)
{
    /* звать, держа gui_lock() (или из потока композитора) */
    for (int i = 0; i < 12; i++) {
        win_t *w = gui_window_by_index(i);
        if (w && w->used && w->app == id) return w;
    }
    return NULL;
}

/* =====================================================================
 *  About
 * =================================================================== */
static void about_paint(win_t *w)
{
    surf_t *s = &w->surf;
    int W = w->cw, H = w->ch;
    char left[8][24], right[8][128];
    int n = 0;
    usize ht = 0, hu = 0, kimg = 0;

    gfx_pinstripe(s, 0, 0, W, H, 0xF1F1F1, 0xFFFFFF);
    //gui_apple(s, 34, 24, 70, 80, 0x3A3A3A);   /* векторное, без пикселей */

    gfx_text(s, 30, 22, "MaXOS", 0x1A1A1A, FONT_TITLE, 0);
    gfx_text(s, 30, 70, "Version 0.1  \"Aqua\"", 0x4A4A4A, FONT_UI, 0);
    gfx_text(s, 30, 88, "x86-64, MaXOS is alpha.",
             0x7A7A7A, FONT_UI, 0);

    gfx_hline(s, 24, 118, W - 48, 0xC8C8C8);
    gfx_hline(s, 24, 119, W - 48, 0xFFFFFF);

    mm_info(&ht, &hu, &kimg);

    strcpy(left[n], "Processor");
    ksnprintf(right[n], sizeof(right[0]),
              "x86-64, PIT %u Hz", PIT_HZ); n++;
    strcpy(left[n], "Memory");
    ksnprintf(right[n], sizeof(right[0]),
              "%u MiB phys, heap %u KiB (%u KiB used)",
              PHYS_MEM_MB, (u32)(ht >> 10), (u32)(hu >> 10)); n++;
    strcpy(left[n], "Graphics");
    ksnprintf(right[n], sizeof(right[0]), "%ux%u, %u bpp, LFB %p",
              fb.width, fb.height, fb.bpp, (void *)(usize)fb.base); n++;
    strcpy(left[n], "Multitasking");
    ksnprintf(right[n], sizeof(right[0]), "Round Robin, %d/%d tasks, CPU: %u%%",
              sched_count(), MAX_TASKS, (unsigned)sched_load()); n++;
    strcpy(left[n], "Uptime at");
    ksnprintf(right[n], sizeof(right[0]), "%u s, %llu ticks",
              (u32)(sched_uptime_ms() / 1000), sched_ticks()); n++;

    int y = 132;
    for (int i = 0; i < n; i++) {
        gfx_text(s, 34, y, left[i], 0x6A6A6A, FONT_UI, 1);
        gfx_text(s, 150, y, right[i], 0x1A1A1A, FONT_UI, 0);
        y += 21;
    }

    y += 2;
    gfx_hline(s, 24, y, W - 48, 0xC8C8C8);
    gfx_hline(s, 24, y + 1, W - 48, 0xFFFFFF);
    y += 14;
    gfx_text(s, 34, y, "The MaXOS (C) lev445",
             0x4A4A4A, FONT_UI, 0);

    w->repaint = 1;                     /* цифры живые */
}

static void about_key(win_t *w, const key_t *k)
{
    if (k->ch == '\n' || k->code == KEY_ESC || k->ch == ' ') gui_close(w);
}

/* =====================================================================
 *  Terminal (maxsh). Показывает хвост журнала ядра + строку ввода.
 * =================================================================== */
static char term_in[112];
static int  term_len;
static int  term_skip;
static int  term_hist_idx;
static char term_hist[8][112];
static int  term_hist_n;

static int has_word(const char *hay, const char *needle)
{
    usize nl = strlen(needle);
    if (!nl) return 1;
    for (const char *p = hay; *p; p++)
        if (!strncmp(p, needle, nl)) return 1;
    return 0;
}

static void term_out(const char *fmt, ...)
{
    char buf[176];
    va_list ap;
    va_start(ap, fmt);
    kvsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    klog("%s", buf);
}

static void cmd_help(void)
{
    term_out("term: commands:");
    term_out("  help             this list");
    term_out("  ps               list kernel tasks");
    term_out("  mem              memory / heap info");
    term_out("  gfx              compositor frame cost (rdtsc)");
    term_out("  ver              kernel version");
    term_out("  time | date      CMOS clock");
    term_out("  uptime           time since boot");
    term_out("  log              show the whole kernel log");
    term_out("  open <app>       about | terminal | activity | bounce | calc");
    term_out("  close            close this window");
    term_out("  hog              4 s CPU burn (watch the beachball spin)");
    term_out("  beep             PC speaker");
    term_out("  echo <text>      echo text");
    term_out("  clear            clear the screen");
    term_out("  neofetch         the important one");
    term_out("  shutdown | reboot  power management");
}

static void cmd_ps(void)
{
    term_out("term:  ID  NAME                 STATE      CPU   CTXSW   STACK");
    for (int i = 0; i < MAX_TASKS; i++) {
        task_t *t = &tasks[i];
        if (t->state == TASK_FREE) continue;
        term_out("      %2d  %-20s %-9s %3u%% %7u   %p",
                 t->id, t->name, task_state_name(t->state),
                 (unsigned)t->cpu_pct, (u32)t->switches, (void *)t->stack);
    }
    term_out("term: load %u%%, %d tasks, quantum %d ticks of %u Hz",
             (unsigned)sched_load(), sched_count(), SCHED_QUANTUM, (unsigned)SCHED_HZ);
}

static void cmd_mem(void)
{
    usize ht, hu, ki;
    mm_info(&ht, &hu, &ki);
    term_out("term: physical   : %u MiB (assumed; stage2 does not pass e820)", PHYS_MEM_MB);
    term_out("term: kernel img : %u KiB at 0x00100000", (u32)(ki >> 10));
    term_out("term: heap total : %u KiB", (u32)(ht >> 10));
    term_out("term: heap used  : %u KiB", (u32)(hu >> 10));
    term_out("term: heap free  : %u KiB", (u32)((ht - hu) >> 10));
    term_out("term: fb canvas  : %u KiB (screen) + %u KiB (wallpaper)",
             (u32)((usize)fb.width * fb.height * 4 / 1024),
             (u32)((usize)fb.width * fb.height * 4 / 1024));
}

static void cmd_neofetch(void)
{
    static const char *logo[6] = {
        " #...#   .###.   #...#   .###.   .#### ",
        " ##.##   #...#   .#.#.   #...#   #.... ",
        " #.#.#   #####   ..#..   #...#   .###. ",
        " #...#   #...#   .#.#.   #...#   ....# ",
        " #...#   #...#   #...#   .###.   ####. ",
        "                                       "
    };
    usize ht, hu;
    mm_info(&ht, &hu, NULL);
    char st[6][80];
    ksnprintf(st[0], sizeof st[0], "max@maxos");
    ksnprintf(st[1], sizeof st[1], "OS: MaXOS 0.1 \"Aqua\" x86_64");
    ksnprintf(st[2], sizeof st[2], "Kernel: MaXKernel-Beta");
    ksnprintf(st[3], sizeof st[3], "Uptime: %u s   Ticks: %llu",
              (u32)(sched_uptime_ms() / 1000), sched_ticks());
    ksnprintf(st[4], sizeof st[4], "Tasks: %d   Load: %u%%   Heap: %uK/%uK",
              sched_count(), (unsigned)sched_load(), (u32)(hu >> 10), (u32)(ht >> 10));
    ksnprintf(st[5], sizeof st[5], "Display: %ux%ux%u VBE LFB   Shell: maxsh",
              fb.width, fb.height, fb.bpp);
    for (int i = 0; i < 6; i++)
        term_out("%s | %s", logo[i], st[i]);
}

static void cmd_open(const char *arg)
{
    while (*arg == ' ') arg++;
    int id = -1;
    if (!strcmp(arg, "about"))              id = APP_ABOUT;
    else if (!strcmp(arg, "terminal"))      id = APP_TERMINAL;
    else if (!strcmp(arg, "activity"))      id = APP_ACTIVITY;
    else if (!strcmp(arg, "bounce"))        id = APP_BOUNCE;
    else if (!strcmp(arg, "calc"))          id = APP_CALC;
    if (id < 0) { term_out("term: open: unknown app '%s'", arg); return; }
    term_out("term: launching %s", app_names[id]);
    app_launch(id);
}

/* Калибровка: rdtc в эмуляторе врёт (там host-циклы), поэтому меряем
 * эталонную цепочку из 1M зависимых итераций (~1 цикл каждая на железе)
 * и делим на неё. На реальном CPU cal ~= 1M и числа становятся честными. */
static u64 gfx_calibrate(void)
{
    static u64 cal;
    if (!cal) {
        volatile u64 x = 0;
        u64 t0 = rdtsc();
        for (u32 i = 0; i < 1000000u; i++) x++;
        cal = rdtsc() - t0;
        if (cal < 1000) cal = 1000000;
    }
    return cal;
}

static void cmd_gfx(void)
{
    u64 n, ca, cl, fa, fl, px;
    gui_stats(&n, &ca, &cl, &fa, &fl, &px);
    u64 cal = gfx_calibrate();
    term_out("term: composes=%llu, pixels/frame=%llu, cal=%llu cyc/1M iter",
             n, px, cal);
    term_out("term: compose avg %llu.%02llu Mcyc, last %llu.%02llu Mcyc",
             ca / cal, (ca % cal) * 100 / cal, cl / cal, (cl % cal) * 100 / cal);
    term_out("term: fb_flush avg %llu.%02llu Mcyc, last %llu.%02llu Mcyc",
             fa / cal, (fa % cal) * 100 / cal, fl / cal, (fl % cal) * 100 / cal);
    term_out("term: frame ~%llu.%02llu Mcyc (= ms @1GHz): compose+flush",
             (ca + fa) / cal, ((ca + fa) % cal) * 100 / cal);
}

static void cmd_time(void)
{
    datetime_t dt;
    rtc_read(&dt);
    if (!dt.valid) rtc_fake_from_uptime(&dt, sched_uptime_ms());
    term_out("term: %04u-%02u-%02u %02u:%02u:%02u%s",
             (unsigned)dt.year, (unsigned)dt.month, (unsigned)dt.day,
             (unsigned)dt.hour, (unsigned)dt.min, (unsigned)dt.sec,
             dt.valid ? " (CMOS RTC)" : " (fake clock, RTC invalid)");
}

static void term_run(char *line)
{
    while (*line == ' ') line++;
    if (!*line) return;

    char cmd[24], arg[96];
    const char *sp = strchr(line, ' ');
    if (sp) {
        usize n = (usize)(sp - line);
        if (n >= sizeof(cmd)) n = sizeof(cmd) - 1;
        memcpy(cmd, line, n);
        cmd[n] = 0;
        strncpy(arg, sp + 1, sizeof(arg) - 1);
        arg[sizeof(arg) - 1] = 0;
    } else {
        strncpy(cmd, line, sizeof(cmd) - 1);
        cmd[sizeof(cmd) - 1] = 0;
        arg[0] = 0;
    }

    if (!strcmp(cmd, "help"))                      cmd_help();
    else if (!strcmp(cmd, "ps") || !strcmp(cmd, "tasks")) cmd_ps();
    else if (!strcmp(cmd, "mem") || !strcmp(cmd, "meminfo")) cmd_mem();
    else if (!strcmp(cmd, "neofetch"))             cmd_neofetch();
    else if (!strcmp(cmd, "open"))                 cmd_open(arg);
    else if (!strcmp(cmd, "time") || !strcmp(cmd, "date")) cmd_time();
    else if (!strcmp(cmd, "gfx")) cmd_gfx();
    else if (!strcmp(cmd, "log")) { term_skip = 0;
                                    term_out("term: showing %d log lines", log_count()); }
    else if (!strcmp(cmd, "ver") || !strcmp(cmd, "uname"))
        term_out("term: %s %s \"%s\" x86_64, build %s",
                 MAXOS_NAME, MAXOS_VERSION, MAXOS_CODENAME, MAXOS_BUILD);
    else if (!strcmp(cmd, "uptime"))
        term_out("term: up %u s, %llu ticks, %d tasks alive",
                 (u32)(sched_uptime_ms() / 1000), sched_ticks(), sched_count());
    else if (!strcmp(cmd, "clear"))                term_skip = log_count();
    else if (!strcmp(cmd, "hog") || !strcmp(cmd, "spin")) {
        term_out("term: spawning a CPU hog for 4s");
        app_hog(NULL);
    }
    else if (!strcmp(cmd, "beep"))                 gui_beep();
    else if (!strcmp(cmd, "echo"))                 term_out("term: %s", arg);
    else if (!strcmp(cmd, "close"))              { term_out("term: bye"); gui_close(w_term); }
    else if (!strcmp(cmd, "shutdown"))             gui_request_shutdown();
    else if (!strcmp(cmd, "reboot"))             { term_out("term: rebooting");
                                                   gui_request_restart(); }
    else term_out("term: %s: command not found (try 'help')", cmd);
}

static int  term_seen_n = -1;
static char term_seen_in[160];
static int  term_seen_blink = -1;
static int  term_cx, term_cy;

static void term_cell_bg(surf_t *s, int x, int y)
{
    gfx_fill(s, x, y, 10, 16, 0x101418);
    for (int yy = y; yy < y + 16; yy += 3)
        gfx_blend(s, x, yy, 10, 1, 0xFFFFFF, 5);
}

static void term_paint(win_t *w)
{
    surf_t *s = &w->surf;
    int rows = w->ch / 16;

    int n = log_count();
    int blink = (int)((sched_uptime_ms() / 500) & 1);
    int content = (n != term_seen_n) || strcmp(term_in, term_seen_in) != 0;

    if (!content && term_seen_blink >= 0 && blink == term_seen_blink) {
        w->repaint = 1;                 /* ни контент, ни курсор не меняются */
        return;
    }

    if (!content && term_seen_blink >= 0) {
        /* мигнул только курсор: гасим/рисуем одну клетку */
        term_cell_bg(s, term_cx, term_cy);
        if (blink == 0)
            gfx_fill(s, term_cx + 1, term_cy + 3, 7, 11, 0x9BE89B);
        gui_damage_surf(w, term_cx, term_cy, 10, 16);
        term_seen_blink = blink;
        w->repaint = 1;
        return;
    }

    gfx_fill(s, 0, 0, w->cw, w->ch, 0x101418);
    for (int y = 0; y < w->ch; y += 3)
        gfx_blend(s, 0, y, w->cw, 1, 0xFFFFFF, 5);

    int first = term_skip;
    if (first > n) first = n;
    int avail = rows - 1;
    if (avail < 1) avail = 1;
    int show = n - first;
    if (show > avail) { first = n - avail; show = avail; }

    int cols = w->cw / 8 - 1;          /* строк шире окна у нас нет: обрезаем */
    char cut[160];

    int y = 3;
    for (int i = 0; i < show; i++) {
        const char *ln = log_get(first + i);
        u32 c = 0xD6DEE6;
        if (has_word(ln, "PANIC") || has_word(ln, "!!!"))     c = 0xFF7B72;
        else if (has_word(ln, "term:"))                       c = 0x9BE89B;
        else if (has_word(ln, "error") || has_word(ln, "fail")) c = 0xFFC46B;
        else if (has_word(ln, "gui:") || has_word(ln, "sched:")) c = 0x9BD0FF;
        usize len = strlen(ln);
        if (len > (usize)cols) len = (usize)cols;
        memcpy(cut, ln, len);
        cut[len] = 0;
        gfx_text(s, 6, y, cut, c, FONT_MONO, 0);
        y += 16;
    }

    char buf[160];
    ksnprintf(buf, sizeof buf, "max@kernel:~$ %s", term_in);
    usize bl = strlen(buf);
    if (bl > (usize)cols) { bl = (usize)cols; buf[bl] = 0; }
    gfx_text(s, 6, y, buf, 0x9BE89B, FONT_MONO, 0);
    term_cx = 6 + 8 * (int)bl;
    term_cy = y;
    if (blink == 0)
        gfx_fill(s, term_cx + 1, y + 3, 7, 11, 0x9BE89B);

    term_seen_n = n;
    strcpy(term_seen_in, term_in);
    term_seen_blink = blink;
    w->repaint = 1;                     /* курсор мигает */
}

static void term_key(win_t *w, const key_t *k)
{
    if (k->ch == '\n') {
        if (term_len) {
            if (term_hist_n < (int)ARRAY_LEN(term_hist)) term_hist_n++;
            else memmove(term_hist, term_hist + 1,
                         (ARRAY_LEN(term_hist) - 1) * sizeof(term_hist[0]));
            strncpy(term_hist[term_hist_n - 1], term_in, sizeof(term_hist[0]) - 1);
            term_hist[term_hist_n - 1][sizeof(term_hist[0]) - 1] = 0;
            term_out("term: %s", term_in);
            term_run(term_in);
        }
        term_len = 0; term_in[0] = 0;
        term_hist_idx = term_hist_n;
    } else if (k->ch == '\b') {
        if (term_len > 0) { term_len--; term_in[term_len] = 0; }
    } else if (k->code == KEY_UP && term_hist_idx > 0) {
        term_hist_idx--;
        strncpy(term_in, term_hist[term_hist_idx], sizeof(term_in) - 1);
        term_in[sizeof(term_in) - 1] = 0;
        term_len = (int)strlen(term_in);
    } else if (k->code == KEY_DOWN && term_hist_idx < term_hist_n) {
        term_hist_idx++;
        if (term_hist_idx == term_hist_n) { term_len = 0; term_in[0] = 0; }
        else {
            strncpy(term_in, term_hist[term_hist_idx], sizeof(term_in) - 1);
            term_in[sizeof(term_in) - 1] = 0;
            term_len = (int)strlen(term_in);
        }
    } else if (k->code == KEY_ESC) {
        term_len = 0; term_in[0] = 0;
    } else if (k->ch >= 32 && k->ch < 127) {
        if (term_len < (int)sizeof(term_in) - 1) {
            term_in[term_len++] = k->ch;
            term_in[term_len] = 0;
        }
    }
    w->repaint = 1;
}

win_t *term_win(void) { return w_term; }

/* =====================================================================
 *  Activity Monitor
 * =================================================================== */
#define HIST_N 96
static u32 cpu_hist[HIST_N];
static int hist_n, hist_head;
static u32 hist_ms;

static void act_paint(win_t *w)
{
    surf_t *s = &w->surf;
    int W = w->cw, H = w->ch;
    char b[128];

    u32 now = (u32)sched_uptime_ms();
    if (now - hist_ms >= 1000) {
        hist_ms = now;
        sched_account();
        cpu_hist[hist_head] = sched_load();
        hist_head = (hist_head + 1) % HIST_N;
        if (hist_n < HIST_N) hist_n++;
    }

    gfx_fill(s, 0, 0, W, H, 0xFFFFFF);
    gfx_grad_v(s, 0, 0, W, 22, 0xF7F9FB, 0xE4E9F0);
    gfx_hline(s, 0, 22, W, 0xB8C2CE);
    gfx_text(s, 8,   3, "ID",     0x3A4A5A, FONT_UI, 1);
    gfx_text(s, 40,  3, "Task",   0x3A4A5A, FONT_UI, 1);
    gfx_text(s, 168, 3, "State",  0x3A4A5A, FONT_UI, 1);
    gfx_text(s, 238, 3, "CPU",    0x3A4A5A, FONT_UI, 1);
    gfx_text(s, 286, 3, "Ctx sw", 0x3A4A5A, FONT_UI, 1);
    gfx_text(s, 348, 3, "Load",   0x3A4A5A, FONT_UI, 1);

    int y = 24, row = 22, i = 0;
    for (int t = 0; t < MAX_TASKS && y + row < H - 110; t++) {
        task_t *tk = &tasks[t];
        if (tk->state == TASK_FREE) continue;
        gfx_fill(s, 0, y, W, row, (i++ & 1) ? 0xF4F7FA : 0xFFFFFF);
        ksnprintf(b, sizeof b, "%d", tk->id);
        gfx_text(s, 8, y + 3, b, 0x2A2A2A, FONT_UI, 0);
        gfx_text(s, 40, y + 3, tk->name, 0x1A1A1A, FONT_UI, tk->state == TASK_RUNNING);
        u32 sc = (tk->state == TASK_RUNNING) ? 0x2E7D32 :
                 (tk->state == TASK_SLEEP)   ? 0x6A7A8A : 0xB26A00;
        gfx_text(s, 168, y + 3, task_state_name(tk->state), sc, FONT_UI, 0);
        ksnprintf(b, sizeof b, "%u%%", (unsigned)tk->cpu_pct);
        gfx_text(s, 238, y + 3, b, 0x1A1A1A, FONT_UI, 0);
        ksnprintf(b, sizeof b, "%u", (u32)tk->switches);
        gfx_text(s, 286, y + 3, b, 0x1A1A1A, FONT_UI, 0);
        int bw = (int)(tk->cpu_pct * 60 / 100);
        if (bw > 60) bw = 60;
        if (bw > 0) gfx_fill(s, 348, y + 7, bw, 8, tk->cpu_pct > 60 ? 0xE8574A : 0x7ED321);
        gfx_rect(s, 348, y + 7, 60, 8, 0xC8D0D8);
        y += row;
    }
    gfx_hline(s, 0, y, W, 0xC8D0D8);

    int gh = H - y - 40, gy = y + 8;
    if (gh < 24) gh = 24;
    gfx_fill(s, 8, gy, W - 16, gh, 0xF0F4F8);
    for (int g = 1; g < 4; g++)
        gfx_hline(s, 8, gy + gh * g / 4, W - 16, 0xDCE4EC);
    /* график нагрузки: столбики с градиентом + линия сверху, чтобы даже
     * 1-2% были видны, а не терялись в один пиксель */
    int bw2 = (W - 16) / HIST_N;
    if (bw2 < 1) bw2 = 1;
    int prev_top = -1;
    for (int k = 0; k < hist_n; k++) {
        int idx = (hist_head - hist_n + k + HIST_N * 2) % HIST_N;
        u32 v = cpu_hist[idx];
        if (v > 100) v = 100;
        int x = 8 + k * bw2;
        int bh = (int)(v * (u32)gh / 100);
        u32 col = v > 70 ? 0xE8574A : (v > 35 ? 0xF5A623 : 0x5BA85B);
        if (bh > 1)
            gfx_grad_v(s, x, gy + gh - bh, bw2, bh, col, mixc(col, 0xF0F4F8, 170));
        else if (bh > 0)
            gfx_fill(s, x, gy + gh - bh, bw2, bh, col);
        int top = gy + gh - (bh > 0 ? bh : 0);
        gfx_fill(s, x, top - 1, bw2, 1, col);      /* линия даже при 0% */
        if (prev_top >= 0) {
            /* связка соседних столбиков вертикальной риской */
            int lo = MIN(top, prev_top), hi = MAX(top, prev_top);
            if (hi - lo > 1) gfx_fill(s, x, lo, 1, hi - lo, col);
        }
        prev_top = top;
    }
    gfx_rect(s, 8, gy, W - 16, gh, 0xB8C2CE);
    ksnprintf(b, sizeof b, "CPU load, last %d s   now %u%%",
              hist_n, (unsigned)sched_load());
    gfx_text(s, 12, gy + 2, b, 0x8A98A8, FONT_UI, 0);

    ksnprintf(b, sizeof b, "load %u%%   tasks %d   uptime %u s   tick %u ms   quantum %u ms",
              (unsigned)sched_load(), sched_count(),
              (u32)(sched_uptime_ms() / 1000), 1000 / (unsigned)SCHED_HZ,
              1000 * SCHED_QUANTUM / (unsigned)SCHED_HZ);
    gfx_text(s, 8, gy + gh + 10, b, 0x3A4A5A, FONT_UI, 0);

    w->repaint = 1;
}

static void act_key(win_t *w, const key_t *k)
{
    if (k->ch == 'h' || k->ch == 'H') { app_hog(NULL); gui_beep(); }
    if (k->ch == 'r' || k->ch == 'R') { hist_n = hist_head = 0; }
    w->repaint = 1;
}

/* =====================================================================
 *  Bounce: физика в собственном потоке
 * =================================================================== */
#define FX 8                    /* сдвиг фиксированной точки: px << 8 */
typedef struct {
    i32 x, y;                   /* px << FX */
    i32 vx, vy;                 /* px/s << FX */
    u32 last_ms, frames, fps_ms, fps;
    int tx[8], ty[8], tn;
} bounce_t;
static bounce_t B;

static void bounce_paint(win_t *w)
{
    surf_t *s = &w->surf;
    int W = w->cw, H = w->ch;
    u32 now = (u32)sched_uptime_ms();
    u32 dt = now - B.last_ms;
    if (dt > 200) dt = 200;
    B.last_ms = now;

    if (B.x == 0 && B.y == 0 && B.vx == 0) {
        B.x = (W << (FX - 1));
        B.y = (H << (FX - 2));
        B.vx = 140 << FX;
        B.vy = 0;
    }

    B.vy += (900 << FX) * (i32)dt / 1000;       /* g = 900 px/s^2 */
    B.x  += (i32)(((i64)B.vx * dt) / 1000);
    B.y  += (i32)(((i64)B.vy * dt) / 1000);

    int r = 20 << FX;
    if (B.x < r) { B.x = r; B.vx = -(B.vx * 92 / 100); }
    if (B.x > ((W << FX) - r)) { B.x = (W << FX) - r; B.vx = -(B.vx * 92 / 100); }
    if (B.y > ((H << FX) - r)) {
        B.y = (H << FX) - r;
        B.vy = -(B.vy * 78 / 100);
        B.vx = B.vx * 995 / 1000;
        if (B.vy > -(60 << FX)) B.vy = -(330 << FX);   /* не даём улечься */
    }
    if (B.y < r) { B.y = r; B.vy = -(B.vy * 92 / 100); }

    B.frames++;
    if (now - B.fps_ms >= 1000) {
        B.fps = B.frames * 1000 / (now - B.fps_ms ? now - B.fps_ms : 1);
        B.frames = 0;
        B.fps_ms = now;
    }

    static const u32 st[3] = { 0x2E4A6E, 0x1E3350, 0x14243A };
    gfx_grad_stops(s, 0, 0, W, H, st, 3);
    for (int x = 0; x < W; x += 24) gfx_blend(s, x, 0, 1, H, 0xFFFFFF, 14);
    for (int y = 0; y < H; y += 24) gfx_blend(s, 0, y, W, 1, 0xFFFFFF, 14);
    gfx_hline(s, 0, H - 2, W, 0x6A8AB0);

    int bx = B.x >> FX, by = B.y >> FX, br = 20;

    memmove(&B.tx[1], &B.tx[0], sizeof(B.tx[0]) * 7);
    memmove(&B.ty[1], &B.ty[0], sizeof(B.ty[0]) * 7);
    B.tx[0] = bx; B.ty[0] = by;
    if (B.tn < 8) B.tn++;
    for (int i = B.tn - 1; i >= 1; i--)
        gfx_circle_blend(s, B.tx[i], B.ty[i], br - 4 - i, 0x8FC1F5, (u32)(70 - i * 7));

    gfx_circle_blend(s, bx, H - 6, 8 + (H - by) / 30, 0x000000, 70);
    gfx_circle(s, bx, by, br, 0xE8574A);
    gfx_circle_blend(s, bx - 6, by - 7, br - 11, 0xFFFFFF, 130);
    gfx_circle_blend(s, bx, by + br - 7, br - 9, 0x8A1F14, 100);

    char b[96];
    ksnprintf(b, sizeof b, "%u fps", (unsigned)B.fps);
    gfx_text(s, 10, 6, b, 0xBFD8F5, FONT_MONO, 0);
    task_t *me = sched_current();
    ksnprintf(b, sizeof b, "thread '%s' #%d", me ? me->name : "?", me ? me->id : -1);
    gfx_text(s, 10, 24, b, 0x8FA9C8, FONT_MONO, 0);
    ksnprintf(b, sizeof b, "x=%4d y=%4d vy=%5d", bx, by, B.vy >> FX);
    gfx_text(s, 10, 42, b, 0x8FA9C8, FONT_MONO, 0);
    gfx_text(s, 10, H - 44, "space = kick, R = reset", 0x6A8AB0, FONT_UI, 0);

    w->repaint = 1;
}

static void bounce_mouse(win_t *w, int x, int y, u8 buttons, int pressed)
{
    (void)x; (void)y;
    if (pressed && (buttons & MB_LEFT)) { B.vy = -(420 << FX); gui_beep(); w->repaint = 1; }
}

static void bounce_key(win_t *w, const key_t *k)
{
    if (k->ch == ' ') { B.vy = -(420 << FX); gui_beep(); }
    if (k->ch == 'r' || k->ch == 'R') { B.vx = 140 << FX; B.vy = 0; }
    w->repaint = 1;
}

/* =====================================================================
 *  Calculator
 * =================================================================== */
typedef struct {
    i64 acc, cur;
    char op;
    int fresh;
    char flash;
    u32 flash_ms;
} calc_t;
static calc_t C;

static const char calc_grid[5][4] = {
    { 'C',   0,   0,  '/' },
    { '7', '8', '9', '*' },
    { '4', '5', '6', '-' },
    { '1', '2', '3', '+' },
    { '0', '.', '=',   0  }
};

static void calc_layout(win_t *w, int *bx, int *by, int *bw, int *bh)
{
    int W = w->cw, H = w->ch;
    *bx = 10;
    *by = 8 + 48 + 10;
    *bw = (W - 2 * 10 - 3 * 6) / 4;
    *bh = (H - *by - 12 - 4 * 6) / 5;
    if (*bh < 18) *bh = 18;
}

static char calc_hit(win_t *w, int x, int y)
{
    int bx, by, bw, bh;
    calc_layout(w, &bx, &by, &bw, &bh);
    for (int r = 0; r < 5; r++)
        for (int c = 0; c < 4; c++) {
            char k = calc_grid[r][c];
            int wide = (r == 0 && c == 0);
            if (!k && !wide) continue;
            int kx = bx + c * (bw + 6), ky = by + r * (bh + 6);
            int kw = wide ? bw * 3 + 12 : bw;
            if (x >= kx && x < kx + kw && y >= ky && y < ky + bh)
                return wide ? 'C' : k;
        }
    return 0;
}

static void calc_eval(char op)
{
    switch (op) {
    case '+': C.acc += C.cur; break;
    case '-': C.acc -= C.cur; break;
    case '*': C.acc *= C.cur; break;
    case '/': C.acc = C.cur ? C.acc / C.cur : 0; break;
    default:  C.acc = C.cur; break;
    }
    C.cur = C.acc;
}

static void calc_press(char k)
{
    C.flash = k;
    C.flash_ms = (u32)sched_uptime_ms();
    if (k >= '0' && k <= '9') {
        if (C.fresh) { C.cur = 0; C.fresh = 0; }
        if (C.cur < 999999999999LL) C.cur = C.cur * 10 + (k - '0');
    } else if (k == '.') {
        C.fresh = 0;
    } else if (k == 'C') {
        C.acc = C.cur = 0; C.op = 0; C.fresh = 1;
    } else if (k == '+' || k == '-' || k == '*' || k == '/') {
        if (C.op && !C.fresh) calc_eval(C.op);
        else if (!C.op) C.acc = C.cur;
        C.op = k;
        C.fresh = 1;
    } else if (k == '=') {
        if (C.op) calc_eval(C.op);
        C.op = 0;
        C.fresh = 1;
        gui_beep();
    }
}

static void calc_paint(win_t *w)
{
    surf_t *s = &w->surf;
    int W = w->cw, H = w->ch;
    u32 st[2];

    gfx_grad_v(s, 0, 0, W, H, 0xF4F4F4, 0xDCDCDC);
    for (int x = 0; x < W; x += 2) gfx_blend(s, x, 0, 1, H, 0xFFFFFF, 60);

    int dm = 10, dh = 48;
    gfx_round(s, dm, 8, W - 2 * dm, dh, 6, 0x2C3E50);
    gfx_round(s, dm + 1, 9, W - 2 * dm - 2, dh / 2, 5, 0x3A5068);
    gfx_round_outline(s, dm, 8, W - 2 * dm, dh, 6, 0x1A2A3A, 256);
    char d[40];
    if (C.op) {
        ksnprintf(d, sizeof d, "%lld %c", C.acc, C.op);
        gfx_text(s, dm + 8, 12, d, 0x7FA8C8, FONT_MONO, 0);
    }
    ksnprintf(d, sizeof d, "%lld", C.cur);
    i32 tw = (i32)gfx_text_width(d, FONT_MONO);
    gfx_text(s, W - dm - 8 - tw, 8 + dh - 20, d, 0x9BE89B, FONT_MONO, 0);

    int bx, by, bw, bh;
    calc_layout(w, &bx, &by, &bw, &bh);
    int flash_on = C.flash && ((u32)sched_uptime_ms() - C.flash_ms < 130);

    for (int r = 0; r < 5; r++) {
        for (int c = 0; c < 4; c++) {
            char k = calc_grid[r][c];
            int x = bx + c * (bw + 6), y = by + r * (bh + 6);
            if (r == 0 && c == 0) {                     /* Clear во всю ширину */
                int ww = bw * 3 + 12;
                u32 cl[3] = { 0xFFFFFF, 0xF0F0F0, 0xDCDCDC };
                gfx_grad_stops(s, x, y, ww, bh, cl, 3);
                gfx_round_outline(s, x, y, ww, bh, 8, 0x8A8A8A, 256);
                gfx_blend(s, x + 4, y + 2, ww - 8, bh / 3, 0xFFFFFF, 140);
                gfx_text(s, x + 10, y + (bh - 18) / 2 + 1, "Clear", 0x1A1A1A, FONT_UI, 0);
                continue;
            }
            if (!k) continue;
            int isop = (k == '*' || k == '/' || k == '-' || k == '+' || k == '=');
            int pressed = flash_on && C.flash == k;
            st[0] = isop ? (pressed ? 0xD9822B : 0xFBCB5A) : (pressed ? 0xC8D8E8 : 0xFFFFFF);
            st[1] = isop ? (pressed ? 0xB96A1B : 0xE8942B) : (pressed ? 0xA8B8C8 : 0xDCDCDC);
            gfx_grad_stops(s, x, y, bw, bh, st, 2);
            gfx_round_outline(s, x, y, bw, bh, 8, isop ? 0xA05E10 : 0x8A8A8A, 256);
            gfx_blend(s, x + 3, y + 2, bw - 6, bh / 3, 0xFFFFFF, isop ? 70 : 140);
            char lb[2] = { k, 0 };
            i32 lw = (i32)gfx_text_width(lb, FONT_UI);
            gfx_text(s, x + (bw - lw) / 2, y + (bh - 18) / 2 + 1, lb,
                     isop ? 0x3A2200 : 0x1A1A1A, FONT_UI, 1);
        }
    }
    if (C.flash && (u32)sched_uptime_ms() - C.flash_ms >= 130) C.flash = 0;
    if (C.flash) w->repaint = 1;
}

static void calc_mouse(win_t *w, int x, int y, u8 buttons, int pressed)
{
    if (pressed && (buttons & MB_LEFT)) {
        char key = calc_hit(w, x, y);
        if (key) { calc_press(key); w->repaint = 1; }
    }
}

static void calc_key(win_t *w, const key_t *k)
{
    char c = k->ch;
    if (c >= '0' && c <= '9')                              calc_press(c);
    else if (c == '+' || c == '-' || c == '*' || c == '/') calc_press(c);
    else if (c == '\n' || c == '=')                        calc_press('=');
    else if (c == '.' || c == ',')                         calc_press('.');
    else if (c == 'c' || c == 'C' || c == '\b' || k->code == KEY_ESC) calc_press('C');
    w->repaint = 1;
}

/* =====================================================================
 *  Демо «тяжёлой» задачи: поток, который НЕ спит.
 *  Планировщик вытесняет его по тику, поэтому beachball крутится,
 *  а GUI остаётся живым. Лучшая проверка вытесняющей многозадачности.
 * =================================================================== */
static void hog_task(void *arg)
{
    (void)arg;
    gui_set_busy(1);
    klog("hog: creating TODOs");
    u64 t0 = sched_uptime_ms();
    volatile u64 n = 0;
    while (sched_uptime_ms() - t0 < 4000) n++;
    klog("hog: done, %llu iterations", n);
    gui_set_busy(0);
    task_exit();
}

void app_hog(void *arg)
{
    (void)arg;
    if (task_create("hog", hog_task, NULL) < 0)
        klog("hog: cannot create task (no slots)");
}

/* =====================================================================
 *  Запуск
 * =================================================================== */
static void dock_bounce(void)
{
    app_bounce_ms = 900;
    bounce_t0 = (u32)sched_uptime_ms();
}

void apps_tick(void)
{
    if (!app_bounce_ms) return;
    u32 e = (u32)sched_uptime_ms() - bounce_t0;
    app_bounce_ms = (e < 900) ? (u32)(900 - e) : 0;
}

win_t *app_launch(int id)
{
    win_t *w = NULL;

    switch (id) {
    case APP_ABOUT:
        w = w_about;
        if (!w || !w->used)
            w = w_about = gui_window("About MaXOS", 210, 80, 560, 420, WIN_METAL,
                                     about_paint, about_key, NULL, 250, "about");
        break;
    case APP_TERMINAL:
        w = w_term;
        if (!w || !w->used) {
            w = w_term = gui_window("Terminal -- maxsh", 400, 50, 570, 420, WIN_TERM,
                                    term_paint, term_key, NULL, 120, "terminal");
            if (w) { w->app = APP_TERMINAL; term_skip = 0; term_len = 0; term_in[0] = 0; }
        }
        break;
    case APP_ACTIVITY:
        w = w_act;
        if (!w || !w->used)
            w = w_act = gui_window("Activity Monitor", 30, 150, 470, 420, WIN_AQUA,
                                   act_paint, act_key, NULL, 120, "activity");
        break;
    case APP_BOUNCE:
        w = w_bounce;
        if (!w || !w->used) {
            memset(&B, 0, sizeof(B));
            w = w_bounce = gui_window("Bounce", 590, 300, 340, 320, WIN_AQUA,
                                      bounce_paint, bounce_key, NULL, 20, "bounce");
        }
        break;
    case APP_CALC:
        w = w_calc;
        if (!w || !w->used)
            w = w_calc = gui_window("Calculator", 730, 70, 250, 340, WIN_AQUA,
                                    calc_paint, calc_key, NULL, 80, "calculator");
        break;
    default:
        return NULL;
    }

    if (w) {
        w->app = id;
        w->on_mouse = (id == APP_CALC) ? calc_mouse :
                      (id == APP_BOUNCE) ? bounce_mouse : NULL;
        dock_bounce();
        gui_focus(w);
        gui_redraw(w);
    }
    return w;
}

void apps_init(void)
{
    klog("apps: starting Terminal and Activity Monitor");
}
