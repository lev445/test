#include "mouse.h"
#include "klib.h"
#include "sched.h"
#include "log.h"

/* =====================================================================
 *  PS/2 мышь через контроллер 8042 (aux-порт).
 *
 *  Инициализация по классике:
 *    1) в command byte контроллера: bit1 = IRQ12 разрешён, bit5 (disable
 *       aux) снят;
 *    2) команда 0xA8 контроллеру -- включить aux-устройство;
 *    3) мыши: 0xF6 (дефолты), магическая последовательность sample rate
 *       200/100/80 и 0xF2 -- спросить id: id=3 означает Intellimouse с
 *       колесом (4-байтный пакет), id=0 -- обычная (3 байта);
 *    4) 0xF4 -- разрешить репорты. Дальше пакеты приходят на IRQ12.
 *
 *  Пакет: [buttons|signs|always1][dx][dy][wheel]
 * =================================================================== */

#define KBD_CMD  0x64
#define KBD_DATA 0x60

static int present;
static int plen = 3;
static u8  pkt[4];
static int pidx;

#define MQUEUE 32
static mouse_evt_t mq[MQUEUE];
static volatile int mq_head, mq_tail;

static void wait_write(void)
{
    int t = 100000;
    while ((inb(KBD_CMD) & 2) && --t > 0) ;
}

static void wait_read(void)
{
    int t = 100000;
    while (!(inb(KBD_CMD) & 1) && --t > 0) ;
}

static u8 ctl_read(u8 cmd)
{
    wait_write(); outb(KBD_CMD, cmd); wait_read(); return inb(KBD_DATA);
}

static void ctl_write(u8 cmd, u8 val)
{
    wait_write(); outb(KBD_CMD, cmd); wait_write(); outb(KBD_DATA, val);
}

/* посылка байта мыши через 0xD4 ("write to aux") */
static void aux_send(u8 b)
{
    wait_write(); outb(KBD_CMD, 0xD4); wait_write(); outb(KBD_DATA, b);
}

static int aux_ack(void)
{
    wait_read();
    return inb(KBD_DATA) == 0xFA;
}

static u8 aux_read(void)
{
    wait_read();
    return inb(KBD_DATA);
}

static int aux_cmd(u8 cmd)
{
    aux_send(cmd);
    return aux_ack();
}

int mouse_present(void) { return present; }

int mouse_init(void)
{
    /* command byte: IRQ12 (bit1) включить, disable-aux (bit5) снять */
    u8 status = ctl_read(0x20);
    ctl_write(0x60, (u8)((status | 0x02) & ~0x20));

    wait_write();
    outb(KBD_CMD, 0xA8);              /* enable aux device */

    if (!aux_cmd(0xF6)) {             /* set defaults */
        klog("mouse: no PS/2 aux device (no ack on 0xF6) -- keyboard only");
        return present = 0;
    }

    /* Intellimouse handshake: rate 200, 100, 80 -> get id */
    aux_send(0xF3); if (aux_ack()) { aux_send(200); if (!aux_ack()) goto no_wheel; }
    aux_send(0xF3); if (aux_ack()) { aux_send(100); if (!aux_ack()) goto no_wheel; }
    aux_send(0xF3); if (aux_ack()) { aux_send(80);  if (!aux_ack()) goto no_wheel; }
    aux_send(0xF2);
    if (aux_ack()) {
        u8 id = aux_read();
        if (id == 3) plen = 4;
        klog("mouse: aux id=%u (%s)", (unsigned)id,
             plen == 4 ? "Intellimouse, wheel on" : "standard, 3-byte packets");
    }
no_wheel:
    if (!aux_cmd(0xF4)) {             /* enable data reporting */
        klog("mouse: device refused 0xF4 -- disabled");
        return present = 0;
    }

    present = 1;
    klog("mouse: PS/2 mouse on IRQ12, %d-byte packets", plen);
    return 1;
}

void mouse_irq(void)
{
    u8 b = inb(KBD_DATA);
    if (!present) return;

    /* синхронизация: у первого байта пакета бит 3 всегда равен 1 */
    if (pidx == 0 && !(b & 0x08)) return;

    pkt[pidx++] = b;
    if (pidx < plen) return;
    pidx = 0;

    if (pkt[0] & 0xC0) return;        /* overflow -- выбрасываем пакет */

    mouse_evt_t e;
    e.dx = (i32)(i8)pkt[1];
    e.dy = (i32)(i8)pkt[2];
    e.wheel = (plen == 4) ? (i8)pkt[3] : 0;
    e.buttons = pkt[0] & 0x07;

    int next = (mq_head + 1) % MQUEUE;
    if (next != mq_tail) {
        mq[mq_head] = e;
        mq_head = next;
        sched_wake_gui();
    }
}

int mouse_pending(void) { return mq_head != mq_tail; }

int mouse_poll(mouse_evt_t *e)
{
    if (mq_head == mq_tail) return 0;
    *e = mq[mq_tail];
    mq_tail = (mq_tail + 1) % MQUEUE;
    return 1;
}
