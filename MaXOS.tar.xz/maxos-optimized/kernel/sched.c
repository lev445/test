#include "sched.h"
#include "mm.h"
#include "klib.h"
#include "log.h"
#include "cpu.h"
#include "idt.h"

/* из kernel/arch/lowlevel.S */
extern u64  cpu_switch(u64 *save_here, u64 restore_this);
extern void task_entry_stub(void);

task_t tasks[MAX_TASKS];

static int      nslots;        /* высокая вода по слотам */
static task_t  *cur;
static volatile u64 sys_ticks;
static int      sched_ready;
static int      quantum_cnt;

static int wake_id = -1;

void sched_set_wake_id(int id) { wake_id = id; }

/* Разбудить композитор досрочно (событие ввода). Безопасно: единственное
 * место, где чужое состояние пишется вне cli, -- переход SLEEP->READY,
 * он идемпотентен и гонится только с собственным cli-окном задачи. */
void sched_wake_gui(void)
{
    if (wake_id <= 0 || wake_id >= nslots) return;
    task_t *t = &tasks[wake_id];
    if (t->state == TASK_SLEEP) t->state = TASK_READY;
}

u64 sched_ticks(void)     { return sys_ticks; }
u64 sched_uptime_ms(void) { return (sys_ticks * 1000) / SCHED_HZ; }
task_t *sched_current(void) { return cur; }

const char *task_state_name(int st)
{
    switch (st) {
    case TASK_FREE:    return "free";
    case TASK_READY:   return "ready";
    case TASK_RUNNING: return "running";
    case TASK_SLEEP:   return "sleep";
    case TASK_DEAD:    return "dead";
    default:           return "?";
    }
}

void sched_init(void)
{
    memset(tasks, 0, sizeof(tasks));
    for (int i = 0; i < MAX_TASKS; i++) { tasks[i].id = i; tasks[i].state = TASK_FREE; }

    /* Слот 0 -- это контекст, в котором мы сейчас сидим (kmain).
     * После старта он превращается в задачу idle: hlt до следующего тика. */
    cur = &tasks[0];
    strncpy(cur->name, "idle", sizeof(cur->name) - 1);
    cur->state = TASK_RUNNING;
    cur->stack = NULL;                 /* стек kmain, освобождать нельзя */
    nslots = 1;
    sched_ready = 1;
    cpu_set_kernel_stack(0);
    klog("sched: preemptive round-robin, %u Hz, quantum %u ticks",
         SCHED_HZ, SCHED_QUANTUM);
}

int task_create(const char *name, void (*fn)(void *), void *arg)
{
    int slot = -1;
    for (int i = 1; i < MAX_TASKS; i++) {
        if (tasks[i].state == TASK_FREE) { slot = i; break; }
    }
    if (slot < 0) { klog("sched: no free task slots"); return -1; }

    task_t *t = &tasks[slot];
    u8 *stack = (u8 *)kzalloc(TASK_STACK_SIZE);
    if (!stack) { klog("sched: no memory for stack of '%s'", name); return -1; }

    t->stack      = stack;
    t->stack_size = TASK_STACK_SIZE;
    t->cpu_ticks = t->cpu_last = t->cpu_pct = t->switches = 0;
    t->wake_tick  = 0;
    memset(t->name, 0, sizeof(t->name));
    strncpy(t->name, name ? name : "task", sizeof(t->name) - 1);

    /* Собираем поддельный кадр cpu_switch.
     * cpu_switch делает: push rbx, rbp, r12, r13, r14, r15, pushfq --
     * значит в памяти сверху вниз: retaddr, rbx, rbp, r12, r13, r14, r15, rflags.
     * Дополнительно кладём пустой слот НАД retaddr, чтобы на входе в
     * task_entry_stub rsp был кратен 16 (требование SysV ABI).            */
    u64 *sp = (u64 *)(stack + TASK_STACK_SIZE);
    *--sp = 0;                       /* выравнивание            */
    *--sp = (u64)(usize)task_entry_stub; /* адрес возврата      */
    *--sp = 0;                       /* rbx */
    *--sp = 0;                       /* rbp */
    *--sp = (u64)(usize)fn;          /* r12 = точка входа */
    *--sp = (u64)(usize)arg;         /* r13 = аргумент    */
    *--sp = 0;                       /* r14 */
    *--sp = 0;                       /* r15 */
    *--sp = 0x202;                   /* rflags: IF=1, bit1 всегда 1 */
    t->ctx = (u64)(usize)sp;

    u64 f = irq_save();
    cli();
    t->state = TASK_READY;
    if (slot >= nslots) nslots = slot + 1;
    irq_restore(f);

    klog("sched: task #%d '%s' created (stack %p, %u KiB)",
         slot, t->name, (void *)stack, TASK_STACK_SIZE / 1024);
    return slot;
}

/* ---------------------------------------------------------------------
 *  Освобождаем ресурсы завершившихся задач. Вызывается только из
 *  do_schedule, то есть не на стеке умирающей задачи.
 * ------------------------------------------------------------------- */
static void reap(void)
{
    for (int i = 1; i < nslots; i++) {
        task_t *t = &tasks[i];
        if (t->state == TASK_DEAD && t != cur) {
            if (t->stack) { kfree(t->stack); t->stack = NULL; }
            t->ctx = 0;
            t->state = TASK_FREE;
        }
    }
}

/* Реентерабельность не нужна и невозможна: все точки входа сюда --
 * либо обработчик прерывания (IF=0), либо sched_sleep/sched_yield/
 * task_exit, которые сами делают cli(). Отдельный флаг «идёт
 * переключение» был бы даже вреден: строка после cpu_switch() в новом
 * потоке не выполняется никогда (он стартует через task_entry_stub). */
static void do_schedule(void)
{
    if (!sched_ready) return;

    reap();

    task_t *next = NULL;
    int n = nslots > 0 ? nslots : 1;
    for (int k = 1; k <= n; k++) {
        task_t *t = &tasks[(cur->id + k) % n];
        if (t->state == TASK_READY) { next = t; break; }
    }
    if (!next) next = &tasks[0];        /* idle всегда готов */

    if (next == cur) {
        /* Переключаться некуда. Если текущая задача RUNNING -- просто
         * продолжаем её. Если она SLEEP/DEAD и других готовых нет --
         * это логическая дыра в коде задач, сообщаем громко. */
        if (cur->state != TASK_RUNNING && cur->state != TASK_SLEEP)
            panic("sched: nothing to run (cur=%s)", cur->name);
        return;
    }

    task_t *prev = cur;
    if (prev->state == TASK_RUNNING) prev->state = TASK_READY;
    next->state = TASK_RUNNING;
    next->switches++;
    cur = next;

    /* на будущее: RSP0 для возврата из ring-3 в контекст новой задачи */
    if (next->stack)
        cpu_set_kernel_stack((u64)(usize)(next->stack + next->stack_size));

    cpu_switch(&prev->ctx, next->ctx);
    /* сюда мы вернёмся только когда ЭТОТ контекст resurrect'нут;
     * для новосозданных задач возврата не будет вовсе */
}

void sched_tick(void)
{
    sys_ticks++;
    if (!sched_ready || !cur) return;

    cur->cpu_ticks++;

    int woken = 0;
    for (int i = 0; i < nslots; i++) {
        task_t *t = &tasks[i];
        if (t->state == TASK_SLEEP && (i64)(sys_ticks - t->wake_tick) >= 0) {
            t->state = TASK_READY;
            woken = 1;
        }
    }

    if (++quantum_cnt >= SCHED_QUANTUM || woken) {
        quantum_cnt = 0;
        do_schedule();
    }
}

void sched_yield(void)
{
    if (!sched_ready) return;
    u64 f = irq_save();
    cli();
    if (cur && cur->state == TASK_RUNNING) do_schedule();
    irq_restore(f);
}

void sched_sleep_ms(u32 ms)
{
    if (!sched_ready) {
        /* планировщик ещё не запущен (ранняя инициализация) */
        for (volatile u32 i = 0; i < ms * 2000u; i++) cpu_pause();
        return;
    }
    u64 t = ((u64)ms * SCHED_HZ + 999) / 1000;
    if (t == 0) t = 1;

    u64 f = irq_save();
    cli();
    cur->wake_tick = sys_ticks + t;
    cur->state = TASK_SLEEP;
    do_schedule();
    if (cur->state == TASK_SLEEP) cur->state = TASK_RUNNING;
    irq_restore(f);
}

void task_exit(void)
{
    cli();          /* обратно мы уже не вернёмся */
    klog("sched: task '%s' finished", cur->name);
    cur->state = TASK_DEAD;
    do_schedule();
    for (;;) hlt();
}

void sched_account(void)
{
    for (int i = 0; i < nslots; i++) {
        task_t *t = &tasks[i];
        if (t->state == TASK_FREE) { t->cpu_pct = 0; continue; }
        u64 d = t->cpu_ticks - t->cpu_last;
        t->cpu_last = t->cpu_ticks;
        t->cpu_pct = (u32)((d * 100) / SCHED_HZ);
    }
}

u32 sched_load(void)
{
    u32 s = 0;
    for (int i = 1; i < nslots; i++)   /* 0 = idle */
        if (tasks[i].state != TASK_FREE) s += tasks[i].cpu_pct;
    return s;
}

int sched_count(void)
{
    int c = 0;
    for (int i = 0; i < nslots; i++)
        if (tasks[i].state != TASK_FREE) c++;
    return c;
}
