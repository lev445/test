#include "types.h"
#include "maxos.h"
#include "klib.h"
#include "serial.h"
#include "fb.h"
#include "console.h"
#include "log.h"
#include "mm.h"
#include "cpu.h"
#include "idt.h"
#include "input.h"
#include "mouse.h"
#include "sched.h"
#include "gui.h"
#include "apps.h"
#include "rtc.h"

/* =====================================================================
 *  MaXOS -- точка входа из C.
 *
 *  Аргументы приходят из kernel/arch/head.S (там они разбираются из
 *  VBE boot info, которую stage2 оставляет по адресу 0x30400).
 *
 *  Порядок инициализации важен:
 *      serial   -- чтобы было куда кричать, если всё упадёт
 *      fb       -- параметры видео
 *      console  -- текст по фреймбуферу (живёт до запуска GUI)
 *      mm       -- свои странички ядра + куча
 *      cpu      -- своя GDT и TSS (перезагружаем сегменты!)
 *      idt      -- IDT, PIC, PIT
 *      input    -- клавиатура
 *      sched    -- планировщик (текущий контекст = задача idle)
 *      gui      -- канвас, обои, док, меню-бар
 *      apps     -- окна и их потоки
 *      sti      -- и только теперь разрешаем прерывания
 *
 *  После sti() kmain превращается в задачу idle: hlt до следующего тика.
 * =================================================================== */

static void banner(void)
{
    if (!console_enabled()) return;
    console_set_fg(0x8FC1F5);
    console_printf("\n");
    console_printf("  ##   ##   ###   ##   ##   ####   ####\n");
    console_printf("  ### ###  ## ##   ## ##   ##  ##  ##\n");
    console_printf("  ## # ##  #####    ###    ##  ##   ###\n");
    console_printf("  ##   ##  ## ##   ## ##   ##  ##      ##\n");
    console_printf("  ##   ##  ## ##  ##   ##   ####    ####\n");
    console_printf("\n");
    console_set_fg(0xE8E8E8);
    console_printf("  %s %s \"%s\"  (build %s)\n", MAXOS_NAME, MAXOS_VERSION,
                   MAXOS_CODENAME, MAXOS_BUILD);
    console_printf("  64-bit kernel loading.\n");
    console_printf("  -------------------------------------------------\n");
    console_set_fg(0xE8E8E8);
}

void kmain(u32 w, u32 h, u32 bpp, u32 pitch, u64 fbase, u32 vbe_ok)
{
    serial_init();
    serial_write("\r\n\r\n");
    serial_write("=== " MAXOS_NAME " kernel starting ===\r\n");

    fb_init(w, h, bpp, pitch, fbase, vbe_ok);
    console_init();
    banner();

    klog("boot: entered long mode at 0x100000, stack %p", (void *)0x80000);
    klog("vbe : %s  %ux%u %ubpp pitch=%u lfb=%p mask r%u g%u b%u",
         fb.ok ? "ok" : "NOT AVAILABLE (text fallback)",
         fb.width, fb.height, fb.bpp, fb.pitch, (void *)(usize)fb.base,
         (unsigned)fb.rpos, (unsigned)fb.gpos, (unsigned)fb.bpos);
    if (!fb.ok)
        klog("vbe : GUI will render into a canvas that nobody sees; check stage2");

    mm_init();
    cpu_init();
    idt_init();
    input_init();
    klog("input: keyboard on IRQ1, scancode set 1");
    mouse_init();               /* PS/2 aux: IRQ12; если мыши нет -- живём с клавой */

    sched_init();

    gui_init();

    /* Поток композитора создаём до приложений: окна сразу начнут
     * заказывать перерисовку, а рисовать их есть кому. */
    if (task_create("WindowServer", gui_task, NULL) < 0)
        panic("cannot create WindowServer task");

    apps_init();

    datetime_t dt;
    rtc_read(&dt);
    if (dt.valid)
        klog("rtc : %04u-%02u-%02u %02u:%02u:%02u",
             (unsigned)dt.year, (unsigned)dt.month, (unsigned)dt.day,
             (unsigned)dt.hour, (unsigned)dt.min, (unsigned)dt.sec);
    else
        klog("rtc : CMOS invalid, using uptime-based clock");

    klog("boot: init done in %llu ms, handing over to the scheduler",
         sched_uptime_ms());
    klog("gui : Aqua compositor started, %d window(s), %d task(s)",
         gui_window_count(), sched_count());

    /* Консоль больше не хозяйка экрана -- её перехватил композитор. */
    console_disable();

    sti();
    klog("idle: interrupts on, entering hlt loop");

    /* Задача 0: idle. Спим до следующего прерывания, планировщик сам
     * переключит нас на готовую задачу и вернёт обратно. */
    for (;;) hlt();
}
