#ifndef MAXOS_MAXOS_H
#define MAXOS_MAXOS_H

#define MAXOS_NAME     "MaXOS"
#define MAXOS_VERSION  "0.1"
#define MAXOS_CODENAME "Aqua"
#define MAXOS_BUILD    "2026.10.09"

#endif
