#ifndef MAXOS_TYPES_H
#define MAXOS_TYPES_H

/* ------------------------------------------------------------------ */
/*  Базовые типы. stdint.h из freestanding-комплекта тянет за собой     */
/*  лишнее, поэтому определяем сами - ядро самодостаточно.              */
/* ------------------------------------------------------------------ */
typedef unsigned char      u8;
typedef unsigned short     u16;
typedef unsigned int       u32;
typedef unsigned long long u64;
typedef signed char        i8;
typedef short              i16;
typedef int                i32;
typedef long long          i64;
typedef u64                usize;
typedef i64                isize;

typedef int bool;
#define true  1
#define false 0

#define NULL ((void *)0)

typedef u32 color_t;      /* 0x00RRGGBB (внутренний формат ядра) */

typedef struct { i32 x, y; } point_t;
typedef struct { i32 x, y, w, h; } rect_t;

/* ------------------------------------------------------------------ */
/*  Мелкие макросы                                                     */
/* ------------------------------------------------------------------ */
#define ARRAY_LEN(a)   (sizeof(a) / sizeof((a)[0]))
#define MIN(a, b)      ((a) < (b) ? (a) : (b))
#define MAX(a, b)      ((a) > (b) ? (a) : (b))
#define CLAMP(v, a, b) ((v) < (a) ? (a) : ((v) > (b) ? (b) : (v)))
#define ALIGN_UP(x, a)    ((((u64)(x)) + ((a) - 1)) & ~((u64)((a) - 1)))
#define ALIGN_DOWN(x, a)  (((u64)(x)) & ~((u64)((a) - 1)))

#define KB(x) ((u64)(x) * 1024u)
#define MB(x) ((u64)(x) * 1024u * 1024u)

/* ------------------------------------------------------------------ */
/*  Портики (единственный inline-asm, который есть в C-коде;           */
/*  синтаксис AT&T - так его понимает gcc без -masm=intel)             */
/* ------------------------------------------------------------------ */
static inline void outb(u16 port, u8 val)
{
    __asm__ volatile("outb %0, %1" :: "a"(val), "Nd"(port));
}
static inline void outw(u16 port, u16 val)
{
    __asm__ volatile("outw %0, %1" :: "a"(val), "Nd"(port));
}
static inline u8 inb(u16 port)
{
    u8 r;
    __asm__ volatile("inb %1, %0" : "=a"(r) : "Nd"(port));
    return r;
}
static inline u16 inw(u16 port)
{
    u16 r;
    __asm__ volatile("inw %1, %0" : "=a"(r) : "Nd"(port));
    return r;
}
static inline void io_wait(void) { outb(0x80, 0); }

static inline void cli(void) { __asm__ volatile("cli"); }
static inline void sti(void) { __asm__ volatile("sti"); }
static inline void hlt(void) { __asm__ volatile("hlt"); }
static inline void cpu_pause(void) { __asm__ volatile("pause"); }

static inline u64 rdtsc(void)
{
    u32 lo, hi;
    __asm__ volatile("rdtsc" : "=a"(lo), "=d"(hi));
    return ((u64)hi << 32) | lo;
}

#define barrier() __asm__ volatile("" ::: "memory")

#endif
