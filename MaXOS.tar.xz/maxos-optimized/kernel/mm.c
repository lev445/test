#include "mm.h"
#include "klib.h"
#include "log.h"

extern char kernel_end[];      /* из linker.ld */
extern void cpu_set_cr3(u64);
extern void cpu_or_cr4(u64);

/* ---------------------------------------------------------------------
 *  Странички ядра.
 *
 *  stage2 оставил identity-map на 512 GiB таблицами в нижней памяти
 *  (0x10000, 0x11000, 0x200000). Работать на чужих таблицах -- дурной
 *  тон, поэтому строим свои: 4 GiB identity крупными (2 MiB) страницами,
 *  все supervisor-only. Пользовательское окно 0x400000..0x800000, которое
 *  stage2 пометил как user, мы намеренно НЕ наследуем: ring-3 появится
 *  вместе со своими адресными пространствами.
 * ------------------------------------------------------------------- */
#define PTE_P     0x1ull
#define PTE_W     0x2ull
#define PTE_U     0x4ull
#define PTE_PSE   0x80ull     /* 2 MiB страница в PD */
#define PTE_G     0x100ull    /* global (нужен CR4.PGE) */

#define PD_COUNT  4                       /* 4 * 512 * 2MiB = 4 GiB */

static u64 kpml4[512]     __attribute__((aligned(4096)));
static u64 kpdpt[512]     __attribute__((aligned(4096)));
static u64 kpd[PD_COUNT][512] __attribute__((aligned(4096)));

static void build_kernel_tables(void)
{
    memset(kpml4, 0, sizeof(kpml4));
    memset(kpdpt, 0, sizeof(kpdpt));
    memset(kpd,   0, sizeof(kpd));

    kpml4[0] = ((u64)kpdpt) | PTE_P | PTE_W;
    for (int i = 0; i < PD_COUNT; i++)
        kpdpt[i] = ((u64)kpd[i]) | PTE_P | PTE_W;

    u64 pa = 0;
    for (int i = 0; i < PD_COUNT; i++)
        for (int j = 0; j < 512; j++, pa += MB(2))
            kpd[i][j] = pa | PTE_P | PTE_W | PTE_PSE | PTE_G;

    cpu_or_cr4(1ull << 7);          /* CR4.PGE -- чтобы бит G имел смысл */
    cpu_set_cr3((u64)kpml4);
}

/* ---------------------------------------------------------------------
 *  Куча. Простейший first-fit по списку блоков: для ядра, где память
 *  выделяют редко и крупно (буферы окон, стеки задач), этого хватает
 *  за глаза, а читается за пять минут.
 *
 *  [blk_t header][ payload ... ][blk_t header][ payload ... ]...
 * ------------------------------------------------------------------- */
typedef struct blk {
    usize size;   /* размер payload */
    u32   used;
    u32   magic;
} blk_t;

#define BLK_MAGIC 0x4D584844u      /* 'MXHD' */
#define HEAP_CAP  MB(64)

static u8    *heap_base;
static usize  heap_cap;
static usize  heap_top;            /* конец размеченной области == heap_cap */

static blk_t *first(void) { return (blk_t *)heap_base; }
static blk_t *next_blk(blk_t *b)
{
    return (blk_t *)((u8 *)b + sizeof(blk_t) + b->size);
}
static int valid(blk_t *b)
{
    return (u8 *)b < heap_base + heap_top && b->magic == BLK_MAGIC;
}

static void coalesce(void)
{
    blk_t *b = first();
    while (valid(b)) {
        blk_t *n = next_blk(b);
        while (valid(n) && !b->used && !n->used) {
            b->size += sizeof(blk_t) + n->size;
            n->magic = 0;
            n = next_blk(b);
        }
        b = n;
    }
}

void *kmalloc(usize size)
{
    if (!heap_base || size == 0) return NULL;
    size = ALIGN_UP(size, 16);

    blk_t *b = first();
    while (valid(b)) {
        if (!b->used && b->size >= size) {
            if (b->size >= size + sizeof(blk_t) + 32) {
                blk_t *n = (blk_t *)((u8 *)b + sizeof(blk_t) + size);
                n->size  = b->size - size - sizeof(blk_t);
                n->used  = 0;
                n->magic = BLK_MAGIC;
                b->size  = size;
            }
            b->used = 1;
            return (u8 *)b + sizeof(blk_t);
        }
        b = next_blk(b);
    }
    return NULL;
}

void *kzalloc(usize size)
{
    void *p = kmalloc(size);
    if (p) memset(p, 0, size);
    return p;
}

void kfree(void *p)
{
    if (!p) return;
    blk_t *b = (blk_t *)((u8 *)p - sizeof(blk_t));
    if (b->magic != BLK_MAGIC) return;   /* двойное освобождение/мусор */
    b->used = 0;
    coalesce();
}

void mm_init(void)
{
    build_kernel_tables();

    u64 start = ALIGN_UP((u64)(usize)kernel_end, MB(2));
    u64 phys_end = MB(PHYS_MEM_MB);
    u64 limit = start + HEAP_CAP;
    if (limit > phys_end - MB(8)) limit = phys_end - MB(8);
    if (limit <= start) limit = start + MB(8);

    heap_base = (u8 *)(usize)start;
    heap_cap  = (usize)(limit - start);
    /* Блоки всегда ровно покрывают всю кучу: при сплите суммарный размер
     * не меняется, поэтому граница обхода -- это heap_cap. (Раньше тут
     * стоял sizeof(blk_t), и второй kmalloc() сразу упирался в «конец».) */
    heap_top  = heap_cap;

    blk_t *b = first();
    b->size  = heap_cap - sizeof(blk_t);
    b->used  = 0;
    b->magic = BLK_MAGIC;

    klog("mm: kernel image ends at %p", (void *)(usize)kernel_end);
    klog("mm: identity-mapped 4 GiB (2 MiB pages), CR3=%p", (void *)(usize)kpml4);
    klog("mm: heap %p..%p (%u MiB)", (void *)(usize)heap_base,
         (void *)(usize)(heap_base + heap_cap), (u32)(heap_cap >> 20));
}

void mm_info(usize *total, usize *used, usize *kernel_img)
{
    usize u = 0;
    blk_t *b = first();
    while (valid(b)) {
        if (b->used) u += b->size;
        b = next_blk(b);
    }
    if (total) *total = heap_cap;
    if (used)  *used  = u;
    if (kernel_img) *kernel_img = (usize)kernel_end - 0x100000;
}
