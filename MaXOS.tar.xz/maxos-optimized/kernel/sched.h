#ifndef MAXOS_SCHED_H
#define MAXOS_SCHED_H

#include "types.h"

/* ---------------------------------------------------------------------
 *  Многозадачность.
 *
 *  Прерывистая (preemptive), round-robin, квант = QUANTUM тиков PIT.
 *  Каждая задача -- это поток ядра со своим стеком 16 KiB. Переключение
 *  делает cpu_switch() (asm): сохраняем callee-saved + rflags, больше
 *  ничего не нужно, потому что переключаемся мы всегда из точки, где
 *  всё остальное уже лежит на стеке (либо внутри ISR, либо внутри
 *  sched_sleep/sched_yield).
 *
 *  Адресное пространство пока одно на всех (identity-map ядра) -- это
 *  честные потоки, а не процессы. До ring-3 и отдельных CR3 рукой
 *  подать: TSS и user-селекторы в GDT уже есть.
 * ------------------------------------------------------------------- */

#define MAX_TASKS       24
#define TASK_STACK_SIZE (16 * 1024)
#define SCHED_HZ        100        /* = PIT_HZ */
#define SCHED_QUANTUM   2          /* тиков на задачу (20 мс) */

typedef enum {
    TASK_FREE = 0,
    TASK_READY,
    TASK_RUNNING,
    TASK_SLEEP,
    TASK_DEAD
} task_state_t;

typedef struct task {
    u64  ctx;                       /* сохранённый rsp */
    u8  *stack;
    u32  stack_size;
    char name[24];
    volatile int state;
    u64  wake_tick;
    u64  cpu_ticks;                 /* сколько тиков задача была текущей */
    u64  cpu_last;
    u32  cpu_pct;                   /* % за последнюю секунду */
    u64  switches;
    int  id;
} task_t;

extern task_t tasks[MAX_TASKS];

void     sched_init(void);
int      task_create(const char *name, void (*fn)(void *), void *arg);
void     sched_tick(void);          /* из IRQ0 */
void     sched_yield(void);
void     sched_sleep_ms(u32 ms);
void     task_exit(void) __attribute__((noreturn));

void     sched_set_wake_id(int id);   /* задача-композитор: будить по событиям */
void     sched_wake_gui(void);        /* из IRQ клавиатуры/мыши */
u64      sched_ticks(void);
u64      sched_uptime_ms(void);
task_t  *sched_current(void);
void     sched_account(void);       /* раз в секунду: пересчёт cpu_pct */
u32      sched_load(void);          /* сумма % всех задач, кроме idle */
int      sched_count(void);         /* живых задач */
const char *task_state_name(int st);

/* Критические секции: pushfq/popfq -- единственные инструкции, которые
 * одинаково пишутся и в AT&T, и в Intel синтаксисе. */
static inline u64 irq_save(void)
{
    u64 f;
    __asm__ volatile("pushfq; popq %0" : "=r"(f) :: "memory");
    return f;
}
static inline void irq_restore(u64 f)
{
    __asm__ volatile("pushq %0; popfq" :: "r"(f) : "memory", "cc");
}

#endif
