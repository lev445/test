#include "cpu.h"
#include "klib.h"
#include "log.h"

/* из kernel/arch/head.S */
extern u64 gdt64[];
extern u8  ist1_stack[];
extern void cpu_load_gdt(void *desc);
extern void cpu_load_tr(u16 sel);

struct gdt_desc {
    u16 limit;
    u64 base;
} __attribute__((packed));
extern struct gdt_desc gdt64_desc;

#define GDT_TSS_QWORD 5      /* gdt64[5..6] -- 16-байтный TSS-дескриптор */

void cpu_set_kernel_stack(u64 rsp0)
{
    tss64.rsp0 = rsp0;
}

void cpu_init(void)
{
    memset(&tss64, 0, sizeof(tss64));
    tss64.iomap = (u16)sizeof(tss_t);        /* карты портов нет */
    tss64.ist1  = (u64)(usize)ist1_stack + 4096;

    /* Собираем 64-битный системный дескриптор TSS:
     *   bits  0..15  limit 0..15
     *   bits 16..39  base  0..23
     *   bits 40..43  type = 1001b (available 64-bit TSS)
     *   bit  44      S = 0 (системный)
     *   bits 45..46  DPL = 0
     *   bit  47      P = 1
     *   bits 48..51  limit 16..19
     *   bits 56..63  base 24..31
     *   второй qword: base 32..63                                        */
    u64 base  = (u64)(usize)&tss64;
    u32 limit = (u32)sizeof(tss_t) - 1;

    gdt64[GDT_TSS_QWORD] =
          (u64)(limit & 0xFFFF)
        | ((base & 0xFFFFFFull) << 16)
        | (0x9ull << 40)
        | (1ull << 47)
        | (((u64)(limit >> 16) & 0xF) << 48)
        | (((base >> 24) & 0xFFull) << 56);
    gdt64[GDT_TSS_QWORD + 1] = base >> 32;

    cpu_load_gdt(&gdt64_desc);
    cpu_load_tr(SEL_TSS);

    klog("cpu: GDT reloaded (CS=%x DS=%x), TSS %p, IST1 for #DF",
         SEL_KCODE, SEL_KDATA, (void *)base);
}
