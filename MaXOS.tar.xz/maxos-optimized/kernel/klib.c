#include "klib.h"

/* =====================================================================
 *  Память
 * =================================================================== */
void *memcpy(void *dst, const void *src, usize n)
{
    u8 *d = (u8 *)dst;
    const u8 *s = (const u8 *)src;
    while (n >= 8) {
        *(u64 *)d = *(const u64 *)s;   /* x86 умеет невыровненный доступ */
        d += 8; s += 8; n -= 8;
    }
    while (n--) *d++ = *s++;
    return dst;
}

void *memmove(void *dst, const void *src, usize n)
{
    u8 *d = (u8 *)dst;
    const u8 *s = (const u8 *)src;
    if (d == s || n == 0) return dst;
    if (d < s) {
        while (n--) *d++ = *s++;
    } else {
        d += n; s += n;
        while (n--) *--d = *--s;
    }
    return dst;
}

void *memset(void *dst, int c, usize n)
{
    u8 *d = (u8 *)dst;
    u64 v = (u8)c;
    v |= v << 8; v |= v << 16; v |= v << 32;
    while (n >= 8) { *(u64 *)d = v; d += 8; n -= 8; }
    while (n--) *d++ = (u8)c;
    return dst;
}

int memcmp(const void *a, const void *b, usize n)
{
    const u8 *x = a, *y = b;
    while (n--) {
        if (*x != *y) return (int)*x - (int)*y;
        x++; y++;
    }
    return 0;
}

/* =====================================================================
 *  Строки
 * =================================================================== */
usize strlen(const char *s)
{
    const char *p = s;
    while (*p) p++;
    return (usize)(p - s);
}

int strcmp(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return (int)(u8)*a - (int)(u8)*b;
}

int strncmp(const char *a, const char *b, usize n)
{
    while (n && *a && *a == *b) { a++; b++; n--; }
    if (!n) return 0;
    return (int)(u8)*a - (int)(u8)*b;
}

char *strcpy(char *dst, const char *src)
{
    char *d = dst;
    while ((*d++ = *src++)) ;
    return dst;
}

char *strncpy(char *dst, const char *src, usize n)
{
    usize i = 0;
    for (; i < n && src[i]; i++) dst[i] = src[i];
    for (; i < n; i++) dst[i] = 0;
    return dst;
}

char *strcat(char *dst, const char *src)
{
    char *d = dst + strlen(dst);
    while ((*d++ = *src++)) ;
    return dst;
}

const char *strchr(const char *s, int c)
{
    for (; *s; s++) if (*s == (char)c) return s;
    return (c == 0) ? s : NULL;
}

/* =====================================================================
 *  Числа
 * =================================================================== */
char *utoa(u64 v, char *buf, int base)
{
    static const char dig[] = "0123456789abcdef";
    char tmp[24];
    int i = 0;
    if (v == 0) tmp[i++] = '0';
    while (v) { tmp[i++] = dig[v % base]; v /= base; }
    int n = 0;
    while (i) buf[n++] = tmp[--i];
    buf[n] = 0;
    return buf;
}

char *itoa(i64 v, char *buf, int base)
{
    if (v < 0 && base == 10) { *buf++ = '-'; v = -v; }
    return utoa((u64)v, buf, base);
}

/* =====================================================================
 *  Форматтер. size == 0 означает "буфер без ограничения" (vsprintf).
 * =================================================================== */
static int pfmt(char *buf, usize size, const char *fmt, va_list ap)
{
    usize pos = 0;
#define PUTC(ch) do { if (size == 0 || pos + 1 < size) buf[pos] = (char)(ch); pos++; } while (0)

    for (; *fmt; fmt++) {
        if (*fmt != '%') { PUTC(*fmt); continue; }
        fmt++;

        int left = 0, zeropad = 0;
        while (*fmt == '-' || *fmt == '0') {
            if (*fmt == '-') left = 1; else zeropad = 1;
            fmt++;
        }
        int width = 0;
        if (*fmt == '*') { width = va_arg(ap, int); fmt++; }
        else while (*fmt >= '0' && *fmt <= '9') { width = width * 10 + (*fmt - '0'); fmt++; }
        if (width < 0) { left = 1; width = -width; }

        /* модификаторы длины. Это важно: на x86-64 старшая половина
         * слота variadic-аргумента для unsigned int не определена,
         * поэтому читать всё как u64 -- классическая грабля. */
        int is64 = 0;
        for (;;) {
            if (*fmt == 'l') { is64 = 1; fmt++; }
            else if (*fmt == 'z' || *fmt == 'j' || *fmt == 't') { is64 = 1; fmt++; }
            else if (*fmt == 'h') { fmt++; }        /* promotion -> int */
            else break;
        }

        char tmp[32];
        const char *out = tmp;
        usize olen = 0;
        char pad = ' ';
        int numeric = 0;

        switch (*fmt) {
        case 'd': case 'i': {
            i64 v = is64 ? va_arg(ap, i64) : (i64)va_arg(ap, int);
            if (v < 0) { tmp[0] = '-'; utoa((u64)(-v), tmp + 1, 10); }
            else utoa((u64)v, tmp, 10);
            olen = strlen(tmp); numeric = 1;
            break;
        }
        case 'u':
            utoa(is64 ? va_arg(ap, u64) : (u64)va_arg(ap, unsigned), tmp, 10);
            olen = strlen(tmp); numeric = 1; break;
        case 'x':
            utoa(is64 ? va_arg(ap, u64) : (u64)va_arg(ap, unsigned), tmp, 16);
            olen = strlen(tmp); numeric = 1; break;
        case 'X':
            utoa(is64 ? va_arg(ap, u64) : (u64)va_arg(ap, unsigned), tmp, 16);
            for (char *p = tmp; *p; p++) if (*p >= 'a') *p -= 32;
            olen = strlen(tmp); numeric = 1; break;
        case 'p': {
            u64 v = (u64)(usize)va_arg(ap, void *);
            tmp[0] = '0'; tmp[1] = 'x';
            utoa(v, tmp + 2, 16);
            olen = strlen(tmp); numeric = 1;
            break;
        }
        case 'c':
            tmp[0] = (char)va_arg(ap, int); tmp[1] = 0; olen = 1; break;
        case 's':
            out = va_arg(ap, const char *);
            if (!out) out = "(null)";
            olen = strlen(out);
            break;
        case '%':
            PUTC('%'); continue;
        case 0:
            fmt--; continue;
        default:
            PUTC('%'); PUTC(*fmt); continue;
        }

        int fill = (width > (int)olen) ? width - (int)olen : 0;
        if (zeropad && !left && numeric) pad = '0';
        if (!left) while (fill-- > 0) PUTC(pad);
        for (usize i = 0; i < olen; i++) PUTC(out[i]);
        if (left) while (fill-- > 0) PUTC(' ');
    }
    if (size == 0) buf[pos] = 0;
    else buf[pos < size ? pos : size - 1] = 0;
#undef PUTC
    return (int)pos;
}

int kvsprintf(char *buf, const char *fmt, va_list ap)
{
    return pfmt(buf, 0, fmt, ap);
}

int kvsnprintf(char *buf, usize size, const char *fmt, va_list ap)
{
    return pfmt(buf, size, fmt, ap);
}

int ksnprintf(char *buf, usize size, const char *fmt, ...)
{
    va_list ap;
    int r;
    va_start(ap, fmt);
    r = pfmt(buf, size, fmt, ap);
    va_end(ap);
    return r;
}
