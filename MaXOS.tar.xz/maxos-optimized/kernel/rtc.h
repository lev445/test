#ifndef MAXOS_RTC_H
#define MAXOS_RTC_H

#include "types.h"

typedef struct {
    u16 year;
    u8  month, day, weekday;
    u8  hour, min, sec;
    int valid;
} datetime_t;

void rtc_read(datetime_t *dt);
void rtc_fake_from_uptime(datetime_t *dt, u64 ms); /* если CMOS молчит */

#endif
