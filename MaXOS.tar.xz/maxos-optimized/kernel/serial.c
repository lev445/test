#include "serial.h"

#define COM1 0x3F8

static int serial_ok;

void serial_init(void)
{
    outb(COM1 + 1, 0x00);   /* выключить прерывания */
    outb(COM1 + 3, 0x80);   /* DLAB = 1 */
    outb(COM1 + 0, 0x01);   /* делитель 1 -> 115200 бод */
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x03);   /* 8N1 */
    outb(COM1 + 2, 0xC7);   /* FIFO */
    outb(COM1 + 4, 0x0B);   /* RTS/DSR */
    serial_ok = 1;
}

void serial_putc(char c)
{
    if (!serial_ok) return;
    int timeout = 100000;
    while (!(inb(COM1 + 5) & 0x20) && --timeout > 0) cpu_pause();
    outb(COM1, (u8)c);
}

void serial_write(const char *s)
{
    for (; *s; s++) {
        if (*s == '\n') serial_putc('\r');
        serial_putc(*s);
    }
}
