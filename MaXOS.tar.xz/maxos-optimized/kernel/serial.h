#ifndef MAXOS_SERIAL_H
#define MAXOS_SERIAL_H

#include "types.h"

/* COM1 0x3F8 -- в QEMU это `-serial stdio`, на железе обычный UART.
 * Очень полезен, когда экран ещё не поднялся или уже ушёл в триплекссер. */
void serial_init(void);
void serial_putc(char c);
void serial_write(const char *s);

#endif
