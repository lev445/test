/* =====================================================================
 *  QuarkOS userland: TRAP_MEM.BIN - tries to read the kernel's VGA
 *  buffer (0xB8000) from ring 3; page tables mark it supervisor-only,
 *  so the CPU must raise #PF and the kernel kills us
 * ===================================================================== */
#include "usyscall.h"

__attribute__((section(".text.boot"))) void _start(void) {
    putstr("naughty task: reading kernel VGA memory @ 0xB8000...\n");
    putstr("(expect #PF -> kernel kills this task)\n");
    volatile unsigned short *vga = (volatile unsigned short *)0xB8000;
    unsigned short v = vga[0];
    putstr("!!! BUG: ring 3 read kernel memory: "); put_hex(v); putstr(" !!!\n");
    syscall1(SYS_EXIT, 1);
    for (;;) asm volatile("hlt");
}
