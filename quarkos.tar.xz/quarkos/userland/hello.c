/* =====================================================================
 *  QuarkOS userland: HELLO.BIN - a good ring-3 citizen
 *  syscalls, sleep (timer IRQs via TSS.RSP0), clean exit with status 42
 * ===================================================================== */
#include "usyscall.h"

__attribute__((section(".text.boot"))) void _start(void) {
    putstr("+--------------------------------------------+\n");
    putstr("|  hello from RING 3!  (user mode, CPL = 3)  |\n");
    putstr("+--------------------------------------------+\n");

    uint64_t cs, ss;
    asm volatile("mov %%cs, %0" : "=r"(cs));
    asm volatile("mov %%ss, %0" : "=r"(ss));
    putstr("CS = "); put_hex(cs); putstr(" -> CPL = "); putu(cs & 3); putstr("\n");
    putstr("SS = "); put_hex(ss); putstr(" -> DPL = "); putu(ss & 3); putstr("\n");

    putstr("sys_uptime()  = "); putu((uint64_t)syscall1(SYS_UPTIME, 0));
    putstr(" ms\n");

    putstr("sys_sleep(1500): while I wait, timer IRQs enter the\n");
    putstr("kernel through TSS.RSP0 and come back to me...\n");
    syscall1(SYS_SLEEP, 1500);
    putstr("...awake! sys_uptime() = ");
    putu((uint64_t)syscall1(SYS_UPTIME, 0)); putstr(" ms\n");

    putstr("benchmark: 100000 syscalls through SYSCALL/SYSRET...\n");
    uint64_t t0 = (uint64_t)syscall1(SYS_UPTIME, 0);
    for (int i = 0; i < 100000; i++)
        syscall1(SYS_UPTIME, 0);
    uint64_t t1 = (uint64_t)syscall1(SYS_UPTIME, 0);
    putstr("done in ~"); putu(t1 - t0); putstr(" ms\n");

    putstr("that's all from user mode; sys_exit(42)\n");
    syscall1(SYS_EXIT, 42);
    for (;;) asm volatile("hlt");
}
