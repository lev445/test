; =====================================================================
;  HELLOWORLD.BIN - the first third-party QuarkOS userland application
;  (reconstructed from the spectator's original 28-byte binary,
;   plus the sys_exit the original was missing - it fell off the end
;   of the image into rip=0x0 and got #PF-killed, gloriously)
;
;  syscall ABI: rax = number, rdi = arg0, result in rax
; =====================================================================
BITS 64
org 0x400000

SYS_EXIT  equ 0
SYS_WRITE equ 1

start:
    lea rdi, [rel msg]        ; arg0 = string
    mov eax, SYS_WRITE
    syscall

    mov eax, SYS_EXIT         ; <- the line the original forgot
    mov edi, 7                ; lucky number of the first third-party dev
    syscall

    ; never reached, but never fall off the edge either
.hang:
    jmp .hang

msg: db "Hello, world!", 10
