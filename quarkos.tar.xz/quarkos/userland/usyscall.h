/* tiny syscall library for QuarkOS userland (ring 3) */
#ifndef USYSCALL_H
#define USYSCALL_H

typedef unsigned long uint64_t;

#define SYS_EXIT    0
#define SYS_WRITE   1
#define SYS_PUTU    2
#define SYS_UPTIME  3
#define SYS_SLEEP   4

static inline long syscall1(long num, long a0) {
    long ret;
    /* fast path: SYSCALL/SYSRET (rcx, r11 clobbered by CPU) */
    asm volatile("syscall"
                 : "=a"(ret)
                 : "a"(num), "D"(a0)
                 : "rcx", "r11", "memory");
    return ret;
}

static inline void putstr(const char *s) { syscall1(SYS_WRITE, (long)s); }
static inline void putu(uint64_t v)      { syscall1(SYS_PUTU, (long)v); }

static inline void put_hex(uint64_t v) {
    const char *d = "0123456789abcdef";
    char buf[19];
    buf[0] = '0'; buf[1] = 'x';
    for (int i = 0; i < 16; i++)
        buf[2 + i] = d[(v >> (60 - i * 4)) & 0xF];
    buf[18] = 0;
    putstr(buf);
}

#endif
