/* =====================================================================
 *  QuarkOS userland: TRAP_IO.BIN - executes a privileged instruction
 *  (CLI) in ring 3; the CPU must raise #GP and the kernel kills us
 * ===================================================================== */
#include "usyscall.h"

__attribute__((section(".text.boot"))) void _start(void) {
    putstr("naughty task: executing privileged CLI in ring 3...\n");
    putstr("(expect #GP -> kernel kills this task)\n");
    asm volatile("cli");
    putstr("!!! BUG: ring 3 was allowed to CLI !!!\n");
    syscall1(SYS_EXIT, 1);
    for (;;) asm volatile("hlt");
}
