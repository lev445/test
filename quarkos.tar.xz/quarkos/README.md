# QuarkOS

Hobby-операционная система для x86_64, написанная с нуля: свой загрузчик
(16 → 32 → 64 bit), свой ATA PIO драйвер, свой драйвер FAT32 и свой шелл.
Без GRUB, без libc, без BIOS-сервисов после загрузки ядра.

Версия: **0.1.0** · Архитектура: **x86_64 (long mode)** · Лицензия: делай что хочешь.

```
   ____                    _  __  ____  ____
  / __ \__  ______ _____  | |/ / / __ \/ __/
 / / / / / / / __ `/ ___/ |   / / / / /\__ \
/ /_/ / /_/ / /_/ / /    /   | / /_/ /___/ /
\___\_\__,_/\__,_/_/    /_/|_| \____//____/
```

---

## 1. Цепочка загрузки

```
BIOS (real mode, 16 bit)
   │  загружает LBA 0 в 0x7C00
   ▼
boot/boot.asm  (stage1, MBR, ≤512 байт)
   │  INT 13h AH=42h: читает 16 секторов с LBA 1 → 0x0800
   ▼
boot/stage2.asm (stage2)
   │  1. включает A20 (fast gate 0x92 + INT 15h AX=2401)
   │  2. INT 13h AH=42h: читает ядро (512 сект. с LBA 2048) → 0x40000
   │     (чанками по 64 сектора: выше 1 МиБ DMA BIOS ненадёжен)
   │  3. строит таблицы страниц: identity-map первых 1 ГиБ (2-МиБ страницы)
   │  4. CR0.PE → far jmp в 32-bit protected mode
   │  5. копирует ядро 0x40000 → 0x100000
   │  6. CR4.PAE, CR3=PML4, EFER.LME, CR0.PG → far jmp в 64-bit long mode
   ▼
kernel/entry.asm → kernel/kmain()   (C, -ffreestanding, -mno-red-zone)
```

### Разметка диска (512-байтные сектора)

| LBA            | Содержимое                          |
|----------------|-------------------------------------|
| 0              | stage1 (MBR) + таблица разделов     |
| 1 – 16         | stage2                              |
| 2048 – 2559    | плоский бинарник ядра (≤256 КиБ)    |
| 4096 – …       | раздел FAT32 (тип 0x0C)             |

### Карта памяти ядра

| Адрес          | Что                                  |
|----------------|--------------------------------------|
| 0x00000–0x00500| BDA                                  |
| 0x07C00        | stage1 (перезаписывается)            |
| 0x08000        | stage2, стек stage1/stage2           |
| 0x10000–0x13000| PML4 / PDPT / PD (stage2)            |
| 0x20000        | GDT stage2                           |
| 0xB8000        | VGA text buffer (консоль)            |
| 0x100000…      | ядро (.text/.rodata/.data/.bss)      |
| …0x117000      | верх стека ядра (64 КиБ)             |

---

## 2. Состав ядра

| Модуль              | Что делает |
|---------------------|------------|
| `console.c`         | VGA text 80×25, курсор, скролл, `kprintf` (`%s %d %u %x %X %c %p`, ширина, `0`-паддинг, `-` влево), зеркало в COM1 |
| `serial.c`          | COM1 38400 8N1 для headless-отладки |
| `gdt.c`             | свой GDT ядра (code64/data64) с перезагрузкой CS через `retfq` |
| `idt.c` + `isr.asm` | 256 векторов, стабы исключений и IRQ0–15, общий `isr_handler`, паника с дампом регистров |
| `pic.c`             | ремап 8259A: IRQ0–7 → 32–39, IRQ8–15 → 40–47, маски |
| `timer.c`           | PIT на 1000 Гц (IRQ0), `timer_ms()`, `timer_sleep_ms()` |
| `keyboard.c`        | PS/2 IRQ1, scancode set 1, Shift/CapsLock, кольцевой буфер |
| `ata.c`             | **ATA PIO драйвер**: IDENTIFY (модель/серийник/прошивка/размер), LBA28+LBA48, чтение/запись/flush, 4 устройства (primary/secondary × master/slave) |
| `fat32.c`           | **драйвер FAT32 (read-only)**: BPB, цепочки кластеров, обход каталогов, LFN, пути `/DIR/FILE.TXT`, подсчёт свободного места сканом FAT |
| `shell.c`           | интерактивный шелл |
| `string.c`          | своя libc-минималка (memset/memcpy/strlen/…) |

### Команды шелла

| Команда      | Описание |
|--------------|----------|
| `help`       | справка |
| `clear`/`cls`| очистить экран |
| `echo <txt>` | напечатать текст |
| `lsblk`      | **все ATA-диски и их разделы** (модель, тип, размер, LBA начала) |
| `ls [путь]`  | листинг каталога FAT32 (по умолчанию `/`) |
| `cat <файл>` | вывести файл (в т.ч. из подкаталога) |
| `ver`        | версия, адреса ядра, состояние ATA/FS |
| `time`       | аптайм |
| `reboot`     | перезагрузка через KBC 0xFE |
| `shutdown`   | ACPI power-off (порты QEMU/Bochs/VBox) |

---

## 3. Сборка и запуск

Нужны: `nasm`, `gcc`, `binutils`, `make`, `python3`, `dosfstools`, `mtools`,
для запуска: `qemu-system-x86`.

```bash
# Debian/Ubuntu
sudo apt install nasm gcc binutils make python3 dosfstools mtools qemu-system-x86
# Arch / CachyOS / Manjaro (gcc там собран с --enable-default-ssp,
# Makefile уже передаёт -fno-stack-protector, так что всё ок)
sudo pacman -S nasm gcc binutils make python dosfstools mtools qemu-system-x86
```

```bash
make            # соберёт ядро и соберёт disk.img (64 МиБ)
make run        # QEMU с serial в терминал (интерактивно!)
make test       # headless автопрогон: sendkey-команды + скриншоты VGA
```

`make test` запускает `tools/qemu_demo.py`: он печатает в шелл `lsblk`,
`ls /`, `cat README.TXT`, `cat /DOCS/NOTES.TXT`, `help`, `time`, `ver`,
делает screendump каждого шага (`build/shots/*.png`) и завершает ОС
командой `shutdown`.

Готовые скриншоты прогона лежат в `doc/` (см. ниже), лог — `doc/serial.log`.

## 4. Доказательства работы

* `doc/boot.png` — баннер и инициализация подсистем
* `doc/lsblk.png` — вывод `lsblk`: диск + раздел FAT32
* `doc/ls.png` — листинг корня ФС
* `doc/cat.png`, `doc/cat_subdir.png` — чтение файлов из корня и из `/DOCS`
* `doc/help.png` — справка шелла
* `doc/serial.log` — полный текстовый лог автопрогона

## 5. Сезон 2: ring 3 (user mode)

### Как это устроено (конспект для понимающих)

1. **GDT** (`kernel/gdt.c`): к kernel-сегментам добавлены user-сегменты с
   DPL=3 (`0x18` code, `0x20` data; селекторы с RPL3: `0x1B`/`0x23`) и
   16-байтный дескриптор **TSS** (`0x28`).
2. **TSS** (`kernel/tss.c`): единственное поле, которое нам реально нужно —
   `RSP0`: куда CPU переключит стек при входе в ядро из ring 3.
   I/O bitmap не задан (offset >= limit) → любой `in/out` из ring 3 = #GP.
3. **Вход в ring 3** (`kernel/proc.c`): собираем на стеке кадр для `iretq`
   (SS=RPL3, user RSP, RFLAGS|IF, CS=RPL3, RIP=entry) и делаем `iretq`.
   Перед этим запоминаем `rec_rsp/rec_rip` — точку возврата сразу после
   iretq: туда прыгают `sys_exit` и убийца fault'ов, восстанавливая
   callee-saved регистры шелла (иначе user их бы затёр).
4. **Сисколлы** (`int 0x80`): гейт в IDT с **DPL=3** (attr `0xEE`), стаб в
   `isr.asm`, диспетчер `kernel/syscall.c`: `exit/write/putu/uptime/sleep`.
   Внутри `sleep` делаем `sti()`, иначе таймер не тикает под interrupt-гейтом.
5. **Изоляция памяти** (`boot/stage2.asm`): у PML4/PDPT проставлен U-бит,
   а из 512 PD-записей U-бит есть **только у двух**, покрывающих окно
   `0x400000–0x7FFFFF` (код+стек пользователя). Всё остальное (ядро, VGA,
   таблицы) — supervisor-only → чтение `0xB8000` из ring 3 = #PF.
6. **Убийство задачи**: в `isr_handler` исключение с `(cs & 3) == 3` →
   `proc_user_fault()` → печать vector/CR2 → `proc_recover()` → шелл жив.

### Демо (команда `run`)

| Программа | Что делает | Ожидаемый финал |
|-----------|------------|-----------------|
| `/BIN/HELLO.BIN` | печатает через сисколлы, CPL, sleep 1500 мс | `exited with status 42` |
| `/BIN/TRAP_IO.BIN` | `cli` в ring 3 | #GP → task KILLED |
| `/BIN/TRAP_MEM.BIN` | читает VGA `0xB8000` | #PF (cr2=0xb8000) → task KILLED |

Скриншоты: `doc/ring3_run.png` (сон задачи), `doc/ring3_exit.png` (успешный
прогон), `doc/ring3_io.png` (#GP), `doc/ring3_mem.png` (#PF).

### Эпизод 4: SYSCALL/SYSRET вместо int 0x80 (готово)

* `syscall_arch_init()` (`kernel/syscall.c`): MSR'ы
  `IA32_STAR` (kernel base 0x08 / user base 0x10), `IA32_LSTAR` (адрес входа),
  `IA32_FMASK` (гасим IF на входе), `EFER.SCE`, `IA32_KERNEL_GS_BASE`.
* **GDT пришлось переставить**: SYSRET жёстко выводит
  `CS = STAR[63:48]+16`, `SS = STAR[63:48]+8`, поэтому user **data** теперь
  0x18, user **code** 0x20 (селекторы 0x1B/0x23).
* Вход `syscall_entry_msr` (`kernel/isr.asm`): `swapgs` → user RSP в
  percpu-scratch → kernel stack → **синтетический кадр** того же формата,
  что и у прерываний (regs_t и обработчик общие для обоих путей!) →
  на выходе `rcx`=RIP, `r11`=RFLAGS, `mov rsp,[rsp]`, `swapgs`, `o64 sysret`.
* `int 0x80` оставлен как legacy-путь (гейт DPL3 жив, им просто никто
  из userland больше не пользуется).
* Бенчмарк в HELLO.BIN: **100 000 сисколлов ≈ 18–22 мс** (~5 млн/с).

Скриншоты те же: `doc/ring3_*.png` (hello теперь с бенчмарком).

### Эпизод: VESA/VBE и графическая консоль (готово)

* `boot/stage2.asm`: VBE-зондирование в реальном режиме (int 0x10:
  0x4F00/0x4F01/0x4F02), выбор 1024x768x32 с фолбэками 800x600/640x480,
  linear framebuffer (бит 14), boot-info блок на 0x30400.
* identity-map расширен до **4 ГиБ** (4 PD-таблицы): фреймбуфер QEMU живёт
  на 0xE0000000, выше старого потолка в 1 ГиБ.
* `kernel/fb.c`: пиксель-упаковка по VBE-маскам, глифы 8x16 из
  `kernel/font8x16.c` (извлечён из Lat15-VGA16.psf), скролл, палитра;
  консоль (`console.c`) сама переключается VGA-text <-> fb, фолбэк текст.
* Команда шелла `fbtest`: градиент + круг поверх (doc/fb_test.png).
* Мины этапа (все в doc/PORT_BUSYBOX.md-стиле записаны ниже): BIOS портит
  ES вокруг int 10h; ModeInfoBlock после цикла содержит инфу ПОСЛЕДНЕГО
  режима, а не выбранного (нужен повторный 0x4F01); XRes/YRes читаются
  словом, не двойным словом; CR4.OSFXSR обязателен для SSE2-userspace.

Скриншоты: `doc/fb_shell.png` (шелл в графике), `doc/fb_test.png` (паттерн).

### Эксперимент: USB-клавиатура через xHCI (kernel/xhci.c, kernel/pci.c)

Полный путь: PCI-поиск контроллера (class 0C/03/30) -> MMIO -> halt/takeover
или cold reset -> rings (command/event/ep0/transfer) -> Enable Slot ->
Address Device -> дескрипторы -> Configure Endpoint (interrupt IN) ->
polling event ring, HID boot-отчёты 8 байт -> ring буфер шелла.
Клавиши переводятся из HID usage напрямую в ASCII (shift учтён).

Статус: **РАБОТАЕТ НА РЕАЛЬНОМ ЖЕЛЕЗЕ.** ASUS PRIME B760M-K D4, клавиатура
Ajazz AK820 (провод Type-C) в порту USB 2.0: enumeration, HID-отчёты и ввод
в шелл подтверждены на плате. До этого end-to-end проверено на QEMU 9.2
(hotplug + sendkey) и QEMU 11.1 (ручной ввод). Зритель сезона облился
холодной водой по контракту.

Коллекция spec-багов, пойманных за порт (все в d3/dword-лейаутах TRB и ctx):
* TRT (Transfer Type) положен в d2 вместо d3 -> sanity-check длины setup'а
* endpoint context в input context живёт по смещению 32*(dci+1), не 32*dci
* EP Type interrupt IN = 7, а не 3 (3 = interrupt OUT -> STALL от клавиатуры)
* IOC = бит 5, IDT = бит 6 (бит 15 лежит внутри поля type!)
* cycle producer'а эп-кольца ресинхронизируется на каждом Address Device
* doorbell interrupt-IN периодически перезванивается поллингом: NAK-retry
  просыпается даже там, где wakeup-путь хоста/эмулятора молчит
Плюс платформенное: BSS выше окна загрузки не нулился (UEFI-остатки в кольцах),
BAR xHCI на реальных платах живёт выше 4 ГиБ (identity map расширен до 512 ГиБ),
контроллер может быть припаркован прошивкой (pci_pm_force_d0),
SeaBIOS оставляет свои слоты (retry с Disable Slot),
старые QEMU (7.2/9.2 без hotplug) грузят event ring только по HCRST
(hard_reinit при таймаутах команд).

Мины этапа: регистры xHCI (DCBAAP=0x30, CONFIG=0x38 — не перепутать);
чистые spin-циклы гостя не дают VMM обработать кольца (нужны vmexit);
HCRST роняет статически подключенные устройства у некоторых реализаций;
все ожидания портов/регистров обязаны быть ограниченными (floating bus).

### Первый сторонний софт

Зритель сезона 1 написал собственную user-программу (28 байт, `Hello, world!`
через syscall) и запустил её через `run`. Оригиналу не хватало `sys_exit`,
поэтому он эффектно упал с края образа в rip=0x0 и был убит #PF — защита
отработала штатно. Программа реконструирована как `userland/helloworld.asm`
(уже с выходом) и лежит на диске как `/BIN/HELLOWORLD.BIN`.

Для своих программ теперь есть два пути:
* `userland/имя.asm` + `org 0x400000` — NASM flat binary, улетает в `/BIN/`;
* `userland/имя.c` с `_start` в секции `.text.boot` — линкуется скриптом
  `userland/user.ld`, сисколлы из `userland/usyscall.h`.

ABI: `rax` = номер (`0 exit, 1 write, 2 putu, 3 uptime, 4 sleep`),
`rdi` = аргумент, результат в `rax`. В конце обязателен `sys_exit`,
иначе край образа и #PF (см. выше, это обряд посвящения).

### Грабли, на которые наступили (чтобы вы не наступили)

* **Порядок регистров в кадре обратный!** `push rax` выполняется первым,
  значит rax ляжет по **старшему** адресу группы; в `regs_t` поля должны
  идти `r15…r12, rbp, rdi, rsi, rdx, rcx, rbx, rax`. Исключения этого не
  показывают (vector/err/rip/cs кладёт CPU выше), а сисколлы молча читают
  мусор — симptom: «int 0x80 возвращается, но ничего не делает».
* gcc/ld подкладывают `.note.gnu.build-id` и относят `.text` от адреса
  линковки (+0x30), а `_start` уезжает в `.text.startup` после чужого кода.
  Лечится `-Wl,--build-id=none`, своей секцией `.text.boot` для `_start`
  и проверкой entry-адреса в Makefile.
* Дистро-GCC с `--enable-default-ssp` требует `-fno-stack-protector`
  даже во freestanding (см. сезон 1).
* **NASM не знает `sysretq`**: он молча собирает его как МЕТКУ (no-op!),
  и выполнение проваливается дальше. Правильно: `o64 sysret` (байты 48 0F 07).
  Симptom: первый сискол «залипает»/ребутит без всякой паники.
* **Баланс swapgs**: если сисколл завершается не через sysret-эпилог
  (а через `proc_recover` у `sys_exit`), GS base остаётся kernel-сторонним,
  и `swapgs` следующей задачи положит user RSP по адресу 0 → ребут.
  Лечится swapgs перед recover + нормализацией MSR'ов при входе в задачу.
* Зондирование ATA сразу после soft reset может увидеть status=0 и
  объявить диск отсутствующим: добавлено ожидание снятия BSY и повторные
  чтения статуса (иначе случайные «0 disks» на быстрых машинах).

## 6. Лестница портирования (дорога к bash и gcc)

Порт настоящего софта (bash, gcc, libc) decomposes на шесть ступеней;
порядок важен, перепрыгивание заканчивается triple fault'ом:

| # | Ступень | Результат |
|---|---------|-----------|
| M1 | ELF-загрузчик + argv/envp + своя мини-libc (`libc-quark.a`, crt0) | C-программы собираются хостовым gcc под QuarkOS |
| M2 | Процессы: spawn/wait + адресные пространства на процесс | шелл = честный лаунчер (shell v2), изоляция задач |
| M3 | fd + VFS с записью | open/read/write, настоящий stdio |
| M4 | POSIX-слой сисколлов + порт musl (или рост quarklibc) | первый настоящий шелл: busybox ash |
| M5 | termios + сигналы | статический bash (--without-job-control) |
| M6 | кросс-gcc с таргетом x86_64-quark-elf; позже нативный | self-hosting |

Инсайты: gcc сначала живёт на хосте как кросс-компилятор (или хостовый gcc +
crt0.o + libc-quark.a + линкер-скрипт — этого хватает на M1-M3); первым
настоящим шеллом портят busybox ash, а не bash; libc-кандидат номер один —
musl (статический, маленький, чистый порт-слой). Ограничение памяти: текущее
user-окно 4 МиБ на всех — статический bash не влезет без M2.

## 7. Что можно добавить дальше (roadmap)

- передача argv в user-программы и свой `malloc` в userland
- ELF-загрузчик вместо flat binary + `sys_execve`
- несколько процессов: планировщик, контекст-switch по timer IRQ
- свои адресные пространства на процесс (user base != identity)
- запись в FAT32 (`mk`, `rm`, `touch`)
- драйвер PS/2-мыши и простой GUI

*(уже сделано в сезоне 2: ring 3 + TSS + сисколлы, SYSCALL/SYSRET — раздел 5;
ELF-загрузчик + Linux x86_64 ABI compat-слой + статический musl-hello —
раздел 6, milestone 1; см. doc/PORT_BUSYBOX.md)*

## 8. Сезон 3: busybox bring-up (2026-10-05)

Static musl busybox 1.36.1 исполняется в ring 3: `run /BIN/busybox
echo/cat/ls/wc/uname/head/tail` и `sh -c` (ash, встроенные команды).
Ядро получило Linux-ABI compat слой «stage B» (`kernel/linux.c` +
`kernel/linuxfs.[ch]`): open/stat/lstat/fstat/newfstatat/getdents64/
lseek/fcntl/readv/writev/mmap/munmap/uname/getcwd/rlimit/uid-семейство,
честный -ENOSYS с trace на остальные. Staging загрузчика вынесен в
физику 16 МиБ (2 МиБ под образ при бюджете ядра 256 КиБ).

Воспроизведение: `tools/build_busybox.sh` (musl-gcc + allnoconfig-набор
аплетов), прогон: `python3 tools/qemu_busybox.py` (6/6 PASS).
Мины и границы слоя: `doc/BUSYBOX_BRINGUP.md`, скриншот
`doc/busybox_ls.png`. Fork/execve и запись в FAT32 — следующие ступени
(M2/M3), ash пока исполняет только встроенные команды.
