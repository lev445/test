; =====================================================================
;  QuarkOS - Stage 1 bootloader (MBR, 512 bytes, 16-bit real mode)
; =====================================================================
;  Loaded by BIOS at 0x0000:0x7C00.
;  Job: load Stage 2 (16 sectors starting at LBA 1) to 0x0000:0x8000
;       and jump to it, passing the boot drive in DL.
; =====================================================================

BITS 16
org 0x7C00

STAGE2_LBA     equ 1
STAGE2_SECTORS equ 16
STAGE2_OFF     equ 0x8000
STAGE2_SEG     equ 0x0000

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00          ; stack grows down from bootloader
    sti

    mov [boot_drive], dl    ; BIOS passes boot drive in DL

    mov si, msg_hello
    call print16

    ; --- extended read (INT 13h AH=42h) via DAP ---------------------
    mov ah, 0x42
    mov dl, [boot_drive]
    mov si, dap_stage2
    int 0x13
    jc disk_error

    ; hand control to stage 2, DL = boot drive
    mov dl, [boot_drive]
    jmp STAGE2_SEG:STAGE2_OFF

disk_error:
    mov si, msg_disk_err
    call print16
.halt:
    cli
    hlt
    jmp .halt

; --- tiny 16-bit string printer (teletype) ---------------------------
print16:
    pusha
    mov ah, 0x0E
    mov bx, 0x0007
.loop:
    lodsb
    test al, al
    jz .done
    int 0x10
    jmp .loop
.done:
    popa
    ret

msg_hello:    db "QuarkOS stage1: loading stage2...", 13, 10, 0
msg_disk_err: db "FATAL: cannot read stage2 from disk!", 13, 10, 0

; Disk Address Packet for INT 13h AH=42h
align 4
dap_stage2:
    db  0x10                ; packet size
    db  0                   ; reserved
    dw  STAGE2_SECTORS      ; sectors to read
    dw  STAGE2_OFF          ; buffer offset
    dw  STAGE2_SEG          ; buffer segment
    dd  STAGE2_LBA          ; LBA low
    dd  0                   ; LBA high

boot_drive: db 0

; bytes 446..509: partition table (filled in by tools/make_disk.py)
times 446 - ($ - $$) db 0
times 64 db 0
times 510 - ($ - $$) db 0
dw 0xAA55
