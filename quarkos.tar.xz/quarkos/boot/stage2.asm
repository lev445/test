; =====================================================================
;  QuarkOS - Stage 2 bootloader: 16-bit -> 32-bit -> 64-bit
; =====================================================================
;  Loaded by stage1 at 0x0000:0x8000 (real mode, DL = boot drive).
;
;  Steps:
;   1. enable A20 line
;   2. load kernel (KERNEL_SECTORS sectors from KERNEL_LBA) to 0x40000
;      (INT 13h cannot reliably DMA above 1 MiB, so we stage below 1 MiB)
;   3. build page tables: identity-map first 1 GiB with 2 MiB pages
;   4. switch to 32-bit protected mode, copy kernel 0x40000 -> 0x100000
;   5. enable PAE + LME + PG, switch to 64-bit long mode
;   6. jump to kernel entry point (0x100000)
; =====================================================================

BITS 16
org 0x8000

KERNEL_LBA     equ 2048          ; kernel lives at 1 MiB on disk
KERNEL_SECTORS equ 512           ; 256 KiB budget for kernel.bin
KERNEL_STAGE   equ 0x40000       ; temp landing zone (real-mode reachable)
KERNEL_DEST    equ 0x100000      ; final linked address
CHUNK          equ 64            ; sectors per INT 13h call

; memory map used by this stage:
;   0x00500        scratch (saved DL)
;   0x08000        stage2 code
;   0x10000        PML4
;   0x11000        PDPT (64 entries)
;   0x200000       512 PD tables (2 MiB, full 512 GiB identity)
;   0x20000        GDT
;   0x40000..      kernel staging area

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x8000
    sti
    mov [0x500], dl               ; save boot drive

    mov si, msg_a20
    call print16

    ; ---- enable A20: fast gate + BIOS fallback ----------------------
    in al, 0x92
    or al, 2
    and al, 0xFE                  ; never trigger a reset
    out 0x92, al
    mov ax, 0x2401
    int 0x15                      ; ignore failure, fast gate is enough

    ; ---- load kernel from disk to 0x40000, in chunks ----------------
    mov si, msg_kernel
    call print16

    mov dword [dap_k.lba], KERNEL_LBA
    mov word  [dap_k.seg], (KERNEL_STAGE >> 4)
    mov ebx, KERNEL_SECTORS       ; sectors remaining
.load_loop:
    test ebx, ebx
    jz .load_done
    mov eax, CHUNK
    cmp ebx, eax
    jae .full_chunk
    mov eax, ebx
.full_chunk:
    mov [dap_k.count], ax
    ; INT 13h AH=42h extended read
    mov ah, 0x42
    mov dl, [0x500]
    mov si, dap_k
    int 0x13
    jc disk_error
    ; advance buffer segment (eax sectors * 512 bytes / 16)
    shl eax, 5
    add [dap_k.seg], ax
    ; advance LBA
    mov eax, [dap_k.count]
    add [dap_k.lba], eax
    sub ebx, eax
    jmp .load_loop
.load_done:

    ; ================= VESA/VBE probe (real mode) =====================
    ; VbeInfoBlock @ 0x30000, ModeInfoBlock @ 0x30200, boot info @ 0x30400
    mov ax, 0x3000
    mov es, ax
    xor di, di
    mov ax, 0x4F00                 ; Get Controller Info
    int 0x10
    cmp ax, 0x004F
    jne vbe_fail
    mov si, [es:14]                ; VideoModePtr off
    mov bx, [es:16]                ; VideoModePtr seg
    xor bp, bp                     ; best priority so far
    mov word [pick_mode], 0xFFFF
vbe_scan:
    mov es, bx                     ; walk the mode list
    mov ax, [es:si]
    add si, 2
    cmp ax, 0xFFFF
    je vbe_pick
    mov [cur_mode], ax
    push bx
    mov ax, 0x3000                 ; Get Mode Info
    mov es, ax
    mov di, 0x200
    mov cx, [cur_mode]
    mov ax, 0x4F01
    int 0x10
    pop bx
    cmp ax, 0x004F
    jne vbe_scan
    mov ax, 0x3000                 ; BIOS may clobber ES across int 10h
    mov es, ax
    mov ax, [es:0x200]             ; ModeAttributes: supported + linear
    and ax, 0x0081
    cmp ax, 0x0081
    jne vbe_scan
    cmp byte [es:0x219], 32        ; BitsPerPixel == 32
    jne vbe_scan
    mov cx, [es:0x212]             ; XResolution
    mov dx, [es:0x214]             ; YResolution
    cmp cx, 1024
    jne vbe_try800
    cmp dx, 768
    jne vbe_scan
    mov ax, 3
    jmp vbe_prio
vbe_try800:
    cmp cx, 800
    jne vbe_try640
    cmp dx, 600
    jne vbe_scan
    mov ax, 2
    jmp vbe_prio
vbe_try640:
    cmp cx, 640
    jne vbe_scan
    cmp dx, 480
    jne vbe_scan
    mov ax, 1
vbe_prio:
    cmp ax, bp                     ; keep strictly better matches only
    jbe vbe_scan
    mov bp, ax
    mov ax, [cur_mode]
    mov [pick_mode], ax
    jmp vbe_scan
vbe_pick:
    cmp word [pick_mode], 0xFFFF
    je vbe_fail
    ; fresh ModeInfo for the picked mode (block holds the last scanned one)
    mov ax, 0x3000
    mov es, ax
    mov di, 0x200
    mov cx, [pick_mode]
    mov ax, 0x4F01
    int 0x10
    cmp ax, 0x004F
    jne vbe_fail
    mov bx, [pick_mode]            ; Set Mode: linear framebuffer
    or bx, 0x4000
    mov ax, 0x4F02
    int 0x10
    cmp ax, 0x004F
    jne vbe_fail
    ; ---- fill boot info @ 0x30400 ----
    mov ax, 0x3000                 ; ES again: 0x4F02 may clobber it
    mov es, ax
    mov esi, 0x30400
    mov dword [esi], 0x31454256    ; 'VBE1'
    mov dword [esi+4], 1           ; ok
    movzx eax, word [es:0x212]
    mov [esi+8], eax               ; width
    movzx eax, word [es:0x214]
    mov [esi+12], eax              ; height
    movzx eax, byte [es:0x219]
    mov [esi+16], eax              ; bpp
    movzx eax, word [es:0x210]
    mov [esi+20], eax              ; bytes per scanline
    mov eax, [es:0x228]
    mov [esi+24], eax              ; PhysBasePtr low
    mov dword [esi+28], 0          ; PhysBasePtr high
    mov al, [es:0x220]
    mov [esi+32], al               ; red field position
    mov al, [es:0x222]
    mov [esi+33], al               ; green field position
    mov al, [es:0x224]
    mov [esi+34], al               ; blue field position
    mov al, [es:0x21F]
    mov [esi+35], al               ; red mask size
    mov al, [es:0x221]
    mov [esi+36], al               ; green mask size
    mov al, [es:0x223]
    mov [esi+37], al               ; blue mask size
    jmp vbe_done
vbe_fail:
    mov esi, 0x30400
    mov dword [esi], 0x31454256
    mov dword [esi+4], 0           ; ok = 0 -> text mode fallback
vbe_done:
    xor ax, ax
    mov es, ax                     ; restore ES for the paging code

    ; ---- build page tables (identity map first 1 GiB, 2 MiB pages) --
    ; PML4[0] -> PDPT @ 0x11000
    mov edi, 0x10000
    xor eax, eax
    cld
.zero1:
    mov ecx, 1024
    a32 rep stosd                     ; a32: use full EDI in 16-bit mode
    cmp edi, 0x12000                  ; zero PML4+PDPT (0x10000..0x12000)
    jb .zero1
    mov edi, 0x200000
.zero2:
    mov ecx, 1024
    a32 rep stosd
    cmp edi, 0x400000                 ; zero 512 PD tables (2 MiB of tables)
    jb .zero2

    mov edi, 0x10000
    mov dword [edi], 0x11007          ; PML4[0] = PDPT, P|RW|U (tree for all)
    ; ALL 512 PDPT entries -> PD tables at 0x200000 + i*0x1000
    ; => full 512 GiB identity: real boards park xHCI BARs at ~256 GiB
    ; when Above-4G decoding + resizable BARs push the MMIO hole up
    mov edi, 0x11000
    mov eax, 0x200007
    mov ecx, 512
.pdpt_fill:
    mov [edi], eax
    add eax, 0x1000
    add edi, 8
    loop .pdpt_fill

    ; 512 PDs * 512 entries * 2 MiB = 512 GiB identity, supervisor by default
    mov edi, 0x200000
    mov eax, 0x83                          ; P|RW|PS(2MiB)
    mov ecx, 262144
.pd_fill:
    mov [edi], eax
    add eax, 0x200000
    add edi, 8
    a32 loop .pd_fill                      ; ECX loop: 262144 > 64K

    ; user window: PD0 entries 2..3 = 0x400000..0x7FFFFF get the U bit,
    ; this is where ring-3 code and its stack live; everything else
    ; (kernel, VGA, tables) stays supervisor-only => memory isolation
    mov edi, 0x200000 + 16
    mov dword [edi], 0x400087              ; 0x400000 P|RW|U|PS
    mov edi, 0x200000 + 24
    mov dword [edi], 0x600087              ; 0x600000 P|RW|U|PS

    ; ---- load 64-bit GDT ---------------------------------------------
    lgdt [gdt_ptr]

    ; ---- switch to protected mode ------------------------------------
    cli
    mov eax, cr0
    or eax, 1                              ; PE
    mov cr0, eax
    jmp 0x08:pm_entry                      ; code32 selector

disk_error:
    mov si, msg_disk_err
    call print16
.halt16:
    cli
    hlt
    jmp .halt16

print16:
    pusha
    mov ah, 0x0E
    mov bx, 0x0007
.ploop:
    lodsb
    test al, al
    jz .pdone
    int 0x10
    jmp .ploop
.pdone:
    popa
    ret

msg_hello:    db 0
msg_a20:      db "QuarkOS stage2: A20 on, loading kernel...", 13, 10, 0
msg_kernel:   db 0
msg_disk_err: db "FATAL: disk read failed in stage2!", 13, 10, 0

; Disk Address Packet (kernel load)
align 4
cur_mode:  dw 0
pick_mode: dw 0xFFFF
dap_k:
    db 0x10
    db 0
.count: dw CHUNK
.off:   dw 0x0000
.seg:   dw (KERNEL_STAGE >> 4)
.lba:   dd KERNEL_LBA
        dd 0

; ---------------------------------------------------------------------
;  GDT (loaded once, used for both 32- and 64-bit switches)
; ---------------------------------------------------------------------
align 8
gdt_base:
    dq 0x0000000000000000        ; 0x00 null
gdt_code32:                        ; 0x08 32-bit code
    dw 0xFFFF, 0x0000
    db 0x00, 0x9A, 0xCF, 0x00
gdt_data32:                        ; 0x10 32-bit data
    dw 0xFFFF, 0x0000
    db 0x00, 0x92, 0xCF, 0x00
gdt_code64:                        ; 0x18 64-bit code
    dw 0x0000, 0x0000
    db 0x00, 0x9A, 0x2F, 0x00
gdt_data64:                        ; 0x20 64-bit data
    dw 0x0000, 0x0000
    db 0x00, 0x92, 0x0F, 0x00
gdt_end:
gdt_ptr:
    dw gdt_end - gdt_base - 1
    dd gdt_base

; =====================================================================
;  32-BIT PROTECTED MODE
; =====================================================================
BITS 32
pm_entry:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, 0x8000

    ; ---- copy kernel 0x40000 -> 0x100000 (256 KiB = 65536 dwords) ---
    mov esi, KERNEL_STAGE
    mov edi, KERNEL_DEST
    mov ecx, (KERNEL_SECTORS * 512) / 4
    cld
    rep movsd

    ; ---- enable PAE + SSE (musl/static userspace assumes SSE2) ----
    mov eax, cr4
    or eax, (1 << 5) | (1 << 4) | (1 << 9) | (1 << 10)  ; PAE|PSE|OSFXSR|OSXMMEXCPT
    mov cr4, eax

    ; ---- load CR3 = PML4 ----------------------------------------------
    mov eax, 0x10000
    mov cr3, eax

    ; ---- set LME (long mode enable) in EFER MSR -----------------------
    mov ecx, 0xC0000080
    rdmsr
    or eax, (1 << 8)
    wrmsr

    ; ---- enable paging + stay in PM, then far-jump to 64-bit ----------
    mov eax, cr0
    or eax, (1 << 31)             ; PG
    mov cr0, eax

    jmp 0x18:lm_entry             ; code64 selector

; =====================================================================
;  64-BIT LONG MODE - hand over to the kernel
; =====================================================================
BITS 64
lm_entry:
    mov ax, 0x20
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov rsp, 0x80000

    ; kernel entry expects: nothing special, it sets up its own stack
    mov rax, KERNEL_DEST
    jmp rax
