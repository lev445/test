#!/usr/bin/env python3
"""
QuarkOS disk image builder.

Layout (512-byte sectors):
  LBA 0                : stage1 MBR + partition table
  LBA 1..16            : stage2 bootloader
  LBA KERNEL_LBA..+N   : flat kernel binary
  LBA PART_LBA..       : FAT32 partition (built with mkfs.vfat + mcopy)
"""
import os
import struct
import subprocess
import sys
import tempfile

SECT = 512

def main():
    img_path = sys.argv[1] if len(sys.argv) > 1 else "disk.img"
    image_mb = int(sys.argv[2]) if len(sys.argv) > 2 else 64
    kernel_lba = int(sys.argv[3]) if len(sys.argv) > 3 else 2048
    kernel_sectors = int(sys.argv[4]) if len(sys.argv) > 4 else 512
    part_lba = int(sys.argv[5]) if len(sys.argv) > 5 else 4096

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    build = os.path.join(root, "build")

    total_sectors = image_mb * 1024 * 1024 // SECT
    part_sectors = total_sectors - part_lba

    # ---- stage1 MBR ----------------------------------------------------
    with open(os.path.join(build, "boot.bin"), "rb") as f:
        mbr = bytearray(f.read())
    assert len(mbr) == 512, f"boot.bin is {len(mbr)} bytes, expected 512"

    # partition entry 0: bootable FAT32-LBA
    entry = struct.pack("<BBBBBBBBLL",
        0x80,                  # boot flag
        0, 0, 0,               # CHS start (ignored, LBA used)
        0x0C,                  # type: FAT32 LBA
        0xFF, 0xFF, 0xFF,      # CHS end (fake)
        part_lba,
        part_sectors)
    mbr[446:446 + 16] = entry

    with open(img_path, "wb") as f:
        f.write(bytes(mbr))
        # pad up to partition start with zeros; kernel is written below
        f.write(b"\0" * (part_lba * SECT - 512))

    # ---- stage2 --------------------------------------------------------
    with open(os.path.join(build, "stage2.bin"), "rb") as f:
        stage2 = f.read()
    if len(stage2) > 16 * SECT:
        sys.exit(f"stage2.bin too big: {len(stage2)} > {16*SECT}")
    with open(img_path, "r+b") as f:
        f.seek(1 * SECT)
        f.write(stage2)

    # ---- kernel --------------------------------------------------------
    with open(os.path.join(build, "kernel.bin"), "rb") as f:
        kern = f.read()
    if len(kern) > kernel_sectors * SECT:
        sys.exit(f"kernel.bin too big: {len(kern)} > {kernel_sectors*SECT}")
    with open(img_path, "r+b") as f:
        f.seek(kernel_lba * SECT)
        f.write(kern)
        f.write(b"\0" * (kernel_sectors * SECT - len(kern)))

    # ---- FAT32 partition ----------------------------------------------
    fsroot = os.path.join(root, "fsroot")
    with tempfile.NamedTemporaryFile(suffix=".part", delete=False) as tf:
        part_path = tf.name
    try:
        with open(part_path, "wb") as f:
            f.write(b"\0" * (part_sectors * SECT))
        subprocess.run(["mkfs.vfat", "-F", "32", "-n", "QUARKOS", "-v", part_path],
                       check=True, capture_output=True)
        if os.path.isdir(fsroot):
            for name in sorted(os.listdir(fsroot)):
                src = os.path.join(fsroot, name)
                if os.path.isdir(src):
                    subprocess.run(["mcopy", "-s", "-i", part_path, src, "::/"],
                                   check=True)
                else:
                    subprocess.run(["mcopy", "-i", part_path, src, "::/"],
                                   check=True)
        with open(part_path, "rb") as f:
            part_data = f.read()
        with open(img_path, "r+b") as f:
            f.seek(part_lba * SECT)
            f.write(part_data)
    finally:
        os.unlink(part_path)

    print(f"{img_path}: {image_mb} MiB image built OK")
    print(f"  stage1 @ LBA 0, stage2 @ LBA 1, kernel @ LBA {kernel_lba}, "
          f"FAT32 @ LBA {part_lba} ({part_sectors} sectors)")

if __name__ == "__main__":
    main()
