#!/usr/bin/env python3
"""Convert a QEMU screendump PPM (P6) to PNG using pure stdlib (zlib+struct)."""
import struct
import sys
import zlib


def main():
    src, dst = sys.argv[1], sys.argv[2]
    with open(src, "rb") as f:
        data = f.read()

    # parse PPM header: P6 \n width height \n maxval \n
    assert data[:2] == b"P6"
    idx = 2
    vals = []
    while len(vals) < 3:
        # skip whitespace and comments
        while data[idx:idx+1] in (b" ", b"\n", b"\r", b"\t"):
            idx += 1
        if data[idx:idx+1] == b"#":
            while data[idx:idx+1] != b"\n":
                idx += 1
            continue
        start = idx
        while data[idx:idx+1] not in (b" ", b"\n", b"\r", b"\t"):
            idx += 1
        vals.append(int(data[start:idx]))
    idx += 1  # single whitespace char after maxval
    w, h, maxv = vals
    pixels = data[idx:idx + w * h * 3]

    def chunk(typ, payload):
        c = typ + payload
        return struct.pack(">I", len(payload)) + c + struct.pack(">I", zlib.crc32(c))

    raw = b"".join(b"\x00" + pixels[y*w*3:(y+1)*w*3] for y in range(h))
    png = (b"\x89PNG\r\n\x1a\n" +
           chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) +
           chunk(b"IDAT", zlib.compress(raw, 9)) +
           chunk(b"IEND", b""))
    with open(dst, "wb") as f:
        f.write(png)
    print(f"{dst}: {w}x{h} PNG written")


if __name__ == "__main__":
    main()
