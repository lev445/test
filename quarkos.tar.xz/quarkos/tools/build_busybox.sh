#!/bin/sh
# =====================================================================
#  Host-side builder: static musl busybox for the QuarkOS guest rootfs
#
#  Reproduces fsroot/BIN/busybox (lowercase name on purpose: the
#  busybox multiplexer activates on a case-sensitive "busybox" prefix
#  of basename(argv[0]), and our FAT32 driver preserves LFN case).
#
#  Needs on the host:
#    - a musl cross/native toolchain:  MUSL_GCC=musl-gcc (or a wrapper
#      like the one built from musl sources:
#        musl:  ./configure --prefix=$M && make && make install
#        wrapper: gcc -specs $M/musl-gcc.specs  (tools/musl-gcc.specs.sh)
#      plus kernel UAPI headers copied into $M/include:
#        linux/ asm/ asm-generic/  (from linux-libc-dev)
#    - busybox sources (BUSYBOX_SRC, default ./busybox-1.36.1)
#
#  Usage:  BUSYBOX_SRC=/path/to/busybox MUSL_GCC=/path/to/musl-gcc \
#          tools/build_busybox.sh
# =====================================================================
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
BUSYBOX_SRC=${BUSYBOX_SRC:-$ROOT/../busybox-1.36.1}
MUSL_GCC=${MUSL_GCC:-$(command -v musl-gcc || true)}

if [ -z "$MUSL_GCC" ]; then
    echo "MUSL_GCC not set and musl-gcc not in PATH" >&2
    echo "build musl first, see the header of this script" >&2
    exit 1
fi
if [ ! -d "$BUSYBOX_SRC" ]; then
    echo "busybox sources not found at $BUSYBOX_SRC" >&2
    exit 1
fi

# bring-up applet set: small, read-only-friendly, ash included.
# (defconfig pulls kbd_mode/nandwrite which need UAPI headers musl
#  does not ship; trim as you like -- the ABI layer does not care.)
APPLETS="STATIC ECHO CAT LS WC UNAME HEAD TAIL ASH SH_IS_ASH
         FEATURE_LS_FILETYPE FEATURE_AUTOWIDTH
         ASH_ECHO ASH_PRINTF ASH_HELP ASH_CMDCMD FEATURE_SH_MATH ASH_SLEEP"

cd "$BUSYBOX_SRC"
make allnoconfig >/dev/null
for a in $APPLETS; do
    ./scripts/config -e "$a"
done
make oldconfig >/dev/null
make CC="$MUSL_GCC" -j"$(nproc)"

mkdir -p "$ROOT/fsroot/BIN"
cp busybox "$ROOT/fsroot/BIN/busybox"
echo "installed: $ROOT/fsroot/BIN/busybox ($(stat -c%s busybox) bytes)"
echo "now: make disk.img   and   python3 tools/qemu_busybox.py"
