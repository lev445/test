/* stage-1 bring-up probe for the Linux-ABI compat layer:
 * built on the HOST with: musl-gcc -static -no-pie -O2
 * (see doc/PORT_BUSYBOX.md); the resulting ELF runs inside QuarkOS */
#include <stdio.h>
int main(int argc, char **argv) {
    puts("hello from musl (static, linux ABI)");
    printf("argc=%d argv0=%s\n", argc, argv[0]);
    return 0;
}
