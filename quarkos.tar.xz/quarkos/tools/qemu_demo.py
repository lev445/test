#!/usr/bin/env python3
"""
Automated headless test/demo for QuarkOS.

Runs QEMU with:
  - serial  -> build/serial.log
  - monitor -> unix socket (we drive it: sendkey, screendump)
  - VGA screendump -> PNG screenshots in build/shots/

Usage: python3 tools/qemu_demo.py [--timeout SECONDS]
"""
import os
import socket
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, "build")
SHOTS = os.path.join(BUILD, "shots")
MON = "/tmp/quarkos-mon.sock"
SERIAL = os.path.join(BUILD, "serial.log")

KEYMAP = {
    " ": "spc", "-": "minus", "_": "shift-minus", ".": "dot", "/": "slash",
    "\n": "ret", ",": "comma", ":": "shift-semicolon", "=": "equal",
}


def key_for(ch):
    if ch in KEYMAP:
        return KEYMAP[ch]
    if ch.isupper():
        return "shift-" + ch.lower()
    return ch


class Monitor:
    def __init__(self, path, timeout=10):
        self.s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        deadline = time.time() + timeout
        while True:
            try:
                self.s.connect(path)
                break
            except OSError:
                if time.time() > deadline:
                    raise
                time.sleep(0.2)
        self.s.settimeout(5)
        time.sleep(0.3)
        self.s.recv(65536)  # banner

    def cmd(self, line, wait=0.4):
        self.s.sendall((line + "\n").encode())
        time.sleep(wait)
        try:
            self.s.recv(65536)
        except socket.timeout:
            pass

    def close(self):
        try:
            self.cmd("quit")
        except OSError:
            pass
        self.s.close()


def wait_serial(marker, timeout=60):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with open(SERIAL, "r", errors="replace") as f:
                if marker in f.read():
                    return True
        except FileNotFoundError:
            pass
        time.sleep(0.5)
    return False


def type_text(mon, text, delay=0.04):
    for ch in text:
        mon.cmd("sendkey " + key_for(ch), wait=delay)
    mon.cmd("sendkey ret", wait=0.2)


def main():
    os.makedirs(SHOTS, exist_ok=True)
    for p in (MON, SERIAL):
        if os.path.exists(p):
            os.unlink(p)

    proc = subprocess.Popen(
        ["qemu-system-x86_64",
         "-drive", "format=raw,file=" + os.path.join(ROOT, "disk.img"),
         "-m", "256", "-net", "none", "-display", "none",
         "-serial", "file:" + SERIAL,
         "-monitor", "unix:" + MON + ",server,nowait"],
        cwd=ROOT)

    try:
        if not wait_serial("shell ready", timeout=90):
            print("TIMEOUT waiting for boot; serial log:")
            with open(SERIAL, errors="replace") as f:
                print(f.read())
            sys.exit(1)
        print("=== booted, shell ready ===")

        mon = Monitor(MON)
        time.sleep(1.0)

        steps = [
            ("boot",       None,       0.5),
            ("lsblk",      "lsblk",    1.5),
            ("ls",         "ls /",     2.0),
            ("cat",        "cat README.TXT", 3.0),
            ("cat2",       "cat HELLO.TXT", 1.5),
            ("ls_subdir",  "ls /DOCS", 2.0),
            ("cat_subdir", "cat /DOCS/NOTES.TXT", 2.0),
            ("help",       "help",     1.5),
            ("time_ver",   "time",     0.7),
            ("ver",        "ver",      1.0),
            ("ring3_run",  "run /BIN/HELLO.BIN", 1.0),
            ("ring3_exit", None,       2.5),
            ("ring3_io",   "run /BIN/TRAP_IO.BIN", 1.5),
            ("ring3_mem",  "run /BIN/TRAP_MEM.BIN", 1.5),
        ]
        for name, text, wait in steps:
            if text:
                type_text(mon, text)
            time.sleep(wait)
            ppm = os.path.join(SHOTS, name + ".ppm")
            mon.cmd("screendump " + ppm, wait=0.8)
            subprocess.run([sys.executable, os.path.join(ROOT, "tools/ppm2png.py"),
                            ppm, os.path.join(SHOTS, name + ".png")], check=True)
            print(f"shot: {name}.png")

        # final: shut the OS down from the shell itself
        type_text(mon, "shutdown")
        time.sleep(2)
        mon.close()
    finally:
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()

    print("=== serial log ===")
    with open(SERIAL, errors="replace") as f:
        print(f.read())


if __name__ == "__main__":
    main()
