#!/usr/bin/env python3
"""
Headless bring-up test: static musl busybox inside QuarkOS ring 3.

Boots disk.img in QEMU, drives the shell through the QEMU monitor
(sendkey), and runs a battery of `run /BIN/busybox <applet>` commands.
Everything the guest prints lands in build/busybox_serial.log; the
script then greps it for the expected markers and prints a PASS/FAIL
table. Usage: python3 tools/qemu_busybox.py [--timeout SECONDS]
"""
import os
import socket
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, "build")
MON = "/tmp/quarkos-bb-mon.sock"
SERIAL = os.path.join(BUILD, "busybox_serial.log")

KEYMAP = {
    " ": "spc", "-": "minus", "_": "shift-minus", ".": "dot", "/": "slash",
    "\n": "ret", ",": "comma", ":": "shift-semicolon", "=": "equal",
    "'": "apostrophe", "\"": "shift-apostrophe", "\\": "backslash",
    "%": "shift-5",
}


def key_for(ch):
    if ch in KEYMAP:
        return KEYMAP[ch]
    if ch.isupper():
        return "shift-" + ch.lower()
    return ch


class Monitor:
    def __init__(self, path, timeout=15):
        self.s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        deadline = time.time() + timeout
        while True:
            try:
                self.s.connect(path)
                break
            except OSError:
                if time.time() > deadline:
                    raise
                time.sleep(0.2)
        self.s.settimeout(5)
        time.sleep(0.3)
        try:
            self.s.recv(65536)
        except socket.timeout:
            pass

    def cmd(self, line, wait=0.3):
        self.s.sendall((line + "\n").encode())
        time.sleep(wait)
        try:
            self.s.recv(65536)
        except socket.timeout:
            pass

    def type_line(self, line, settle=1.2):
        for ch in line:
            self.cmd("sendkey " + key_for(ch), wait=0.03)
        self.cmd("sendkey ret", wait=settle)


def serial_lines(offset):
    """lines of the serial log written after byte offset `offset`"""
    try:
        with open(SERIAL, "r", errors="replace") as f:
            f.seek(offset)
            data = f.read()
    except OSError:
        return [], offset
    return [l.rstrip("\r") for l in data.split("\n")], offset + len(data.encode())


def wait_lines(pred, offset, timeout=25):
    """wait until any NEW serial line (after offset) satisfies pred(line)"""
    import re
    rx = re.compile(pred)
    deadline = time.time() + timeout
    cur = offset
    while time.time() < deadline:
        lines, cur = serial_lines(cur)
        for l in lines:
            if rx.search(l):
                return True, cur
        time.sleep(0.3)
    return False, cur


def main():
    os.makedirs(BUILD, exist_ok=True)
    if os.path.exists(MON):
        os.unlink(MON)
    if os.path.exists(SERIAL):
        os.unlink(SERIAL)

    qemu = subprocess.Popen(
        ["qemu-system-x86_64", "-drive", "format=raw,file=disk.img",
         "-m", "256", "-net", "none", "-display", "none",
         "-serial", "file:" + SERIAL,
         "-monitor", "unix:" + MON + ",server,nowait"],
        cwd=ROOT, stdin=subprocess.DEVNULL)

    try:
        if not wait_lines(r"shell ready", 0, timeout=40)[0]:
            print("FAIL: shell never came up")
            return 1
        mon = Monitor(MON)
        mon.cmd("info status")

        # markers are line-anchored so the shell's own input echo of the
        # typed command can never fake a PASS
        commands = [
            ("run /BIN/busybox echo HELLO-FROM-BUSYBOX-ON-QUARKOS",
             r"^HELLO-FROM-BUSYBOX-ON-QUARKOS$"),
            ("run /BIN/busybox uname -a",
             r"^QuarkOS quark "),
            ("run /BIN/busybox cat /HELLO.TXT",
             r"^Hello, world$"),
            ("run /BIN/busybox ls /",
             r"^BIN$"),
            ("run /BIN/busybox wc -c /HELLO.TXT",
             r"^13 /HELLO\.TXT$|^ *13 /HELLO\.TXT$"),
            ("run /BIN/busybox sh -c pwd",
             r"^/$"),
        ]
        results = []
        _, off = serial_lines(0)
        for cmdline, marker in commands:
            mon.type_line(cmdline, settle=1.5)
            ok, off = wait_lines(marker, off, timeout=20)
            results.append((cmdline, ok))
            if not ok:
                time.sleep(1.0)   # let the shell recover before next cmd

        # interactive ash session through the new `sh` passthrough:
        # builtins only (no fork/execve yet), like a real console login
        mon.type_line("sh", settle=2.0)
        mon.type_line("printf 'ASH-PRINTF-%s\\n' OK", settle=1.5)
        ok2, off = wait_lines(r"^ASH-PRINTF-OK$", off, timeout=10)
        results.append(("ash interactive: printf builtin", ok2))
        mon.type_line("cd /DOCS", settle=1.0)
        mon.type_line("pwd", settle=1.5)
        ok3, off = wait_lines(r"^/DOCS$", off, timeout=10)
        results.append(("ash interactive: cd + pwd builtins", ok3))
        mon.type_line("exit", settle=2.0)
        ok4, off = wait_lines(r"task exited", off, timeout=10)
        results.append(("ash interactive: exit returns to quark shell", ok4))

        mon.type_line("echo BBTEST-DONE", settle=1.0)
        wait_lines(r"^BBTEST-DONE$", off, timeout=10)
        mon.cmd("quit")
    finally:
        time.sleep(0.5)
        qemu.terminate()

    print()
    print("==== busybox bring-up results ====")
    fails = 0
    for cmdline, ok in results:
        print(("PASS  " if ok else "FAIL  ") + cmdline)
        fails += 0 if ok else 1
    print("==================================")
    print("serial log: " + SERIAL)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
