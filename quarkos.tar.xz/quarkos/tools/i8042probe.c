/* =====================================================================
 *  i8042probe - direct PS/2 controller probe from Linux userspace
 *
 *  For when dmesg says "PNP: No PS/2 controller found" but the port
 *  is physically staring at you from the back panel. Bypasses all
 *  kernel drivers: raw inb/outb through ioperm().
 *
 *  Build & run (AS ROOT):
 *      gcc -O2 i8042probe.c -o i8042probe
 *      sudo ./i8042probe
 *
 *  Safe by design: only reads config, runs the controller self-test
 *  and resets the keyboard. Do NOT add write commands like 0xD1
 *  (output port) here unless you enjoy spontaneous reboots.
 * ===================================================================== */
#include <stdio.h>
#include <unistd.h>
#include <sys/io.h>

#define KBD_DATA   0x60
#define KBD_STATUS 0x64

static unsigned char st(void) { return inb(KBD_STATUS); }

static int wait_data(void) {          /* status bit 0: output buffer full */
    for (int i = 0; i < 200000; i++) { if (st() & 1) return 1; usleep(10); }
    return 0;
}
static int wait_idle(void) {          /* status bit 1: input buffer full */
    for (int i = 0; 200000 > i; i++) { if (!(st() & 2)) return 1; usleep(10); }
    return 0;
}

int main(void) {
    if (ioperm(KBD_DATA, 8, 1)) { perror("ioperm (need root?)"); return 1; }

    unsigned char s = st();
    printf("status port 0x64      = 0x%02x%s\n", s,
           (s == 0xFF || s == 0x00) ? "   (floating/dead-looking)" : "");

    if (wait_idle()) {
        outb(0x20, KBD_STATUS);       /* read controller command byte */
        if (wait_data()) {
            unsigned char cb = inb(KBD_DATA);
            printf("command byte        = 0x%02x  (bit0 IRQ1=%d, bit4 kbd-clk-disabled=%d, bit6 translate=%d)\n",
                   cb, cb & 1, (cb >> 4) & 1, (cb >> 6) & 1);
        } else printf("command byte        = NO DATA (controller silent)\n");
    } else printf("command byte        = controller busy forever?\n");

    if (wait_idle()) {
        outb(0xAA, KBD_STATUS);       /* controller self test */
        if (wait_data()) {
            unsigned char r = inb(KBD_DATA);
            printf("self-test 0xAA      = 0x%02x  %s\n", r,
                   r == 0x55 ? "-> CONTROLLER ALIVE" : "(want 0x55)");
        } else printf("self-test 0xAA      = NO DATA (controller silent)\n");
    }

    if (wait_idle()) {
        int tries = 3;
        unsigned char r = 0;
        while (tries--) {
            outb(0xFF, KBD_DATA);     /* keyboard reset; ack = 0xFA */
            if (!wait_data()) { r = 0; break; }
            r = inb(KBD_DATA);
            if (r != 0xFE) break;     /* 0xFE = RESEND: say it again */
            printf("keyboard said RESEND, retrying (%d left)...\n", tries);
        }
        if (r) {
            printf("keyboard reset 0xFF = 0x%02x  %s\n", r,
                   r == 0xFA ? "-> KEYBOARD (or SMM emulation) ANSWERS" :
                   r == 0xFE ? "-> still RESEND: device deaf or line noisy" : "");
            if (r == 0xFA && wait_data())
                printf("keyboard BAT        = 0x%02x (0xAA = selftest ok)\n",
                       inb(KBD_DATA));
        } else printf("keyboard reset 0xFF = NO REPLY (no device or no emulation)\n");
    }

    printf("\nverdict guide:\n"
           "  self-test 0x55 + kbd 0xFA  -> port & controller & keyboard alive: OS-side init is all you need\n"
           "  self-test 0x55 + kbd silent -> controller alive, keyboard behind port not talking (USB w/o port emulation? try PS/2 kb)\n"
           "  all silent / status 0xFF    -> controller truly absent or firmware-gated: BIOS option or USB-path quest\n");
    return 0;
}
