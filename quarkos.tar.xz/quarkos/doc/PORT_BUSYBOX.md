# PORT DOSSIER: busybox on QuarkOS

Цель выбрана зрителем-ставшим-разработчиком: «busybox можно ;D просто
почему бы и нет». Документ фиксирует стратегию, измеренные требования
и порядок bring-up. Ревью-статус: консультант, код пишет ведущий разработчик.

## 0. Стратегия (главный твист)

Никакого «порта musl» и никакого нового тулчейна не нужно:

1. На хосте уже есть **musl-gcc** (Debian: `musl-tools`, Arch: `musl` + wrapper).
   Он собирает **статические ELF с Linux x86_64 syscall-ABI**
   (rax=номер, rdi/rsi/rdx/r10/r8/r9, `syscall`, возврат = -errno).
2. Бинарю всё равно, какой триплет указан: он просто дёргает номера
   сисколлов. Значит, задача QuarkOS — реализовать **подмножество Linux
   x86_64 ABI** (baby-compat-layer, как WSL наоборот).
3. busybox собирается тем же musl-gcc: `make CC=musl-gcc defconfig config`,
   статикой, с вырезанным лишним (см. §4). Статический busybox ≈ 0.8–1.1 МиБ.

Следствие: ступень M4 из лестницы («порт musl») **упраздняется** — вместо
неё «таблица Linux-сисколлов в ядре». Дешевле на порядок.

## 1. Измеренные требования (strace, musl 1.2.3, x86_64, static)

### Этап A — «hello, puts» (bring-up milestone)
`arch_prctl(ARCH_SET_FS)` (TLS!), `set_tid_address`, `writev`,
`exit_group`, `ioctl` (TCGETS-проба).
**Итого 5 сисколлов.** Всё остальное — шум загрузки execve.

### Этап B — stdio + malloc + файлы + каталоги
добавляются: `brk`, `mmap`, `munmap`, `open`, `read`, `close`,
`fcntl`, `getdents64` (+ позже `newfstatat` для stat-семейства).
malloc musl = brk + mmap выше порога; оба тривиальны в заглушечной
форме (bump-аллокатор поверх пользовательского окна).

### Этап C — shell-поведение (fork/pipe/exec/wait)
добавляются: `fork`, `execve`, `wait4`, `pipe`, `dup2`,
`rt_sigprocmask` + доставка сигналов (Ctrl-C → SIGINT),
`gettid`; у запускаемых программ: `openat`, `pread64`, `access`,
`mprotect`, а также опциональные `rseq`, `set_robust_list`,
`prlimit64`, `getrandom`, `futex`.

### Терпимость к ENOSYS
musl корректно деградирует при ENOSYS на: `rseq`, `set_robust_list`,
`prlimit64`, `getrandom` (частично), `mprotect` (не критичен без ASLR).
glibc — нет; поэтому весь порт ориентируется ТОЛЬКО на musl-сборку.

## 2. Критическая тонкость: буферизация stdio

`isatty(1)` делается через `ioctl(TCGETS)`. Если вернуть -ENOTTY,
musl-stdio переключится в **полную буферизацию**: приглашение ash и
`puts` не появятся на экране до exit. Поэтому с самого начала
ioctl(TCGETS) на fd 0/1/2 должен **успевать** (фейковый struct termios),
иначе демо выглядит мёртвым. Это первая неочевидная мина порта.

## 3. Ядерные работы по этапам (карта мин)

| Работа | Зачем порту | Ступень лестницы |
|--------|-------------|------------------|
| ELF-загрузчик (PT_LOAD, entry, stack-ABI: argc/argv/envp/auxv) | исполнять статик-ELF | M1 |
| Linux-ABI диспетчер: таблица номер→хендлер, -errno в rax | вместо своих номеров | M1+ |
| user-окно 16 МиБ (PD-записи 2..9 с U-битом) — стоп-гэп до адресных пространств | статический busybox ≈ 1 МиБ + куча | стоп-гэп M2 |
| fd-таблица процесса + VFS: open/read/write/close/lseek/dup2/fcntl/getdents64/newfstatat | этап B | M3 |
| Запись в FAT32 **с созданием LFN-записей** | cp/mv/redirect'ы создают файлы; симлинков в FAT нет | M3+ |
| fork = копирование пользовательского окна + своих страниц; execve = перезагрузить образ; wait4 | ash запускает внешние команды | M2 |
| pipe + dup2 | пайплайны `ls | wc` | M2/M3 |
| termios-lite: TCGETS/TCSETS, raw-режим, Ctrl-C → SIGINT; доставка сигналов | интерактивный ash | M5-lite |
| devfs-lite: /dev/null, /dev/zero, /dev/tty, /dev/console | ash и stdio | M3 |
| RTC (CMOS) для clock_gettime | даты в ls -l | M3 (косметика) |
| chmod/access → всегда успех (в FAT нет прав) | иначе cp/mv сыплют ошибками | M3 |

## 4. Рецепт сборки busybox (хост)

```bash
git clone https://git.busybox.net/busybox && cd busybox
make defconfig
# в .config: CONFIG_STATIC=y; выключить: networking*, features,
# требующие /proc (top, ps), utmp, locale, dpkg/rpm-семейство
make CC=musl-gcc HOSTCC=gcc -j$(nproc)
# результат: ./busybox (статика, ~1 МиБ)
```

Запуск на QuarkOS без симлинков (в FAT их нет): мультиплексор понимает
`busybox <applet> [args]`; либо шелл подкладывает копии бинаря под именами
applet'ов (8.3! см. мины). Первой на диск кладётся копия с именем
`BUSYBOX.BIN`.

## 5. Мины формата имен и FAT

* 8.3: имена applet'ов ≤ 8 символов в верхнем регистре: LS, CAT, CP, MV, RM,
  MKDIR, ECHO, SH (ash → `SH.BIN` или запуск через BUSYBOX). Длинные
  (hexedit…) не влезут — политика имен на совести разработчика.
* Нет прав доступа, нет uid, нет симлинков, нет device-файлов: всё это
  изображается успехом в compat-слое.
* Регистр вывода `ls`: наш FAT-драйвер читает LFN, но при создании файлов
  надо писать и LFN, и short-запись, иначе host-инструменты увидят мусор.

## 6. Порядок bring-up и критерии успеха

1. **hello**: статический musl-`puts` печатает строку и выходит с кодом 0.
   Критерий: 5 сисколлов из §1A работают, ELF-загрузчик жив.
2. **cat/ls из busybox**: `busybox cat /README.TXT`, `busybox ls /BIN`.
   Критерий: этап B + getdents64 + termios-фейк (§2).
3. **cp/mv/rm**: создание/удаление файлов с LFN. Критерий: файл пережил
   перезагрузку VM.
4. **ash интерактивно**: `busybox sh`, приглашение, встроенные команды,
   запуск внешних через fork/execve, пайплайн `ls | wc -l`, Ctrl-C.
   Критерий: сессия из 10 команд без паник.
5. **Трофей**: `busybox vi` редактирует файл. Критерий: скриншот в doc/
   и право хвастаться везде, где есть интернет.

## 7. Оценка

Этапы 1–2: ступени M1+M3 лестницы (ELF, fd, VFS-чтение, termios-фейк).
Этапы 3–4: M2/M3/M5-lite (fork/exec, запись+LFN, сигналы).
Этап 5: терминальная дисциплина raw-режима.
Суммарно: это и есть вся оставшаяся лестница, но теперь у каждой ступени
есть измеримый критерий «/busybox сделал X». Лестница превратилась в план.

## 7.5. Milestone 1: ДОСТИГНУТ (консультант не удержался)

Реализовано и проверено в QEMU:
* `kernel/elf.c` — загрузчик статических ELF64 ET_EXEC: PT_LOAD в user-окно,
  brk/mmap-bump, начальный стек System V (argc/argv/envp/auxv AT_PAGESZ);
* `kernel/linux.c` — таблица Linux x86_64 ABI из §1A+B: write/writev/read
  (EOF)/close/ioctl(TCGETS-фейк)/brk/mmap/munmap/arch_prctl(ARCH_SET_FS)/
  set_tid_address/exit/exit_group, остальное -ENOSYS;
* `proc_abi`: flat-бинари живут со старым ABI QuarkOS, ELF — с Linux-ABI
  (программы Зрителя не пострадали при переходе);
* `run /BIN/MHELLO.BIN foo bar` (musl-gcc -static -no-pie) печатает
  `hello from musl` и `argc=3 argv0=/BIN/MHELLO.BIN`, выходит с кодом 0.

### Мина №4 (измерена кровью): SSE
musl под x86_64 использует SSE2 с первой функции (`pxor xmm0,xmm0` в
vfprintf). Без CR4.OSFXSR это #UD (exception 6) прямо в printf.
Лечится в stage2: CR4 |= PAE|PSE|OSFXSR|OSXMMEXCPT.
Следствие на будущее: с несколькими процессами ядро обязано сохранять
xmm0-15 на контекст-свитче (FXSAVE/FXRSTOR или XSAVE) — записка в M2.

### Ограничения stage-1, осознанные
* staging 128 КиБ (busybox не влезет — нужен потоковый лоадер, это M2-work);
* read() = EOF, open() = ENOSYS (этап 2 досье);
* mmap/brk — bump-аллокаторы без освобождения;
* один процесс: save FPU-состояния не нужен, пока не появился M2.

## 8. Роли

Ведущий разработчик: всё вышеперечисленное, руками, как завещал.
Консультант: ревью, стрейс-логи по запросу, таблица Linux-номеров
сисколлов (include/asm-generic/unistd.h из ядра Linux — первоисточник),
аптечка у triple fault'ов и кофейная поддержка на этапе 4.
