# CODE_TOUR — как читать QuarkOS

ОС спроектирована так, чтобы её можно было прочитать целиком за вечер.
Ниже — карта, три сквозных сюжета и эксперименты для проверки понимания.

## 1. Карта файлов (в каком порядке читать)

### Слой 0: загрузка (читается первым, ~200 строк asm)
| Файл | Суть | Смотри, если хочешь понять… |
|------|------|------------------------------|
| `boot/boot.asm` | MBR, 512 Б: читает stage2 через INT 13h AH=42h | что такое DAP и зачем сигнатура 0xAA55 |
| `boot/stage2.asm` | A20, загрузка ядра, таблицы страниц, 16→32→64 | почему `a32 rep stosd`, зачем чанки по 64 сектора, где ставится U-бит |

### Слой 1: скелет ядра
| Файл | Суть |
|------|------|
| `kernel/entry.asm` | точка входа: стек и `call kmain` |
| `kernel/kernel.c` | порядок инициализации всего (читай сверху вниз — это оглавление ОС) |
| `kernel/io.h` | inb/outb/insw/outsw — весь «физический» контакт с железом |
| `kernel/console.c` | VGA 80×25 + kprintf; зеркало в COM1 |

### Слой 2: прерывания
| Файл | Суть |
|------|------|
| `kernel/isr.asm` | PUSHALL/POPALL, стабы ISR/IRQ, **оба syscall-входа** |
| `kernel/idt.h` | `regs_t` — ВНИМАНИЕ: порядок полей обратный порядку push! |
| `kernel/idt.c` | таблица гейтов, диспетчер: exception / user-fault / IRQ |
| `kernel/pic.c`, `timer.c`, `keyboard.c` | 8259A, PIT 1 кГц, PS/2 |

### Слой 3: ring 3
| Файл | Суть |
|------|------|
| `kernel/gdt.c` | селекторы; порядок user-пары продиктован SYSRET |
| `kernel/tss.c` | RSP0 + ltr; iopb >= limit → IO из ring 3 запрещено |
| `kernel/proc.c` | iretq-трамплин в user, rec_rsp/rec_rip, убийца задач |
| `kernel/syscall.c` | MSR'ы быстрого пути + диспетчер сисколлов |
| `kernel/shell.c` | `cmd_run`: загрузка flat-образа и вход в ring 3 |
| `userland/usyscall.h`, `*.c`, `*.asm` | пользовательская сторона |

### Слой 4: драйверы (десерт, читается независимо)
| Файл | Суть |
|------|------|
| `kernel/ata.c` | PIO: polling BSY/DRQ, IDENTIFY, LBA28/48 |
| `kernel/fat32.c` | BPB → кластерные цепочки → каталоги → LFN |

## 2. Три сквозных сюжета

**Путь сектора** (что происходит на `cat HELLO.TXT`):
`shell.c:fat_cat_file` → `fat32.c:fat_find` (каталог) → `fat_next_cluster`
(FAT) → `ata_read_sectors` (pio: select → cmd 0x20 → poll DRQ → `insw`) →
порты 0x1F0… → байты в `sect[]` → `con_putc` на экран и в COM1.

**Путь клавиши**: IRQ1 → `isr.asm:irq1` → `idt.c:isr_handler` →
`keyboard.c:keyboard_irq` (scancode → ASCII, кольцо-буфер) → EOI →
`shell.c` в цикле `keyboard_getc()` печатает эхо.

**Путь сисколла**: user `syscall` → CPU: rcx=RIP, r11=RFLAGS, CPL=0,
RIP=LSTAR → `isr.asm:syscall_entry_msr` (swapgs, kernel-стек, синтетический
кадр) → `syscall.c:syscall_handler` → POPALL → rcx/r11/rsp из кадра →
swapgs → `o64 sysret` → user.

## 3. Магические числа одной таблицей

| Значение | Что это |
|----------|---------|
| 0x08/0x10 | kernel code/data |
| 0x18/0x20 | user data/code (порядок — требование SYSRET) |
| 0x1B/0x23 | user SS/CS с RPL3 |
| 0x28 | TSS |
| 0x400000 / 0x600000 | user-окно: код / верх стека |
| LBA 0 / 1 / 2048 / 4096 | stage1 / stage2 / ядро / FAT32 |
| 0x80 | вектор сисколла (и legacy int-гейт, и метка в кадре) |
| MSR 0xC0000081/82/84 | STAR / LSTAR / FMASK |

## 4. Эксперименты «сломай и посмотри» (лучший способ понять)

1. Убери U-бит у PD-записей 2..3 в `stage2.asm` → hello получит #PF на
   первой же инструкции: ring 3 не видит даже собственный код.
2. Закомментируй `tss_init()` → первый же timer IRQ из user mode = #GP
   двойной_fault паника: CPU не знает, куда класть стек ядра.
3. Замени `o64 sysret` на `sysret` (без REX.W) → возврат в 32-bit
   compat-режим: привет, мусор на экране (у меня так было, см. README).
4. Убери `swapgs` перед `proc_recover` в `syscall.c` → следующий `run`
   ребутит машину (запись по gs:0 = адресу 0).
5. Поменяй делитель PIT в `timer.c` (1193 → 11931) → `sleep` станет в 10
   раз медленнее, а бенчмарк сисколлов не изменится: он не ждёт таймер.

## 5. Как спрашивать

Любая строка кода объяснима за минуту: называй файл и функцию — расскажу,
зачем она и что случится, если её убрать. Особого внимания стоят:
`proc_run_user` (asm-вставка с iretq), `syscall_entry_msr` и `fat32.c:dir_walk`
— там сосредоточена вся магия.
