# BUSYBOX BRING-UP DOSSIER (season 3, 2026-10-05)

Статус: **static musl busybox 1.36.1 работает в ring 3 QuarkOS.**
`echo`, `uname`, `cat`, `ls`, `wc`, `head`, `tail` и **ash** (`sh -c`)
подтверждены headless-прогоном `tools/qemu_busybox.py` (6/6 PASS),
скриншот — `doc/busybox_ls.png`. Это не порт musl и не порт busybox
в классическом смысле: это *Linux-ABI compat слой ядра* (стратегия из
PORT_BUSYBOX.md §0), и он закрыл ступени M1–M3 лестницы частично:
ELF + argv уже были, добавлены fd/stdio-минимум и getdents/stat.

## 1. Что появилось в ядре

| Файл | Роль |
|------|------|
| `kernel/linux.c` | compat-слой расширен до «stage B»: open/openat, stat/lstat/fstat/newfstatat, getdents64, lseek, close, fcntl, readv/writev, mmap/munmap/mprotect/madvise, brk, uname, getcwd, getrlimit, uid/gid/euid/egid/ppid/pgrp, nanosleep, getrandom, arch_prctl(SET_FS). Всё остальное — честный `-ENOSYS` + trace один раз на номер (`[linux] ENOSYS syscall N`) |
| `kernel/linuxfs.[ch]` | POSIX-fd шим поверх FAT32: `open()` славит файл целиком в per-fd буфер ядра (32 КиБ, ФС read-only), каталог сериализуется в `linux_dirent64` при open → `getdents64` = буферизованное чтение |
| `kernel/elf.c` | staging вынесен из образа ядра в физику 16 МиБ (`STAGING_PHYS`): 2 МиБ под образ busybox при бюджете ядра 256 КиБ |
| `kernel/fat32.[ch]` | `fat_stat()` — публичный stat по полному пути |
| `Makefile` | `fsroot/BIN/busybox` — предусловие `disk.img` |
| `tools/build_busybox.sh` | воспроизводимая сборка гостевого busybox на хосте |
| `tools/qemu_busybox.py` | headless-тест: sendkey-батарея `run /BIN/busybox ...` + line-anchored маркеры (введённая строка не может дать false-PASS) |

Таблица сисколлов stage B (номера x86_64): 0,1,2,3,4,5,6,8,9,10,11,12,
13,14,16,19,20,28,35,39,60,63,72,79,97,102,104,107,108,110,111,131,
158,186,217,218,230,231,257,262,273,302,318.

## 2. Мины bring-up (все воспроизводимы)

1. **Регистр имени файла = выключенный мультиплексор.** busybox
   активирует диспетчеризацию по `argv[1]` только если
   `is_prefixed_with(basename(argv[0]), "busybox")` — сравнение
   case-sensitive. FAT32 short name даёт `BUSYBOX`, argv[0] приходит
   как набрано → `"BUSYBOX: applet not found"`, exit 127, при полностью
   живом argv. Лечится lowercase-именем файла на диске (LFN), т.е. тем
   же, чем на Linux (симлинки/`install -s`). Симптом для будущих портов:
   «бинарь запускается и мгновенно выходит 127».
2. **`mmap`: длина — второй аргумент.** musl зовёт `mmap(addr, len, ...)`:
   len в `rsi`, не в `rdi`. Бамп-аллокатор, получающий len=0, выдаёт
   один и тот же адрес всем аллокациям → «out of memory» у echo/ls/sh
   при живых uname/cat (мелкие аллокации успевают уйти через brk).
3. **staging вне бюджета ядра.** 2 МиБ статики в `kernel/*.c` = образ
   > 256 КиБ = кирпич на stage2. Staging живёт отдельной физической
   страницей региона (16 МиБ), образ ядра остался ~49 КиБ.
4. **`make` молча не кладёт новый файл на диск.** `fsroot/BIN/busybox`
   не был предусловием `disk.img` → образ пересобирался без него,
   «cannot load» при живом файле в fsroot. Предусловия образа — часть
   контракта, а не косметика.
5. **Тест-маркеры обязаны быть line-anchored и не входить в набранную
   строку.** Шелл эхо-печатает ввод в serial; маркер-подстрока
   («QuarkOS», «/HELLO.TXT») матчится на саму команду → зелёный тест
   на мёртвом коде. Сравниваем только новые строки лога после offset.
6. **defconfig busybox ≠ переносимость.** kbd_mode/nandwrite тянут
   `linux/kd.h`, `mtd/mtd-user.h`, которых у musl нет; UAPI-заголовки
   (linux/ asm/ asm-generic/) копируются в musl-префикс, конфигурация
   урезается до bring-up набора (tools/build_busybox.sh).

## 3. Границы текущего слоя (честно)

* ФС read-only: `open()` славит файл, запись вернёт ошибку; `vi`/`cp`
  некуда писать. Ступень M3 (VFS с записью) открыта.
* Нет `fork/execve/wait4` → ash исполняет только встроенные команды
  (`echo`, `pwd`, `cd`...): внешние апплеты требуют fork. Внешний
  `sh -c echo X` упирается в `execve` — это ступень M2.
* fd 0 — cooked-клавиатура с эхом kernel-стороны; termios/ioctl(TCGETS)
  фейковые, поэтому musl-stdio считает консоль tty (линейная буферизация
  не убивает вывод).
* Один процесс: pid/tid/ppid — константы, сигналов нет (rt_sigaction
  возвращает 0 и не доставляет).

## 4. Воспроизведение

```sh
# хост: musl + UAPI + busybox (один раз)
musl:  ./configure --prefix=$M && make && make install
       sh tools/musl-gcc.specs.sh $M/include $M/lib /lib/ld-musl-x86_64.so.1 \
           > $M/musl-gcc.specs      # враппер: gcc -specs $M/musl-gcc.specs
       cp -r /usr/include/linux /usr/include/asm /usr/include/asm-generic \
           $M/include/              # из linux-libc-dev
BUSYBOX_SRC=... MUSL_GCC=$M/bin/musl-gcc tools/build_busybox.sh
make disk.img && python3 tools/qemu_busybox.py     # 6/6 PASS
```

Дальше по лестнице: M2 (fork/execve + адресные пространства) превратит
ash из калькулятора встроенных команд в настоящий шелл; M3 (запись в
FAT32) разблокирует `cp`/`vi` и историю ash на диске.

## 5. Добавлено после первого живого прогона (2026-10-05, вечер)

Живой прогон на столе поймал три «не бага, а семантика» и один баг:

1. `run /bin/busybox cd ..` → «cd: applet not found». **cd — builtin,
   не апплет**: на настоящем Linux `busybox cd` падает так же. Внутри
   ash `cd` работает (понадобились `chdir`(80) + честный `getcwd`(79)
   с cwd в linuxfs и относительными путями).
2. `sh: echo: not found` при живом `pwd`: echo-билтин ash закрыт
   `#if ENABLE_ASH_ECHO`, а allnoconfig его выключил; на хосте ash
   молча уходил во **внешний** апплет через fork+exec (которого в
   госте нет). Включены ASH_ECHO/ASH_PRINTF/ASH_HELP/ASH_CMDCMD/
   FEATURE_SH_MATH/ASH_SLEEP — binary 145 КиБ.
3. `sh -c` в quark-шелле → «unknown command»: добавлен passthrough
   `sh [args]` == `run /bin/busybox sh [args]` (kernel/shell.c).
4. Внешние команды из ash (`ls`, `wc` как команды) всё ещё
   «not found»: это execve/fork = ступень M2, не регрессия.

Батарея `tools/qemu_busybox.py` расширена интерактивной ash-сессией
(printf-билтин, cd+/DOCS+pwd, exit в quark-шелл): **9/9 PASS**.
