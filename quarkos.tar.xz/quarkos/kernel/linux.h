#ifndef LINUX_H
#define LINUX_H

#include "idt.h"

/* Linux x86_64 ABI dispatcher; called from syscall_handler when the
   running task was loaded as an ELF (proc_abi == 1) */
void linux_syscall(regs_t *r);

#endif
