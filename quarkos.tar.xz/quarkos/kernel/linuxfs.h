#ifndef LINUXFS_H
#define LINUXFS_H

#include <stdint.h>

/* POSIX-fd shim over the read-only FAT32 driver (Linux-ABI stage B).
 * fd 0/1/2 stay console/EOF; real files get fd >= 3. */
long lfs_open(const char *path);
long lfs_read(int fd, void *buf, uint64_t count);
long lfs_lseek(int fd, int64_t off, int whence);
long lfs_close(int fd);
long lfs_chdir(const char *path);
long lfs_getcwd(char *buf, uint64_t size);
long lfs_getdents(int fd, void *buf, uint64_t count);
long lfs_fstat(int fd, void *statbuf);
long lfs_stat(const char *path, void *statbuf);

#endif
