#ifndef CONSOLE_H
#define CONSOLE_H

#include <stdint.h>

#define VGA_WIDTH  80
#define VGA_HEIGHT 25

enum vga_color {
    VGA_BLACK = 0, VGA_BLUE, VGA_GREEN, VGA_CYAN,
    VGA_RED, VGA_MAGENTA, VGA_BROWN, VGA_LIGHT_GREY,
    VGA_DARK_GREY, VGA_LIGHT_BLUE, VGA_LIGHT_GREEN, VGA_LIGHT_CYAN,
    VGA_LIGHT_RED, VGA_LIGHT_MAGENTA, VGA_YELLOW, VGA_WHITE
};

void con_init(void);
void con_clear(void);
void con_set_color(uint8_t fg, uint8_t bg);
void con_putc(char c);
void con_puts(const char *s);
void kprintf(const char *fmt, ...);

#endif
