#include <stdarg.h>
#include "console.h"
#include "serial.h"
#include "io.h"
#include "string.h"
#include "fb.h"

#define VGA_MEM ((volatile uint16_t *)0xB8000)

static size_t cx = 0, cy = 0;
static int cols = VGA_WIDTH, rows = VGA_HEIGHT;
static uint8_t color = VGA_LIGHT_GREY | (VGA_BLACK << 4);

static inline uint16_t vga_entry(char c, uint8_t col) {
    return (uint16_t)c | ((uint16_t)col << 8);
}

static void update_cursor(void) {
    if (fb_active()) return;              /* no HW cursor in graphics mode */
    uint16_t pos = (uint16_t)(cy * VGA_WIDTH + cx);
    outb(0x3D4, 0x0F);
    outb(0x3D5, (uint8_t)(pos & 0xFF));
    outb(0x3D4, 0x0E);
    outb(0x3D5, (uint8_t)(pos >> 8));
}

static void cell_write(size_t x, size_t y, char ch, uint8_t col) {
    if (fb_active()) fb_glyph((int)x, (int)y, ch, col & 0xF, col >> 4);
    else VGA_MEM[y * VGA_WIDTH + x] = vga_entry(ch, col);
}

static void scroll(void) {
    if (fb_active()) {
        fb_scroll();
    } else {
        memmove((void *)VGA_MEM, (const void *)(VGA_MEM + VGA_WIDTH),
                (size_t)cols * (rows - 1) * 2);
        for (int i = 0; i < cols; i++)
            VGA_MEM[(rows - 1) * VGA_WIDTH + i] = vga_entry(' ', color);
    }
    cy = (size_t)rows - 1;
}

void con_init(void) {
    if (fb_active()) { cols = fb_cols(); rows = fb_rows(); }
    else { cols = VGA_WIDTH; rows = VGA_HEIGHT; }
    con_clear();
}

void con_clear(void) {
    if (fb_active()) fb_clear(color >> 4);
    else for (size_t i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++)
        VGA_MEM[i] = vga_entry(' ', color);
    cx = cy = 0;
    update_cursor();
}

void con_set_color(uint8_t fg, uint8_t bg) {
    color = fg | (bg << 4);
}

void con_putc(char c) {
    /* mirror everything to COM1 for headless debugging */
    if (c == '\n') serial_putc('\r');
    serial_putc(c);

    switch (c) {
    case '\n':
        cx = 0;
        if (++cy == (size_t)rows) scroll();
        break;
    case '\r':
        cx = 0;
        break;
    case '\b':
        if (cx) cx--;
        else if (cy) { cy--; cx = (size_t)cols - 1; }
        cell_write(cx, cy, ' ', color);
        break;
    case '\t':
        cx = (cx + 8) & ~7u;
        if (cx >= (size_t)cols) { cx = 0; if (++cy == (size_t)rows) scroll(); }
        break;
    default:
        cell_write(cx, cy, c, color);
        if (++cx == (size_t)cols) {
            cx = 0;
            if (++cy == (size_t)rows) scroll();
        }
        break;
    }
    update_cursor();
}

void con_puts(const char *s) {
    while (*s) con_putc(*s++);
}

/* ---- tiny printf -------------------------------------------------- */

static void put_uint(uint64_t v, unsigned base, int width, int zeropad, int upper, int left) {
    char tmp[24];
    int i = 0;
    const char *digits = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    if (v == 0) tmp[i++] = '0';
    while (v) {
        tmp[i++] = digits[v % base];
        v /= base;
    }
    if (left) {
        int n = i;
        while (i) con_putc(tmp[--i]);
        while (n < width) { con_putc(' '); n++; }
        return;
    }
    while (i < width) tmp[i++] = zeropad ? '0' : ' ';
    while (i) con_putc(tmp[--i]);
}

void kprintf(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);

    for (const char *p = fmt; *p; p++) {
        if (*p != '%') { con_putc(*p); continue; }
        p++;

        /* flags */
        int left = 0, zeropad = 0;
        for (; *p == '-' || *p == '0'; p++) {
            if (*p == '-') left = 1;
            else zeropad = 1;
        }
        if (left) zeropad = 0;

        /* width */
        int width = 0;
        while (*p >= '0' && *p <= '9') { width = width * 10 + (*p - '0'); p++; }

        /* length modifier */
        int is_long = 0;
        if (*p == 'l') { is_long = 1; p++; }

        switch (*p) {
        case 's': {
            const char *s = va_arg(ap, const char *);
            if (!s) s = "(null)";
            int len = (int)strlen(s);
            if (!left) while (width > len) { con_putc(' '); width--; }
            con_puts(s);
            while (left && width > len) { con_putc(' '); width--; }
            break;
        }
        case 'd': case 'i': {
            long long v = is_long ? va_arg(ap, long long) : va_arg(ap, int);
            int w = width;
            if (v < 0) { con_putc('-'); v = -v; if (w) w--; }
            put_uint((uint64_t)v, 10, w, zeropad, 0, left);
            break;
        }
        case 'u':
            put_uint(is_long ? va_arg(ap, unsigned long long)
                             : va_arg(ap, unsigned int), 10, width, zeropad, 0, left);
            break;
        case 'x':
            put_uint(is_long ? va_arg(ap, unsigned long long)
                             : va_arg(ap, unsigned int), 16, width, zeropad, 0, left);
            break;
        case 'X':
            put_uint(is_long ? va_arg(ap, unsigned long long)
                             : va_arg(ap, unsigned int), 16, width, zeropad, 1, left);
            break;
        case 'c':
            con_putc((char)va_arg(ap, int));
            break;
        case 'p': {
            uint64_t v = va_arg(ap, uint64_t);
            con_puts("0x");
            put_uint(v, 16, width, zeropad, 0, left);
            break;
        }
        case '%':
            con_putc('%');
            break;
        case 0:
            goto done;
        default:
            con_putc('%');
            con_putc(*p);
            break;
        }
    }
done:
    va_end(ap);
}
