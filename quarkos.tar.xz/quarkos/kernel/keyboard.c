#include "keyboard.h"
#include "timer.h"
#include "console.h"
#include "idt.h"
#include "pic.h"
#include "io.h"
#include <stdint.h>

#define KBD_DATA 0x60
#define KBD_STATUS 0x64

/* US QWERTY, scancode set 1 */
static const char kbd_us[128] = {
    0, 27, '1','2','3','4','5','6','7','8','9','0','-','=','\b',
    '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',
    0, /* left ctrl */
    'a','s','d','f','g','h','j','k','l',';','\'','`',
    0, /* left shift */
    '\\','z','x','c','v','b','n','m',',','.','/',
    0, /* right shift */
    '*',
    0, /* left alt */
    ' ',
    0, /* caps lock */
    0,0,0,0,0,0,0,0,0,0,       /* F1-F10 */
    0, /* num lock */
    0, /* scroll lock */
    0, /* home */
    0, /* up */
    0, /* pgup */
    '-',
    0, /* left */
    0,
    0, /* right */
    '+',
    0, /* end */
    0, /* down */
    0, /* pgdn */
    0, /* ins */
    0, /* del */
    0,0,0,
    0, /* F11 */
    0, /* F12 */
    0
};

static const char kbd_us_shift[128] = {
    0, 27, '!','@','#','$','%','^','&','*','(',')','_','+','\b',
    '\t','Q','W','E','R','T','Y','U','I','O','P','{','}','\n',
    0,
    'A','S','D','F','G','H','J','K','L',':','"','~',
    0,
    '|','Z','X','C','V','B','N','M','<','>','?',
    0, '*', 0, ' ', 0,
    0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,'-',0,0,0,'+',0,0,0,0,0,0,0,0,0,0,0,0
};

#define BUF_SIZE 256
static char kbd_buf[BUF_SIZE];
static volatile int buf_head = 0, buf_tail = 0;

static int shift_l = 0, shift_r = 0, caps = 0;
static int e0_prefix = 0;

void keyboard_push_char(char c);   /* fwd */
static void kbd_push(char c) {
    int next = (buf_head + 1) % BUF_SIZE;
    if (next != buf_tail) {          /* drop on overflow */
        kbd_buf[buf_head] = c;
        buf_head = next;
    }
}

static void keyboard_irq(regs_t *r) {
    (void)r;
    if (!(inb(KBD_STATUS) & 1)) return;
    uint8_t sc = inb(KBD_DATA);

    if (sc == 0xE0) { e0_prefix = 1; return; }
    if (e0_prefix) { e0_prefix = 0; return; }   /* ignore extended keys */

    if (sc & 0x80) {                /* break codes */
        uint8_t m = sc & 0x7F;
        if (m == 0x2A) shift_l = 0;
        if (m == 0x36) shift_r = 0;
        return;
    }

    if (sc == 0x2A) { shift_l = 1; return; }
    if (sc == 0x36) { shift_r = 1; return; }
    if (sc == 0x3A) { caps = !caps; return; }

    char c;
    if (shift_l || shift_r) c = kbd_us_shift[sc];
    else c = kbd_us[sc];

    if (c == 0) return;
    if (caps && c >= 'a' && c <= 'z') c -= 32;
    else if (caps && c >= 'A' && c <= 'Z') c += 32;

    kbd_push(c);
}

static void kbd_wait_idle(void) {
    for (int i = 0; i < 100000 && (inb(KBD_STATUS) & 0x02); i++) { }
}

/* ---- i8042 controller init: real BIOSes often leave the keyboard
   port disabled or IRQ1 masked in the controller command byte;
   QEMU hides this, real hardware does not ---- */
static void i8042_init(void) {
    /* drain any pending data (bounded: floating bus reads 0xFF forever) */
    for (int i = 0; i < 256 && (inb(KBD_STATUS) & 1); i++) (void)inb(KBD_DATA);

    kbd_wait_idle();
    outb(KBD_STATUS, 0xAD);          /* disable keyboard port while configuring */

    kbd_wait_idle();
    outb(KBD_STATUS, 0x20);          /* read controller command byte */
    uint8_t cb = 0xFF;
    for (int i = 0; i < 100000; i++) { if (inb(KBD_STATUS) & 1) { cb = inb(KBD_DATA); break; } }
    cb |=  0x01;                     /* enable IRQ1 */
    cb &= ~0x10;                     /* enable keyboard clock */
    cb |=  0x40;                     /* translate scancode set 2 -> set 1 */

    kbd_wait_idle();
    outb(KBD_STATUS, 0x60);          /* write command byte back */
    kbd_wait_idle();
    outb(KBD_DATA, cb);

    kbd_wait_idle();
    outb(KBD_STATUS, 0xAE);          /* enable keyboard port */

    /* flush whatever woke up during the ceremony (bounded!) */
    for (int i = 0; i < 256 && (inb(KBD_STATUS) & 1); i++) (void)inb(KBD_DATA);
}

void keyboard_push_char(char c) { kbd_push(c); }

void keyboard_init(void) {
    irq_register_handler(1, keyboard_irq);
    i8042_init();
    pic_unmask(1);
    for (int i = 0; i < 256 && (inb(KBD_STATUS) & 1); i++) (void)inb(KBD_DATA);
}

char keyboard_getc(void) {
    extern int usb_kbd_active(void);
    extern void usb_kbd_poll(void);
    extern int usb_kbd_init(void);
    static uint64_t next_rescan;
    static int rescans_left = 12;     /* bounded: no hamster wheels, but hotplug-friendly */
    while (buf_tail == buf_head) {
        if (!usb_kbd_active() && rescans_left > 0 && timer_ms() >= next_rescan) {
            next_rescan = timer_ms() + 2000;   /* hotplug auto-rescan */
            rescans_left--;
            usb_kbd_init();
            continue;
        }
        if (usb_kbd_active()) {
            usb_kbd_poll();                 /* xHCI is polled, not IRQ-driven */
            if (buf_tail != buf_head) break;
            timer_sleep_ms(2);              /* let the timer IRQ breathe */
        } else {
            hlt();                          /* wait for IRQ1 */
        }
    }
    char c = kbd_buf[buf_tail];
    buf_tail = (buf_tail + 1) % BUF_SIZE;
    return c;
}

int keyboard_gets(char *buf, int max) {
    int i = 0;
    for (;;) {
        char c = keyboard_getc();
        if (c == '\n') {
            buf[i] = 0;
            return i;
        }
        if (c == '\b') {
            if (i > 0) {
                i--;
                con_putc('\b');   /* caller must include console for echo */
            }
            continue;
        }
        if (i < max - 1 && c >= 32 && c < 127) {
            buf[i++] = c;
        }
    }
}
