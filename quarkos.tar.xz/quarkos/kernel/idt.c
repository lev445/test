#include "idt.h"
#include "proc.h"
#include "console.h"
#include "io.h"
#include <stdint.h>

typedef struct __attribute__((packed)) {
    uint16_t off_lo;
    uint16_t sel;
    uint8_t  ist;
    uint8_t  attr;
    uint16_t off_mid;
    uint32_t off_hi;
    uint32_t zero;
} idt_entry_t;

static idt_entry_t idt[256];
static struct __attribute__((packed)) {
    uint16_t limit;
    uint64_t base;
} idtr;

static irq_handler_t irq_handlers[16];

/* stubs from isr.asm */
extern void isr0(void);  extern void isr1(void);  extern void isr2(void);
extern void isr3(void);  extern void isr4(void);  extern void isr5(void);
extern void isr6(void);  extern void isr7(void);  extern void isr8(void);
extern void isr9(void);  extern void isr10(void); extern void isr11(void);
extern void isr12(void); extern void isr13(void); extern void isr14(void);
extern void isr15(void); extern void isr16(void); extern void isr17(void);
extern void isr18(void); extern void isr19(void); extern void isr20(void);
extern void isr21(void); extern void isr22(void); extern void isr23(void);
extern void isr24(void); extern void isr25(void); extern void isr26(void);
extern void isr27(void); extern void isr28(void); extern void isr29(void);
extern void isr30(void); extern void isr31(void);
extern void irq0(void);  extern void irq1(void);  extern void irq2(void);
extern void irq3(void);  extern void irq4(void);  extern void irq5(void);
extern void irq6(void);  extern void irq7(void);  extern void irq8(void);
extern void irq9(void);  extern void irq10(void); extern void irq11(void);
extern void irq12(void); extern void irq13(void); extern void irq14(void);
extern void irq15(void);

static void idt_set_gate_attr(int n, uint64_t handler, uint8_t attr) {
    idt[n].off_lo  = (uint16_t)(handler & 0xFFFF);
    idt[n].sel     = 0x08;
    idt[n].ist     = 0;
    idt[n].attr    = attr;   /* e.g. 0x8E kernel gate, 0xEE ring3-callable */
    idt[n].off_mid = (uint16_t)((handler >> 16) & 0xFFFF);
    idt[n].off_hi  = (uint32_t)(handler >> 32);
    idt[n].zero    = 0;
}

static void idt_set_gate(int n, uint64_t handler) {
    idt_set_gate_attr(n, handler, 0x8E);
}

void idt_init(void) {
    idtr.limit = sizeof(idt) - 1;
    idtr.base = (uint64_t)&idt;

    void *stubs[] = {
        isr0, isr1, isr2, isr3, isr4, isr5, isr6, isr7,
        isr8, isr9, isr10, isr11, isr12, isr13, isr14, isr15,
        isr16, isr17, isr18, isr19, isr20, isr21, isr22, isr23,
        isr24, isr25, isr26, isr27, isr28, isr29, isr30, isr31,
        irq0, irq1, irq2, irq3, irq4, irq5, irq6, irq7,
        irq8, irq9, irq10, irq11, irq12, irq13, irq14, irq15,
    };
    for (int i = 0; i < 48; i++)
        idt_set_gate(i, (uint64_t)stubs[i]);

    /* int 0x80: syscall gate callable from ring 3 (DPL=3) */
    extern void syscall_entry(void);
    idt_set_gate_attr(0x80, (uint64_t)syscall_entry, 0xEE);

    asm volatile("lidt %0" :: "m"(idtr));
}

void irq_register_handler(int irq, irq_handler_t fn) {
    if (irq >= 0 && irq < 16) irq_handlers[irq] = fn;
}

static const char *exc_names[32] = {
    "Divide Error", "Debug", "NMI", "Breakpoint", "Overflow",
    "Bound Range", "Invalid Opcode", "Device Not Available",
    "Double Fault", "Coprocessor Segment", "Invalid TSS",
    "Segment Not Present", "Stack Fault", "General Protection",
    "Page Fault", "Reserved", "x87 FP", "Alignment Check",
    "Machine Check", "SIMD FP", "Virtualization", "Control Protection",
    "Reserved", "Reserved", "Reserved", "Reserved", "Reserved",
    "Reserved", "Hypervisor Injection", "VMM Communication",
    "Security Exception", "Reserved"
};

void isr_handler(regs_t *r) {
    if (r->vector < 32) {
        /* exception: was the CPU in user mode? then kill just the task */
        if ((r->cs & 3) == 3) {
            proc_user_fault(r);     /* never returns */
        }
        con_set_color(VGA_WHITE, VGA_RED);
        kprintf("\n*** KERNEL PANIC ***\n");
        kprintf("Exception %d: %s\n", (int)r->vector, exc_names[r->vector]);
        kprintf("err=0x%lx rip=0x%lx rsp=0x%lx cs=0x%lx\n",
                r->err, r->rip, r->rsp, r->cs);
        kprintf("rax=0x%lx rbx=0x%lx rcx=0x%lx rdx=0x%lx\n",
                r->rax, r->rbx, r->rcx, r->rdx);
        con_set_color(VGA_LIGHT_GREY, VGA_BLACK);
        for (;;) hlt();
    }

    int irq = (int)(r->vector - 32);
    if (r->vector < 48 && irq_handlers[irq])
        irq_handlers[irq](r);

    /* EOI */
    if (r->vector >= 40 && r->vector < 48) outb(0xA0, 0x20);   /* slave PIC */
    if (r->vector < 48) outb(0x20, 0x20);                      /* master PIC */
}
