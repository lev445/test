#ifndef FAT32_H
#define FAT32_H

#include <stdint.h>

#define FAT_MAX_NAME 16   /* short name buffer */

typedef struct {
    char     name[FAT_MAX_NAME];  /* "NAME.EXT" style */
    uint8_t  attr;
    uint32_t cluster;
    uint32_t size;
} fat_entry_t;

#define FAT_ATTR_READONLY 0x01
#define FAT_ATTR_HIDDEN   0x02
#define FAT_ATTR_SYSTEM   0x04
#define FAT_ATTR_VOLUME   0x08
#define FAT_ATTR_DIR      0x10
#define FAT_ATTR_ARCHIVE  0x20
#define FAT_ATTR_LFN      0x0F

int  fat_mount(int disk, uint32_t part_lba);
int  fat_is_mounted(void);
const char *fat_label(void);
uint64_t fat_size_kb(void);
uint64_t fat_free_kb(void);

/* directory iteration: returns number of entries printed via callback */
typedef void (*fat_list_cb)(const fat_entry_t *e);
int fat_list_dir(const char *path, fat_list_cb cb);

/* stat by full path: 0 ok, -1 not found */
int fat_stat(const char *path, fat_entry_t *out);

/* read a whole file into buffer; returns bytes read or -1 */
int fat_read_file(const char *path, char *buf, uint32_t max);

/* print file to console; returns 0 on success */
int fat_cat_file(const char *path);

#endif
