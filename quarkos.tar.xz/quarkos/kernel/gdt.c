/* =====================================================================
 *  QuarkOS GDT, 64-bit, with ring-3 segments and a TSS descriptor
 *
 *   0x00  null
 *   0x08  kernel code64   DPL0
 *   0x10  kernel data64   DPL0
 *   0x18  user   DATA64   DPL3   (selector with RPL3: 0x1B)
 *   0x20  user   CODE64   DPL3   (selector with RPL3: 0x23)
 *   0x28  TSS (16-byte system descriptor)
 *
 *  NB: order of the user pair is dictated by SYSRET: it loads
 *      CS = STAR[63:48]+16 and SS = STAR[63:48]+8, so with user base
 *      0x10 the data descriptor must sit at 0x18 and code at 0x20.
 * ===================================================================== */

#include "gdt.h"
#include <stdint.h>

static uint64_t gdt_entries[7];

static struct __attribute__((packed)) {
    uint16_t limit;
    uint64_t base;
} gdt_ptr;

void gdt_set_tss(uint64_t base, uint32_t limit) {
    uint64_t lo =
        ((uint64_t)(limit & 0xFFFF))            |   /* limit 15:0   */
        ((uint64_t)(base & 0xFFFF) << 16)       |   /* base  15:0   */
        ((uint64_t)((base >> 16) & 0xFF) << 32) |   /* base  23:16  */
        (0x89ULL << 40)                         |   /* P | type=9 (64-bit TSS) */
        ((uint64_t)((limit >> 16) & 0xF) << 48) |   /* limit 19:16  */
        ((uint64_t)((base >> 24) & 0xFF) << 56);    /* base  31:24  */
    uint64_t hi = (base >> 32) & 0xFFFFFFFF;        /* base  63:32  */
    gdt_entries[5] = lo;
    gdt_entries[6] = hi;
}

void gdt_init(void) {
    gdt_entries[0] = 0x0000000000000000ULL;   /* null          */
    gdt_entries[1] = 0x00209A0000000000ULL;   /* kernel code64 */
    gdt_entries[2] = 0x0000920000000000ULL;   /* kernel data64 */
    gdt_entries[3] = 0x0000F20000000000ULL;   /* user data64, DPL3 (access 0xF2) */
    gdt_entries[4] = 0x0020FA0000000000ULL;   /* user code64, DPL3 (access 0xFA) */
    gdt_entries[5] = 0;                       /* TSS (filled by tss_init) */
    gdt_entries[6] = 0;

    gdt_ptr.limit = sizeof(gdt_entries) - 1;
    gdt_ptr.base = (uint64_t)&gdt_entries;

    asm volatile(
        "lgdt %0\n\t"
        "mov $0x10, %%ax\n\t"
        "mov %%ax, %%ds\n\t"
        "mov %%ax, %%es\n\t"
        "mov %%ax, %%fs\n\t"
        "mov %%ax, %%gs\n\t"
        "mov %%ax, %%ss\n\t"
        /* far-return into current code to reload CS with 0x08 */
        "pushq $0x08\n\t"
        "lea 1f(%%rip), %%rax\n\t"
        "pushq %%rax\n\t"
        "retfq\n\t"
        "1:\n\t"
        :
        : "m"(gdt_ptr)
        : "rax", "memory"
    );
}
