#ifndef KEYBOARD_H
#define KEYBOARD_H

void keyboard_init(void);
void keyboard_push_char(char c);   /* feed a char into the shell ring (usb/xhci) */
char keyboard_getc(void);                 /* blocking */
int  keyboard_gets(char *buf, int max);   /* blocking line read, returns length */

#endif
