#ifndef TIMER_H
#define TIMER_H

#include <stdint.h>

void timer_init(void);
uint64_t timer_ticks(void);
uint64_t timer_ms(void);
void timer_sleep_ms(uint64_t ms);

#endif
