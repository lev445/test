#include "8259.h"
#include "idt.h"
#include "pic.h"
#include "io.h"

#define PIT_HZ 1000 /* 1 kHz tick */
#define PIT_DIV (1193180 / PIT_HZ)

static volatile uint64_t ticks = 0;

static void timer_irq(regs_t *r) {
    (void)r;
    ticks++;
}

void timer_init(void) {
    irq_register_handler(0, timer_irq);
    outb(0x43, 0x36); /* channel 0, lobyte/hibyte, mode 3 */
    outb(0x40, (uint8_t)(PIT_DIV & 0xFF));
    outb(0x40, (uint8_t)(PIT_DIV >> 8));
    pic_unmask(0);
}

uint64_t timer_ticks(void) { return ticks; }
uint64_t timer_ms(void)    { return ticks; } /* 1 tick = 1 ms */

void timer_sleep_ms(uint64_t ms) {
    uint64_t target = ticks + ms;
    while (ticks < target) hlt(); /* wait for IRQ0 */
}
