; =====================================================================
;  QuarkOS kernel entry (64-bit long mode)
; =====================================================================
BITS 64
section .text

global _start
extern kmain
extern __bss_start
extern __bss_end

_start:
    cli
    mov rsp, stack_top
    xor rbp, rbp
    ; zero .bss properly: real hardware RAM keeps firmware residue,
    ; unlike conveniently-zeroed emulators
    lea rdi, [rel __bss_start]
    lea rcx, [rel __bss_end]
    sub rcx, rdi
    shr rcx, 3
    xor eax, eax
    cld
    rep stosq
    call kmain
.halt:
    cli
    hlt
    jmp .halt

section .bss
align 16
stack_bottom: resb 65536      ; 64 KiB kernel stack
stack_top:

section .note.GNU-stack noalloc noexec write progbits
