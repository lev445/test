/* =====================================================================
 *  QuarkOS FAT32 filesystem driver (read-only)
 *  - BPB parsing, cluster chains, directory walk with LFN support
 *  - paths like "/" , "/DIR" , "/DIR/FILE.TXT"
 * ===================================================================== */

#include "fat32.h"
#include "ata.h"
#include "console.h"
#include "string.h"

#define SECT_SIZE 512
#define MAX_PATH_DEPTH 8

static struct {
    int      mounted;
    int      disk;
    uint32_t part_lba;
    uint16_t bytes_per_sector;
    uint8_t  sectors_per_cluster;
    uint32_t fat_lba;
    uint32_t data_lba;
    uint32_t fat_size;       /* sectors */
    uint32_t root_cluster;
    uint32_t total_clusters;
    char     label[12];
} fs;

static uint8_t sect[SECT_SIZE];

static int read_sect(uint32_t rel, void *buf) {
    return ata_read_sectors(fs.disk, fs.part_lba + rel, 1, buf);
}

int fat_is_mounted(void) { return fs.mounted; }
const char *fat_label(void) { return fs.label; }

uint64_t fat_size_kb(void) {
    return (uint64_t)fs.total_clusters * fs.sectors_per_cluster * (fs.bytes_per_sector / 1024);
}

uint64_t fat_free_kb(void) {
    if (!fs.mounted) return 0;
    /* scan the first FAT and count free (zero) entries */
    uint32_t entries_per_sect = fs.bytes_per_sector / 4;
    uint32_t fat_sects = fs.fat_size;
    uint64_t free_clusters = 0;
    uint32_t total = fs.total_clusters;
    uint32_t seen = 0;

    for (uint32_t s = 0; s < fat_sects && seen < total; s++) {
        if (read_sect(fs.fat_lba + s, sect)) break;
        for (uint32_t i = 0; i < entries_per_sect && seen < total; i++, seen++) {
            uint32_t v = (uint32_t)sect[i*4] | ((uint32_t)sect[i*4+1] << 8) |
                         ((uint32_t)sect[i*4+2] << 16) | ((uint32_t)sect[i*4+3] << 24);
            v &= 0x0FFFFFFF;
            if (v == 0) free_clusters++;
        }
    }
    return free_clusters * fs.sectors_per_cluster * (fs.bytes_per_sector / 1024);
}

/* ---- cluster chain helpers ----------------------------------------- */

static uint32_t cluster_lba(uint32_t cluster) {
    return fs.data_lba + (cluster - 2) * fs.sectors_per_cluster;
}

static uint32_t fat_next_cluster(uint32_t cluster) {
    uint32_t byte_off = cluster * 4;
    uint32_t rel = fs.fat_lba + byte_off / fs.bytes_per_sector;
    uint32_t off = byte_off % fs.bytes_per_sector;
    if (read_sect(rel, sect)) return 0xFFFFFFFF;
    uint32_t val = (uint32_t)sect[off] | ((uint32_t)sect[off+1] << 8) |
                   ((uint32_t)sect[off+2] << 16) | ((uint32_t)sect[off+3] << 24);
    val &= 0x0FFFFFFF;
    if (val >= 0x0FFFFFF8) return 0xFFFFFFFF;   /* end of chain */
    return val;
}

/* ---- mount ---------------------------------------------------------- */

int fat_mount(int disk, uint32_t part_lba) {
    memset(&fs, 0, sizeof(fs));
    fs.disk = disk;
    fs.part_lba = part_lba;

    if (ata_read_sectors(disk, part_lba, 1, sect)) return -1;

    if (sect[510] != 0x55 || sect[511] != 0xAA) return -1;

    uint16_t bps = sect[11] | (sect[12] << 8);
    if (bps != 512) return -1;                  /* only 512 supported */

    fs.bytes_per_sector  = bps;
    fs.sectors_per_cluster = sect[13];
    uint16_t reserved    = sect[14] | (sect[15] << 8);
    uint8_t  nfats       = sect[16];
    fs.fat_size          = sect[36] | (sect[37] << 8) | (sect[38] << 16) | (sect[39] << 24);
    fs.root_cluster      = sect[44] | (sect[45] << 8) | (sect[46] << 16) | (sect[47] << 24);
    uint32_t total_sect  = sect[32] | (sect[33] << 8) | (sect[34] << 16) | (sect[35] << 24);

    if (fs.fat_size == 0 || fs.sectors_per_cluster == 0) return -1;
    if (total_sect == 0) {
        /* big total sectors field (offset 47) */
        total_sect = (uint32_t)sect[47] | ((uint32_t)sect[48] << 8) |
                     ((uint32_t)sect[49] << 16) | ((uint32_t)sect[50] << 24);
    }

    fs.fat_lba  = reserved;                        /* partition-relative */
    fs.data_lba = reserved + nfats * fs.fat_size;  /* partition-relative */
    uint32_t data_sectors = total_sect - (reserved + nfats * fs.fat_size);
    fs.total_clusters = data_sectors / fs.sectors_per_cluster;

    memcpy(fs.label, &sect[43], 11);
    fs.label[11] = 0;
    for (int i = 10; i >= 0 && fs.label[i] == ' '; i--) fs.label[i] = 0;

    /* modern mkfs.vfat writes no BPB label -> read the volume-ID entry
       from the root directory instead */
    if (fs.label[0] == 0) {
        uint32_t root_rel = fs.data_lba + (fs.root_cluster - 2) * fs.sectors_per_cluster;
        if (read_sect(root_rel, sect) == 0) {
            for (int off = 0; off < SECT_SIZE; off += 32) {
                uint8_t *e = &sect[off];
                if (e[0] == 0x00) break;
                if (e[0] == 0xE5) continue;
                if (e[11] == 0x0F) continue;           /* LFN */
                if (e[11] & FAT_ATTR_VOLUME) {
                    memcpy(fs.label, e, 11);
                    fs.label[11] = 0;
                    for (int i = 10; i >= 0 && fs.label[i] == ' '; i--) fs.label[i] = 0;
                    break;
                }
            }
        }
    }
    if (fs.label[0] == 0) strcpy(fs.label, "(none)");

    fs.mounted = 1;
    return 0;
}

/* ---- directory entry decoding --------------------------------------- */

static char lfn[256];
static int  lfn_ready;

static void lfn_reset(void) { lfn[0] = 0; lfn_ready = 0; }

static void lfn_fragment(const uint8_t *e) {
    int seq = e[0] & 0x1F;
    if (e[0] & 0x40) { memset(lfn, 0, sizeof(lfn)); lfn_ready = 1; }
    if (!lfn_ready || seq < 1) return;
    int idx = (seq - 1) * 13;
    if (idx > (int)sizeof(lfn) - 14) idx = (int)sizeof(lfn) - 14;
    static const int offs[13] = {1,3,5,7,9, 14,16,18,20,22,24, 28,30};
    for (int i = 0; i < 13; i++) {
        uint16_t ch = (uint16_t)(e[offs[i]] | (e[offs[i]+1] << 8));
        if (ch == 0x0000 || ch == 0xFFFF) { lfn[idx + i] = 0; return; }
        lfn[idx + i] = (ch < 128) ? (char)ch : '?';
    }
}

static int decode_short_name(const uint8_t *e, char *out) {
    if (lfn_ready && lfn[0]) {
        strncpy(out, lfn, FAT_MAX_NAME - 1);
        out[FAT_MAX_NAME - 1] = 0;
        lfn_reset();
        return 1;
    }
    lfn_reset();
    int i = 0;
    for (int j = 0; j < 8 && e[j] != ' '; j++) out[i++] = (char)e[j];
    if (e[8] != ' ') {
        out[i++] = '.';
        for (int j = 8; j < 11 && e[j] != ' '; j++) out[i++] = (char)e[j];
    }
    out[i] = 0;
    return i > 0;
}

static void make_entry(const uint8_t *e, fat_entry_t *out) {
    decode_short_name(e, out->name);
    out->attr = e[11];
    out->cluster = (uint32_t)(e[26] | (e[27] << 8)) |
                   ((uint32_t)(e[20] | (e[21] << 8)) << 16);
    out->size = (uint32_t)e[28] | ((uint32_t)e[29] << 8) |
                ((uint32_t)e[30] << 16) | ((uint32_t)e[31] << 24);
}

/* iterate entries of a directory cluster chain.
   cb==NULL -> find entry with matching name into *found */
static int dir_walk(uint32_t dir_cluster, fat_list_cb cb,
                    const char *want, fat_entry_t *found) {
    uint32_t cluster = dir_cluster;
    int count = 0;
    lfn_reset();

    while (cluster != 0xFFFFFFFF && cluster >= 2) {
        for (uint8_t s = 0; s < fs.sectors_per_cluster; s++) {
            if (read_sect(cluster_lba(cluster) + s, sect)) return -1;
            for (int off = 0; off < SECT_SIZE; off += 32) {
                uint8_t *e = &sect[off];
                if (e[0] == 0x00) return count;        /* end of dir */
                if (e[0] == 0xE5) { lfn_reset(); continue; }
                if (e[11] == 0x0F) { lfn_fragment(e); continue; }
                if (e[11] & FAT_ATTR_VOLUME) { lfn_reset(); continue; }

                fat_entry_t ent;
                make_entry(e, &ent);
                if (want) {
                    /* case-insensitive compare */
                    int match = 1;
                    const char *a = ent.name, *b = want;
                    while (*a && *b) {
                        if (toupper(*a) != toupper(*b)) { match = 0; break; }
                        a++; b++;
                    }
                    if (*a != *b) match = 0;
                    if (match) { *found = ent; return 1; }
                } else if (cb) {
                    cb(&ent);
                    count++;
                }
                lfn_reset();
            }
        }
        cluster = fat_next_cluster(cluster);
    }
    return count;
}

/* resolve path into a dir cluster; last component optionally matched as entry */
static uint32_t resolve_dir(const char *path, char *last, int lastmax) {
    uint32_t cluster = fs.root_cluster;
    const char *p = path;
    last[0] = 0;

    while (*p == '/') p++;

    char comp[FAT_MAX_NAME];
    for (;;) {
        const char *slash = strchr(p, '/');
        size_t len = slash ? (size_t)(slash - p) : strlen(p);
        if (len == 0) break;
        if (len >= FAT_MAX_NAME) len = FAT_MAX_NAME - 1;
        memcpy(comp, p, len);
        comp[len] = 0;

        if (!slash) {                       /* last component */
            strncpy(last, comp, (size_t)lastmax - 1);
            last[lastmax - 1] = 0;
            return cluster;                 /* parent dir cluster */
        }
        /* intermediate: must be a directory */
        fat_entry_t ent;
        if (dir_walk(cluster, NULL, comp, &ent) <= 0) return 0;
        if (!(ent.attr & FAT_ATTR_DIR)) return 0;
        cluster = ent.cluster;

        p = slash + 1;
        while (*p == '/') p++;
    }
    return cluster;
}

int fat_list_dir(const char *path, fat_list_cb cb) {
    if (!fs.mounted) return -1;
    char last[FAT_MAX_NAME];
    uint32_t cluster = resolve_dir(path ? path : "/", last, sizeof(last));
    if (last[0]) {
        /* path pointed at a subdir itself */
        fat_entry_t ent;
        if (dir_walk(cluster, NULL, last, &ent) <= 0) return -1;
        if (!(ent.attr & FAT_ATTR_DIR)) return -1;
        cluster = ent.cluster;
    }
    if (cluster == 0) return -1;
    return dir_walk(cluster, cb, NULL, NULL);
}

/* find entry by full path */
static int fat_find(const char *path, fat_entry_t *out) {
    char last[FAT_MAX_NAME];
    uint32_t cluster = resolve_dir(path, last, sizeof(last));
    if (cluster == 0 || last[0] == 0) return -1;
    if (dir_walk(cluster, NULL, last, out) <= 0) return -1;
    return 0;
}

int fat_stat(const char *path, fat_entry_t *out) {
    if (!fs.mounted || !out) return -1;
    return fat_find(path, out);
}

int fat_read_file(const char *path, char *buf, uint32_t max) {
    if (!fs.mounted) return -1;
    fat_entry_t ent;
    if (fat_find(path, &ent)) return -1;
    if (ent.attr & FAT_ATTR_DIR) return -1;

    uint32_t to_read = ent.size < max ? ent.size : max;
    uint32_t done = 0;
    uint32_t cluster = ent.cluster;

    while (done < to_read && cluster != 0xFFFFFFFF && cluster >= 2) {
        for (uint8_t s = 0; s < fs.sectors_per_cluster && done < to_read; s++) {
            if (read_sect(cluster_lba(cluster) + s, sect)) return -1;
            uint32_t n = to_read - done;
            if (n > SECT_SIZE) n = SECT_SIZE;
            memcpy(buf + done, sect, n);
            done += n;
        }
        cluster = fat_next_cluster(cluster);
    }
    return (int)done;
}

int fat_cat_file(const char *path) {
    if (!fs.mounted) { kprintf("fat32: not mounted\n"); return -1; }
    fat_entry_t ent;
    if (fat_find(path, &ent)) {
        kprintf("cat: %s: not found\n", path);
        return -1;
    }
    if (ent.attr & FAT_ATTR_DIR) {
        kprintf("cat: %s: is a directory\n", path);
        return -1;
    }
    uint32_t done = 0;
    uint32_t cluster = ent.cluster;
    while (done < ent.size && cluster != 0xFFFFFFFF && cluster >= 2) {
        for (uint8_t s = 0; s < fs.sectors_per_cluster && done < ent.size; s++) {
            if (read_sect(cluster_lba(cluster) + s, sect)) return -1;
            uint32_t n = ent.size - done;
            if (n > SECT_SIZE) n = SECT_SIZE;
            for (uint32_t i = 0; i < n; i++) con_putc(sect[i]);
            done += n;
        }
        cluster = fat_next_cluster(cluster);
    }
    if (ent.size && done) con_putc('\n');
    return 0;
}
