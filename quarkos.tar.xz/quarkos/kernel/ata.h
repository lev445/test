#ifndef ATA_H
#define ATA_H

#include <stdint.h>

#define ATA_MAX_DISKS 4

typedef struct {
    int      present;
    int      channel;        /* 0 = primary, 1 = secondary */
    int      drive;          /* 0 = master, 1 = slave */
    char     model[41];
    char     serial[21];
    char     firmware[9];
    uint64_t sectors28;
    uint64_t sectors48;
    int      lba48;
} ata_disk_t;

extern ata_disk_t ata_disks[ATA_MAX_DISKS];

void ata_init(void);                              /* probes all 4 buses */
int  ata_count(void);
int  ata_read_sectors(int disk, uint64_t lba, uint32_t count, void *buf);
int  ata_write_sectors(int disk, uint64_t lba, uint32_t count, const void *buf);
int  ata_flush(int disk);
uint64_t ata_disk_size(const ata_disk_t *d);    /* sectors */

#endif
