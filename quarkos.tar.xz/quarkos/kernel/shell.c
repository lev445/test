/* =====================================================================
 *  QuarkOS shell
 * ===================================================================== */

#include "shell.h"
#include "console.h"
#include "keyboard.h"
#include "ata.h"
#include "fat32.h"
#include "timer.h"
#include "proc.h"
#include "fb.h"
#include "elf.h"
#include "io.h"
#include "string.h"
#include "fb.h"

#define VERSION "0.1.0"
#define MAXARGS 8
#define LINEBUF 128

extern uint64_t kernel_end;   /* from linker script */

/* ---- helpers -------------------------------------------------------- */

static void print_size(uint64_t kb) {
    if (kb >= 1024 * 1024)
        kprintf("%lu GiB", kb / (1024 * 1024));
    else if (kb >= 1024)
        kprintf("%lu.%lu MiB", kb / 1024, (kb % 1024) * 10 / 1024);
    else
        kprintf("%lu KiB", kb);
}

/* ---- lsblk ----------------------------------------------------------- */

static void list_partitions(int disk_idx) {
    uint8_t mbr[512];
    if (ata_read_sectors(disk_idx, 0, 1, mbr)) return;
    if (mbr[510] != 0x55 || mbr[511] != 0xAA) return;

    for (int i = 0; i < 4; i++) {
        uint8_t *e = &mbr[446 + i * 16];
        uint8_t type = e[4];
        if (type == 0) continue;
        uint32_t start = (uint32_t)e[8] | ((uint32_t)e[9] << 8) |
                         ((uint32_t)e[10] << 16) | ((uint32_t)e[11] << 24);
        uint32_t size = (uint32_t)e[12] | ((uint32_t)e[13] << 8) |
                        ((uint32_t)e[14] << 16) | ((uint32_t)e[15] << 24);
        const char *fsname;
        switch (type) {
        case 0x0B: case 0x0C: case 0x0E: fsname = "fat32"; break;
        case 0x06: case 0x04:            fsname = "fat16"; break;
        case 0x83:                       fsname = "linux"; break;
        case 0x82:                       fsname = "swap";  break;
        default:                         fsname = "unknown"; break;
        }
        kprintf(" `- p%d  part  %-8s start=%-8u ", i + 1, fsname, start);
        print_size((uint64_t)size / 2);
        kprintf("\n");
    }
}

static void cmd_lsblk(void) {
    kprintf("NAME   TYPE  MODEL/SIZE\n");
    int n = 0;
    for (int i = 0; i < ATA_MAX_DISKS; i++) {
        ata_disk_t *d = &ata_disks[i];
        if (!d->present) continue;
        kprintf("ata%d   disk  %-20s ", i, d->model);
        print_size(ata_disk_size(d) / 2);
        kprintf("\n");
        list_partitions(i);
        n++;
    }
    if (n == 0) kprintf("(no ATA disks found)\n");
}

/* ---- ls -------------------------------------------------------------- */

static int ls_total_size;

static void ls_entry(const fat_entry_t *e) {
    if (e->attr & FAT_ATTR_DIR) {
        con_set_color(VGA_LIGHT_BLUE, VGA_BLACK);
        kprintf("dr-xr-xr-x  %-16s <DIR>\n", e->name);
    } else {
        kprintf("-r-xr-xr-x  %-16s %u bytes\n", e->name, e->size);
    }
    con_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    ls_total_size += e->size;
}

static void cmd_ls(const char *path) {
    if (!fat_is_mounted()) {
        kprintf("ls: no FAT32 partition mounted\n");
        return;
    }
    if (!path || !path[0]) path = "/";
    ls_total_size = 0;
    int n = fat_list_dir(path, ls_entry);
    if (n < 0) { kprintf("ls: cannot open '%s'\n", path); return; }
    kprintf("total: %d entries, %d bytes\n", n, ls_total_size);
}

/* ---- other commands --------------------------------------------------- */

static void cmd_help(void) {
    kprintf(
    "QuarkOS shell commands:\n"
    "  help          this text\n"
    "  clear         clear screen\n"
    "  echo <text>   print text\n"
    "  lsblk         list block devices & partitions\n"
    "  ls [path]     list FAT32 directory (default /)\n"
    "  cat <file>    print file contents\n"
    "  run [file]    load flat binary and execute in ring 3\n"
    "\n"
    "  fbtest        draw VBE framebuffer test pattern\n"
    "  fbinfo		 about VESA (VBE) mode.\n"
    "  ver           kernel version info\n"
    "  time          uptime\n"
    "  reboot        reboot machine\n"
    "  shutdown      power off (ACPI)\n");
}

static void cmd_echo(int argc, char **argv) {
    for (int i = 1; i < argc; i++) kprintf("%s%s", argv[i], i + 1 < argc ? " " : "");
    kprintf("\n");
}

static void cmd_ver(void) {
    kprintf("QuarkOS %s (x86_64, long mode)\n", VERSION);
    kprintf("kernel: %p .. %p\n", (void *)0x100000, (void *)&kernel_end);
    kprintf("ata disks: %d, fs: %s\n", ata_count(),
            fat_is_mounted() ? "fat32 mounted" : "none");
}

static void cmd_time(void) {
    uint64_t ms = timer_ms();
    kprintf("uptime: %lus %lums (%lu ticks)\n", ms / 1000, ms % 1000, timer_ticks());
}

static void cmd_reboot(void) {
    kprintf("rebooting...\n");
    uint8_t good = 0x02;
    while ((good & 0x02) == 0) good = inb(0x64);
    outb(0x64, 0xFE);
    for (;;) hlt();
}

/* ---- run: load a flat binary from FAT32 and enter ring 3 ------------- */

static void cmd_run(int argc, char **argv) {
	const char *path = argc > 1 ? argv[1] : "none";
    if (!fat_is_mounted()) {
        kprintf("run: no FAT32 partition mounted\n");
        return;
    }

    int n = fat_read_file(path, (char *)elf_staging(), elf_staging_cap());
    if (n <= 0) {
        kprintf("run: cannot load '%s'\n", path);
        return;
    }
    extern int proc_abi;
    uint64_t entry = USER_BASE, ursp = USER_STACK_TOP;

    if (memcmp(elf_staging(), "\x7f" "ELF", 4) == 0) {
        /* Linux-ABI static ELF: load segments, build argv stack */
        char *pargv[8];
        int pargc = argc - 1;
        if (pargc > 8) pargc = 8;
        for (int i = 0; i < pargc; i++) pargv[i] = argv[1 + i];
        if (pargc < 1) { pargc = 1; pargv[0] = (char *)path; }
        if (elf_load(elf_staging(), (uint32_t)n, pargc, pargv, &entry, &ursp)) {
            kprintf("run: '%s' is not a supported static ELF\n", path);
            return;
        }
        proc_abi = 1;
        kprintf("[proc] %s: ELF64 -> entry 0x%lx, linux ABI, ring 3...\n",
                path, entry);
    } else {
        /* legacy QuarkOS flat binary */
        memset((void *)USER_BASE, 0, USER_MAX_SIZE);
        memcpy((void *)USER_BASE, elf_staging(), (size_t)n);
        proc_abi = 0;
        kprintf("[proc] %s: %d bytes -> 0x%lx, entering ring 3...\n",
                path, n, USER_BASE);
    }
    con_set_color(VGA_LIGHT_MAGENTA, VGA_BLACK);
    int st = proc_run_user(entry, ursp);
    con_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    if (st & 0x100)
        kprintf("[proc] task KILLED by exception %d (protection worked)\n", st & 0xFF);
    else
        kprintf("[proc] task exited with status %d\n", st & 0xFF);
}

/*
static void cmd_usbrescan(void) {
    extern int usb_kbd_init(void);
    kprintf("rescanning xHCI bus...\n");
    if (usb_kbd_init())
        kprintf("[ ok ] USB keyboard attached\n");
    else
        kprintf("[ -- ] still no USB keyboard\n");
}
*/

static void cmd_fbtest(void) {
    if (!fb_active()) { kprintf("fbtest: no VBE framebuffer active\n"); return; }
    fb_test_pattern();
    kprintf("pattern drawn; next output scrolls over it\n");
}

static void cmd_fbinfo(void) {
	char fbs[64];
	fb_info_str(fbs, sizeof fbs);
	kprintf("VESA mode is 'ok', screen size: "); kprintf(fbs); kprintf("\n");
}

static void cmd_shutdown(void) {
    kprintf("shutting down...\n");
    cli();
    outw(0x604, 0x2000);   /* QEMU/Bochs ACPI poweroff */
    outw(0xB004, 0x2000);  /* older QEMU */
    outw(0x4004, 0x3400);  /* VirtualBox */
    for (;;) hlt();
}

/* ---- tokenizer -------------------------------------------------------- */

static int tokenize(char *line, char **argv, int max) {
    int argc = 0;
    char *p = line;
    while (*p && argc < max) {
        while (*p == ' ') p++;
        if (!*p) break;
        argv[argc++] = p;
        while (*p && *p != ' ') p++;
        if (*p) *p++ = 0;
    }
    return argc;
}

/* ---- main loop -------------------------------------------------------- */

void shell_start(void) {
    char line[LINEBUF];
    char *argv[MAXARGS];

    kprintf("\n");
    con_set_color(VGA_LIGHT_GREEN, VGA_BLACK);
    kprintf("QuarkOS %s shell ready. Type 'help'.\n", VERSION);
    con_set_color(VGA_LIGHT_GREY, VGA_BLACK);

    for (;;) {
        con_set_color(VGA_YELLOW, VGA_BLACK);
        kprintf("quark");
        con_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
        kprintf(":~$ ");
        con_set_color(VGA_LIGHT_GREY, VGA_BLACK);

        /* read line with echo */
        int i = 0;
        for (;;) {
            char c = keyboard_getc();
            if (c == '\n') { con_putc('\n'); line[i] = 0; break; }
            if (c == '\b') {
                if (i > 0) { i--; con_putc('\b'); }
                continue;
            }
            if (c >= 32 && c < 127 && i < LINEBUF - 1) {
                line[i++] = c;
                con_putc(c);
            }
        }

        int argc = tokenize(line, argv, MAXARGS);
        if (argc == 0) continue;

        char *cmd = argv[0];
        if (strcmp(cmd, "help") == 0)        cmd_help();
        else if (strcmp(cmd, "clear") == 0)  con_clear();
        else if (strcmp(cmd, "cls") == 0)    con_clear();
        else if (strcmp(cmd, "echo") == 0)   cmd_echo(argc, argv);
        else if (strcmp(cmd, "lsblk") == 0)  cmd_lsblk();
        else if (strcmp(cmd, "ls") == 0)     cmd_ls(argc > 1 ? argv[1] : "/");
        else if (strcmp(cmd, "cat") == 0) {
            if (argc < 2) kprintf("usage: cat <file>\n");
            else fat_cat_file(argv[1]);
        }
        else if (strcmp(cmd, "run") == 0)  cmd_run(argc, argv);
        else if (strcmp(cmd, "fbtest") == 0) cmd_fbtest();
        //else if (strcmp(cmd, "usbrescan") == 0) cmd_usbrescan();
        else if (strcmp(cmd, "ver") == 0)    cmd_ver();
        else if (strcmp(cmd, "time") == 0)   cmd_time();
        else if (strcmp(cmd, "reboot") == 0) cmd_reboot();
        else if (strcmp(cmd, "shutdown") == 0) cmd_shutdown();
        else if (strcmp(cmd, "fbinfo") == 0) cmd_fbinfo();
        else kprintf("unknown command: %s (try 'help')\n", cmd);
    }
}
