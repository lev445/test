#ifndef IO_H
#define IO_H

#include <stdint.h>

static inline uint8_t inb(uint16_t port) {
    uint8_t r;
    asm volatile("inb %1, %0" : "=a"(r) : "Nd"(port));
    return r;
}

static inline void outb(uint16_t port, uint8_t v) {
    asm volatile("outb %0, %1" :: "a"(v), "Nd"(port));
}

static inline uint16_t inw(uint16_t port) {
    uint16_t r;
    asm volatile("inw %1, %0" : "=a"(r) : "Nd"(port));
    return r;
}

static inline void outw(uint16_t port, uint16_t v) {
    asm volatile("outw %0, %1" :: "a"(v), "Nd"(port));
}

static inline void insw(uint16_t port, void *buf, uint32_t count) {
    asm volatile("rep insw"
                 : "+D"(buf), "+c"(count)
                 : "d"(port)
                 : "memory");
}

static inline void outsw(uint16_t port, const void *buf, uint32_t count) {
    asm volatile("rep outsw"
                 : "+S"(buf), "+c"(count)
                 : "d"(port)
                 : "memory");
}

static inline void io_wait(void) {
    /* port 0x80: POST port, safe to poke for tiny delays */
    outb(0x80, 0);
}

static inline void cli(void) { asm volatile("cli"); }
static inline void sti(void) { asm volatile("sti"); }
static inline void hlt(void) { asm volatile("hlt"); }

#endif
