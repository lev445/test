#ifndef FB_H
#define FB_H

#include <stdint.h>

/* VESA/VBE linear framebuffer console (32 bpp) */
int  fb_init(void);              /* reads boot info @ 0x30400 */
int  fb_active(void);
int  fb_cols(void);
int  fb_rows(void);
void fb_glyph(int cx, int cy, char c, uint8_t fg, uint8_t bg);  /* 8x16 cell */
void fb_scroll(void);            /* one 16px text row up */
void fb_clear(uint8_t bg);
void fb_test_pattern(void);      /* shell command `fbtest` */
void fb_info_str(char *buf, int max);

#endif
