#ifndef IDT_H
#define IDT_H

#include <stdint.h>

typedef struct __attribute__((packed)) {
    /* memory order after PUSHALL in isr.asm:
       first push (rax) lands at the HIGHEST address of the group */
    uint64_t r15, r14, r13, r12, r11, r10, r9, r8;
    uint64_t rbp, rdi, rsi, rdx, rcx, rbx, rax;
    uint64_t vector, err;
    uint64_t rip, cs, rflags, rsp, ss;
} regs_t;

typedef void (*irq_handler_t)(regs_t *);

void idt_init(void);
void isr_handler(regs_t *r);          /* called from isr.asm */
void irq_register_handler(int irq, irq_handler_t fn);

#endif
