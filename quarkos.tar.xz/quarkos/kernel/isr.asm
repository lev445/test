; =====================================================================
;  QuarkOS - ISR / IRQ stubs (64-bit)
; =====================================================================
BITS 64
section .text

extern isr_handler

%macro PUSHALL 0
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
%endmacro

%macro POPALL 0
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax
%endmacro

; exception without error code
%macro ISR_NOERR 1
global isr%1
isr%1:
    cli
    push qword 0
    push qword %1
    jmp isr_common
%endmacro

; exception with error code
%macro ISR_ERR 1
global isr%1
isr%1:
    cli
    push qword %1
    jmp isr_common
%endmacro

; hardware IRQ: %1 = irq number, %2 = vector (32 + irq)
%macro IRQ 2
global irq%1
irq%1:
    cli
    push qword 0
    push qword %2
    jmp isr_common
%endmacro

ISR_NOERR 0        ; divide by zero
ISR_NOERR 1        ; debug
ISR_NOERR 2        ; NMI
ISR_NOERR 3        ; breakpoint
ISR_NOERR 4        ; overflow
ISR_NOERR 5        ; bound range
ISR_NOERR 6        ; invalid opcode
ISR_NOERR 7        ; device n/a
ISR_ERR   8        ; double fault
ISR_NOERR 9
ISR_ERR   10       ; invalid TSS
ISR_ERR   11       ; segment not present
ISR_ERR   12       ; stack fault
ISR_ERR   13       ; general protection
ISR_ERR   14       ; page fault
ISR_NOERR 15
ISR_NOERR 16
ISR_ERR   17
ISR_NOERR 18
ISR_NOERR 19
ISR_NOERR 20
ISR_NOERR 21
ISR_NOERR 22
ISR_NOERR 23
ISR_NOERR 24
ISR_NOERR 25
ISR_NOERR 26
ISR_NOERR 27
ISR_NOERR 28
ISR_NOERR 29
ISR_ERR   30
ISR_NOERR 31

IRQ 0,  32         ; PIT timer
IRQ 1,  33         ; keyboard
IRQ 2,  34
IRQ 3,  35
IRQ 4,  36
IRQ 5,  37
IRQ 6,  38
IRQ 7,  39
IRQ 8,  40
IRQ 9,  41
IRQ 10, 42
IRQ 11, 43
IRQ 12, 44
IRQ 13, 45
IRQ 14, 46         ; ATA primary
IRQ 15, 47         ; ATA secondary

isr_common:
    PUSHALL
    mov rdi, rsp        ; regs_t*
    cld
    call isr_handler
    POPALL
    add rsp, 16         ; pop vector + error code
    iretq

; ---- int 0x80 syscall entry (gate with DPL=3, no PIC EOI needed) ----
extern syscall_handler
global syscall_entry
syscall_entry:
    cli
    push qword 0
    push qword 0x80
    PUSHALL
    mov rdi, rsp
    cld
    call syscall_handler
    POPALL
    add rsp, 16
    iretq

; ---- fast syscall entry (IA32_LSTAR target, SYSCALL/SYSRET path) ----
; On entry: rcx = user RIP, r11 = user RFLAGS, rsp = user RSP,
;           rax = syscall number, rdi = arg0.
; We synthesize the same stack frame as the interrupt path so that
; regs_t and syscall_handler stay shared between both entries.
global syscall_entry_msr
syscall_entry_msr:
    swapgs                          ; gs -> proc_percpu
    mov [gs:0], rsp                 ; stash user rsp
    mov rsp, [gs:8]                 ; switch to task kernel stack
    ; ---- synthetic CPU frame (same layout as real interrupt) ----
    push qword 0x1B                 ; SS   (user data | 3)
    push qword [gs:0]               ; RSP  (user stack)
    push r11                        ; RFLAGS (saved by CPU in r11)
    push qword 0x23                 ; CS   (user code | 3)
    push rcx                        ; RIP  (saved by CPU in rcx)
    push qword 0                    ; error code
    push qword 0x80                 ; vector (shared with int 0x80)
    PUSHALL
    mov rdi, rsp
    cld
    call syscall_handler
    POPALL
    add rsp, 16                     ; drop vector + err
    pop rcx                         ; user RIP  -> rcx for SYSRET
    add rsp, 8                      ; skip CS
    pop r11                         ; user RFLAGS -> r11 for SYSRET
    mov rsp, [rsp]                  ; user RSP (discard SS)
    swapgs
    o64 sysret                      ; REX.W SYSRET -> back to 64-bit ring 3

section .note.GNU-stack noalloc noexec write progbits
