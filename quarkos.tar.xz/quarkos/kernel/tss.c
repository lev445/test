/* =====================================================================
 *  QuarkOS TSS (task state segment), 64-bit
 *  Needed so that interrupts arriving while CPL=3 can switch to a
 *  kernel stack (CPU loads RSP0 from the TSS on privilege escalation).
 * ===================================================================== */

#include "tss.h"
#include "string.h"

struct __attribute__((packed)) tss64 {
    uint32_t reserved0;
    uint64_t rsp0;
    uint64_t rsp1;
    uint64_t rsp2;
    uint64_t reserved1;
    uint64_t ist[7];
    uint64_t reserved2;
    uint16_t reserved3;
    uint16_t iopb;      /* I/O map base offset; >= limit => all IO denied */
};

static struct tss64 tss __attribute__((aligned(16)));

/* provided by gdt.c: installs the 16-byte TSS descriptor at selector 0x28 */
void gdt_set_tss(uint64_t base, uint32_t limit);

void tss_init(void) {
    memset(&tss, 0, sizeof(tss));
    /* no I/O bitmap: any IN/OUT from ring 3 will #GP */
    tss.iopb = sizeof(tss);

    gdt_set_tss((uint64_t)&tss, sizeof(tss) - 1);
    asm volatile("ltr %0" :: "r"((uint16_t)0x28));
}

void tss_set_rsp0(uint64_t rsp0) {
    tss.rsp0 = rsp0;
}
