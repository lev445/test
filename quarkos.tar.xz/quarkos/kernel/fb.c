/* =====================================================================
 *  QuarkOS VESA/VBE framebuffer console (32 bpp, linear framebuffer)
 *
 *  stage2 sets the video mode in real mode (int 0x10, VBE 0x4F00-0x4F02)
 *  and leaves a boot info block at physical 0x30400; we just paint.
 * ===================================================================== */

#include "fb.h"
#include "string.h"
#include "console.h"

extern const uint8_t font8x16[256][16];

typedef struct __attribute__((packed)) {
    uint32_t magic;          /* 'VBE1' */
    uint32_t ok;
    uint32_t width, height, bpp, bps;
    uint64_t phys;
    uint8_t  rpos, gpos, bpos;
    uint8_t  rsz, gsz, bsz;
} fbinfo_t;

static fbinfo_t *info = (fbinfo_t *)0x30400;
static uint32_t *fb;
static int active;

/* classic VGA palette, 0xRRGGBB */
static const uint32_t pal[16] = {
    0x000000, 0x0000AA, 0x00AA00, 0x00AAAA,
    0xAA0000, 0xAA00AA, 0xAA5500, 0xAAAAAA,
    0x555555, 0x5555FF, 0x55FF55, 0x55FFFF,
    0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF,
};

int fb_active(void) { return active; }
int fb_cols(void) { return active ? (int)(info->width / 8) : 80; }
int fb_rows(void) { return active ? (int)(info->height / 16) : 25; }

int fb_init(void) {
    if (info->magic != 0x31454256 || !info->ok) return 0;
    if (info->bpp != 32 || !info->phys) return 0;
    fb = (uint32_t *)(uintptr_t)info->phys;
    active = 1;
    return 1;
}

void fb_info_str(char *buf, int max) {
    if (!active) { strcpy(buf, "(no VBE framebuffer)"); return; }
    /* tiny local formatter to avoid include loops */
    char tmp[64];
    int p = 0;
    const char *s = "VBE fb ";
    while (*s && p < max - 1) tmp[p++] = *s++;
    /* width */
    char num[12];
    int n = 0;
    uint32_t v = info->width;
    if (!v) num[n++] = '0';
    while (v) { num[n++] = (char)('0' + v % 10); v /= 10; }
    while (n) tmp[p++] = num[--n];
    tmp[p++] = 'x';
    n = 0; v = info->height;
    if (!v) num[n++] = '0';
    while (v) { num[n++] = (char)('0' + v % 10); v /= 10; }
    while (n) tmp[p++] = num[--n];
    tmp[p++] = 'x';
    n = 0; v = info->bpp;
    if (!v) num[n++] = '0';
    while (v) { num[n++] = (char)('0' + v % 10); v /= 10; }
    while (n) tmp[p++] = num[--n];
    tmp[p] = 0;
    strncpy(buf, tmp, (size_t)max - 1);
    buf[max - 1] = 0;
}

static inline uint32_t pack(uint8_t r, uint8_t g, uint8_t b) {
    uint32_t rv = (uint32_t)r >> (8 - info->rsz);
    uint32_t gv = (uint32_t)g >> (8 - info->gsz);
    uint32_t bv = (uint32_t)b >> (8 - info->bsz);
    return (rv << info->rpos) | (gv << info->gpos) | (bv << info->bpos);
}

static inline void pixel(uint32_t x, uint32_t y, uint32_t c) {
    if (x < info->width && y < info->height)
        fb[y * (info->bps / 4) + x] = c;
}

void fb_glyph(int cx, int cy, char c, uint8_t fg, uint8_t bg) {
    if (!active) return;
    uint32_t fgc = pal[fg & 0xF], bgc = pal[bg & 0xF];
    const uint8_t *g = font8x16[(uint8_t)c];
    uint32_t x0 = (uint32_t)cx * 8, y0 = (uint32_t)cy * 16;
    for (int row = 0; row < 16; row++) {
        uint8_t bits = g[row];
        uint32_t yy = y0 + (uint32_t)row;
        if (yy >= info->height) break;
        uint32_t base = yy * (info->bps / 4) + x0;
        for (int col = 0; col < 8; col++) {
            if (x0 + (uint32_t)col >= info->width) break;
            fb[base + (uint32_t)col] = (bits & (0x80 >> col)) ? fgc : bgc;
        }
    }
}

void fb_scroll(void) {
    if (!active) return;
    uint32_t rowwords = info->bps / 4;
    uint32_t n = (info->height - 16) * rowwords;
    memmove(fb, fb + 16 * rowwords, n * 4);
    uint32_t bgc = pal[VGA_BLACK];
    for (uint32_t y = info->height - 16; y < info->height; y++)
        for (uint32_t x = 0; x < info->width; x++)
            fb[y * rowwords + x] = bgc;
}

void fb_clear(uint8_t bg) {
    if (!active) return;
    uint32_t bgc = pal[bg & 0xF];
    uint32_t total = (info->bps / 4) * info->height;
    for (uint32_t i = 0; i < total; i++) fb[i] = bgc;
}

/* ---- `fbtest`: gradient + circle, proof of direct pixel access ---- */
void fb_test_pattern(void) {
    if (!active) return;
    uint32_t w = info->width, h = info->height;
    for (uint32_t y = 0; y < h; y++) {
        for (uint32_t x = 0; x < w; x++) {
            uint8_t r = (uint8_t)((x * 255) / (w ? w : 1));
            uint8_t g = (uint8_t)((y * 255) / (h ? h : 1));
            uint8_t b = (uint8_t)(((x + y) * 128) / (w + h));
            fb[y * (info->bps / 4) + x] = pack(r, g, b);
        }
    }
    /* circle */
    uint32_t cx = w / 2, cy = h / 2, rad = h / 3;
    for (uint32_t y = cy - rad; y < cy + rad; y++) {
        for (uint32_t x = cx - rad; x < cx + rad; x++) {
            int32_t dx = (int32_t)x - (int32_t)cx;
            int32_t dy = (int32_t)y - (int32_t)cy;
            if (dx * dx + dy * dy <= (int32_t)(rad * rad))
                pixel(x, y, pack(255, 255, 255));
        }
    }
}
