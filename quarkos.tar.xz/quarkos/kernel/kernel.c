/* =====================================================================
 *  QuarkOS kernel main
 * ===================================================================== */

#include <stdint.h>
#include "console.h"
#include "serial.h"
#include "gdt.h"
#include "tss.h"
#include "fb.h"
#include "xhci.h"
#include "syscall.h"
#include "idt.h"
#include "pic.h"
#include "8259.h"
#include "keyboard.h"
#include "ata.h"
#include "fat32.h"
#include "shell.h"
#include "io.h"
#include "string.h"
//#include "ahci.h"

/*
static void banner(void) {
    con_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
    kprintf(
"   ____                    _  __  ____  ____\n"
"  / __ \\__  ______ _____  | |/ / / __ \\/ __/\n"
" / / / / / / / __ `/ ___/ |   / / / / /\\__ \\ \n"
"/ /_/ / /_/ / /_/ / /    /   | / /_/ /___/ / \n"
"\\___\\_\\__,_/\\__,_/_/    /_/|_| \\____//____/  \n");
    con_set_color(VGA_LIGHT_GREY, VGA_BLACK);
}
*/

/* scan MBR of a disk for the first FAT partition, return its LBA (0 if none) */
static uint32_t find_fat_partition(int disk) {
    static uint8_t mbr[512];
    if (ata_read_sectors(disk, 0, 1, mbr)) return 0;
    if (mbr[510] != 0x55 || mbr[511] != 0xAA) return 0;
    for (int i = 0; i < 4; i++) {
        uint8_t *e = &mbr[446 + i * 16];
        uint8_t type = e[4];
        if (type == 0x0B || type == 0x0C || type == 0x0E) {
            return (uint32_t)e[8] | ((uint32_t)e[9] << 8) |
                   ((uint32_t)e[10] << 16) | ((uint32_t)e[11] << 24);
        }
    }
    return 0;
}

void kmain(void) {
    serial_init();
    if (fb_init()) {
        char fbs[64];
        fb_info_str(fbs, sizeof fbs);
        kprintf("[ busy ] starting VESA mode\n");
        serial_puts("[ ok ] "); serial_puts(fbs); serial_puts("\n");
    } else {
        serial_puts("[ -- ] no VBE framebuffer, falling back to text\n");
        kprintf("[ -- ] err, failed while initializing VBE framebuffer\n");
    }
    con_init();

    //banner();
    kprintf("QuarkOS 0.1.0 booting (x86_64)...\n");

    /* core subsystems */
    gdt_init();
    kprintf("[ ok ] GDT reloaded (ring0 + ring3 segments)\n");
    tss_init();
    kprintf("[ ok ] TSS loaded (RSP0 for ring3 -> ring0 switches)\n");
    idt_init();
    kprintf("[ ok ] IDT (256 vectors, int 0x80 = syscall gate DPL3)\n");
    syscall_arch_init();
    kprintf("[ ok ] SYSCALL/SYSRET: STAR/LSTAR/FMASK + EFER.SCE\n");
    pic_init();
    kprintf("[ ok ] PIC remapped (32..47)\n");
    timer_init();
    kprintf("[ ok ] PIT timer @ 1000 Hz\n");
    keyboard_init();
    kprintf("[ ok ] PS/2 keyboard\n");
    if (usb_kbd_init())
        kprintf("[ ok ] USB keyboard via xHCI (boot protocol)\n");
    else
        kprintf("[ -- ] no USB keyboard found (xHCI)\n");
    asm volatile("sti");
    kprintf("[ ok ] interrupts enabled (cli->sti)\n");

    /* block devices */
    ata_init();
    int ndisks = ata_count();
    kprintf("[ ok ] ATA: %d disk(s) detected\n", ndisks);
    for (int i = 0; i < ATA_MAX_DISKS; i++) {
        if (!ata_disks[i].present) continue;
        ata_disk_t *d = &ata_disks[i];
        kprintf("      ata%d: %s (%lu sectors)\n",
                i, d->model, ata_disk_size(d));
    }
    //ahci_init();

    /* filesystem */
    if (ndisks > 0) {
        int mounted = 0;
        for (int i = 0; i < ATA_MAX_DISKS && !mounted; i++) {
            if (!ata_disks[i].present) continue;
            uint32_t lba = find_fat_partition(i);
            if (lba && fat_mount(i, lba) == 0) {
                kprintf("[ ok ] FAT32 mounted on ata%d (label: %s)\n",
                        i, fat_label());
                mounted = 1;
            }
        }
        if (!mounted)
            kprintf("[ -- ] no FAT32 partition found\n");
    }

    shell_start();
    kprintf("[ OK! ] Welcome to QuarkOS. To check news, just type whatnew. (or cat NEWS.TXT)\n");

    kprintf("shell exited, halting\n");
    for (;;) hlt();
}
