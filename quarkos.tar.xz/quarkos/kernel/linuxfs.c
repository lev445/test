/* =====================================================================
 *  QuarkOS POSIX-fd shim over the read-only FAT32 driver (stage B)
 *
 *  bring-up shape, deliberately blunt:
 *   - open() slurps the whole file into a per-fd kernel buffer (the FS
 *     is read-only and the files we serve are docs/applets, so a 32 KiB
 *     cap per open file buys simplicity we can afford);
 *   - open() on a directory serializes linux_dirent64 records once, so
 *     getdents64() degenerates into a buffered read;
 *   - everything is re-validated per call: no locks needed, the kernel
 *     is single-threaded and preemption only happens in the shell.
 * ===================================================================== */

#include "linuxfs.h"
#include "fat32.h"
#include "string.h"

#define LFS_MAXFD   8
#define LFS_FD0     3                 /* first shm-fd number handed out  */
#define LFS_BUFSZ   (32u * 1024u)     /* per-fd slurp cap              */

/* linux errno values we return */
#define ENOENT   2
#define EBADF    9
#define EINVAL  22
#define EISDIR  21
#define ENOTDIR 20
#define ERANGE  34
#define EMFILE  24

#define DT_DIR 4
#define DT_REG 8

typedef struct {
    uint8_t  used;
    uint8_t  is_dir;
    uint32_t pos;                     /* read cursor in buf             */
    uint32_t size;                    /* bytes valid in buf             */
    uint32_t ent_size;                /* true FAT entry size            */
    uint32_t cluster;                 /* st_ino material                */
    uint8_t  buf[LFS_BUFSZ];
} lfs_fd_t;

static lfs_fd_t fds[LFS_MAXFD];

/* process cwd (single process, so a single static cwd is honest) */
static char cwd[64] = "/";

static void path_cat(char *buf, int max, const char *a, const char *b)
{
    int i = 0;
    for (const char *p = a; *p && i < max - 1; i++) buf[i] = *p++;
    for (const char *p = b; *p && i < max - 1; i++) buf[i] = *p++;
    buf[i] = 0;
}

/* absolute-ize a path against cwd into buf */
static const char *full_path(const char *path, char *buf, int max)
{
    if (!path) return 0;
    if (path[0] == '/') {
        strncpy(buf, path, (size_t)max - 1);
        buf[max - 1] = 0;
    } else if (cwd[0] == '/' && cwd[1] == 0) {
        path_cat(buf, max, "/", path);
    } else {
        path_cat(buf, max, cwd, "/");
        path_cat(buf, max, buf, path);
    }
    return buf;
}

long lfs_chdir(const char *path)
{
    char cand[96];
    if (!path) return -ENOENT;
    full_path(path, cand, sizeof(cand));
    size_t l = strlen(cand);
    while (l > 1 && cand[l - 1] == '/') cand[--l] = 0;   /* strip trailing / */
    if (fat_list_dir(cand, (fat_list_cb)0) < 0) return -ENOENT;
    strncpy(cwd, cand, sizeof(cwd) - 1);
    cwd[sizeof(cwd) - 1] = 0;
    return 0;
}

long lfs_getcwd(char *buf, uint64_t size)
{
    size_t l = strlen(cwd) + 1;
    if (!buf || size < l) return -ERANGE;
    memcpy(buf, cwd, l);
    return (long)(l - 1);
}

struct linux_dirent64 {
    uint64_t d_ino;
    int64_t  d_off;
    uint16_t d_reclen;
    uint8_t  d_type;
    char     d_name[0];
};

/* ---- dirent serialization (open() of a directory) ---- */
static struct {
    uint8_t *buf;
    uint32_t cap, pos;
    int64_t  idx;
} dc;

static void dent_emit(const char *name, uint8_t type, uint32_t ino)
{
    uint32_t len = strlen(name);
    uint32_t reclen = (19u + len + 1u + 7u) & ~7u;
    if (dc.pos + reclen > dc.cap) return;      /* full: stop, caller sees short list */
    struct linux_dirent64 *d = (struct linux_dirent64 *)(dc.buf + dc.pos);
    d->d_ino    = ino ? ino : 2;
    d->d_off    = dc.idx + 1;
    d->d_reclen = (uint16_t)reclen;
    d->d_type   = type;
    memcpy(d->d_name, name, len + 1);
    dc.pos += reclen;
    dc.idx++;
}

static void dent_cb(const fat_entry_t *e)
{
    dent_emit(e->name, (e->attr & FAT_ATTR_DIR) ? DT_DIR : DT_REG, e->cluster);
}

/* ---- x86_64 linux struct stat (144 bytes) ---- */
struct kstat {
    uint64_t st_dev, st_ino, st_nlink;
    uint32_t st_mode, st_uid, st_gid;
    uint32_t pad0;
    uint64_t st_rdev, st_size, st_blksize, st_blocks;
    uint64_t atime, atime_nsec, mtime, mtime_nsec, ctime, ctime_nsec;
    uint64_t unused[3];
};

static void fill_stat(struct kstat *st, uint8_t is_dir,
                      uint64_t size, uint64_t ino)
{
    memset(st, 0, sizeof(*st));
    st->st_dev     = 1;
    st->st_ino     = ino ? ino : 2;
    st->st_nlink   = 1;
    st->st_mode    = is_dir ? (0040000u | 0755u) : (0100000u | 0644u);
    st->st_blksize = 512;
    st->st_size    = size;
    st->st_blocks  = (size + 511) / 512;
}

static lfs_fd_t *fd_get(int fd)
{
    if (fd < LFS_FD0 || fd >= LFS_FD0 + LFS_MAXFD) return 0;
    lfs_fd_t *f = &fds[fd - LFS_FD0];
    return f->used ? f : 0;
}

long lfs_open(const char *path)
{
    char full[96];
    if (!path || !fat_is_mounted()) return -ENOENT;
    path = full_path(path, full, sizeof(full));

    int slot = -1;
    for (int i = 0; i < LFS_MAXFD; i++)
        if (!fds[i].used) { slot = i; break; }
    if (slot < 0) return -EMFILE;
    lfs_fd_t *f = &fds[slot];
    memset(f, 0, sizeof(*f));

    /* directory? serialize dents once, at open() */
    dc.buf = f->buf; dc.cap = LFS_BUFSZ; dc.pos = 0; dc.idx = 0;
    dent_emit(".",  DT_DIR, 0);
    dent_emit("..", DT_DIR, 0);
    int n = fat_list_dir(path, dent_cb);
    if (n >= 0) {
        f->used = 1; f->is_dir = 1; f->size = dc.pos;
        f->cluster = 2;
        return LFS_FD0 + slot;
    }

    /* regular file: stat then slurp */
    fat_entry_t ent;
    if (fat_stat(path, &ent)) return -ENOENT;
    if (ent.attr & FAT_ATTR_DIR) return -EISDIR;
    int rd = fat_read_file(path, (char *)f->buf, LFS_BUFSZ);
    if (rd < 0) return -ENOENT;
    f->used = 1; f->size = (uint32_t)rd;
    f->ent_size = ent.size; f->cluster = ent.cluster;
    return LFS_FD0 + slot;
}

long lfs_read(int fd, void *buf, uint64_t count)
{
    lfs_fd_t *f = fd_get(fd);
    if (!f) return -EBADF;
    uint32_t avail = f->size > f->pos ? f->size - f->pos : 0;
    uint32_t n = count < avail ? (uint32_t)count : avail;
    memcpy(buf, f->buf + f->pos, n);
    f->pos += n;
    return (long)n;
}

long lfs_getdents(int fd, void *buf, uint64_t count)
{
    lfs_fd_t *f = fd_get(fd);
    if (!f) return -EBADF;
    if (!f->is_dir) return -ENOTDIR;
    return lfs_read(fd, buf, count);
}

long lfs_lseek(int fd, int64_t off, int whence)
{
    lfs_fd_t *f = fd_get(fd);
    if (!f) return -EBADF;
    uint32_t base;
    if (whence == 0)      base = 0;
    else if (whence == 1) base = f->pos;
    else if (whence == 2) base = f->size;
    else return -EINVAL;
    int64_t np = (int64_t)base + off;
    if (np < 0) return -EINVAL;
    if (np > (int64_t)f->size) np = (int64_t)f->size;
    f->pos = (uint32_t)np;
    return (long)np;
}

long lfs_close(int fd)
{
    lfs_fd_t *f = fd_get(fd);
    if (!f) return -EBADF;
    f->used = 0;
    return 0;
}

long lfs_fstat(int fd, void *statbuf)
{
    lfs_fd_t *f = fd_get(fd);
    if (!f) return -EBADF;
    fill_stat((struct kstat *)statbuf, f->is_dir,
              f->is_dir ? 0 : f->ent_size, f->cluster);
    return 0;
}

long lfs_stat(const char *path, void *statbuf)
{
    char full[96];
    if (!path || !fat_is_mounted()) return -ENOENT;
    path = full_path(path, full, sizeof(full));
    if (fat_list_dir(path, (fat_list_cb)0) >= 0) {   /* directory probe */
        fill_stat((struct kstat *)statbuf, 1, 0, 2);
        return 0;
    }
    fat_entry_t ent;
    if (fat_stat(path, &ent)) return -ENOENT;
    fill_stat((struct kstat *)statbuf, !!(ent.attr & FAT_ATTR_DIR),
              ent.size, ent.cluster);
    return 0;
}
