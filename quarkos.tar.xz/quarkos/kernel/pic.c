#include "pic.h"
#include "io.h"

#define PIC1      0x20
#define PIC2      0xA0
#define PIC1_CMD  PIC1
#define PIC1_DATA (PIC1 + 1)
#define PIC2_CMD  PIC2
#define PIC2_DATA (PIC2 + 1)

#define ICW1_INIT 0x10
#define ICW4_8086 0x01

void pic_init(void) {
    /* cascade init, remap vectors: IRQ0-7 -> 32-39, IRQ8-15 -> 40-47 */
    outb(PIC1_CMD, ICW1_INIT | ICW4_8086);
    io_wait();
    outb(PIC2_CMD, ICW1_INIT | ICW4_8086);
    io_wait();
    outb(PIC1_DATA, 32);
    io_wait();
    outb(PIC2_DATA, 40);
    io_wait();
    outb(PIC1_DATA, 4);      /* slave at IRQ2 */
    io_wait();
    outb(PIC2_DATA, 2);      /* slave cascade identity */
    io_wait();
    outb(PIC1_DATA, ICW4_8086);
    io_wait();
    outb(PIC2_DATA, ICW4_8086);
    io_wait();

    /* mask everything; drivers unmask what they need */
    outb(PIC1_DATA, 0xFF);
    outb(PIC2_DATA, 0xFF);
}

void pic_mask(int irq) {
    uint16_t port = irq < 8 ? PIC1_DATA : PIC2_DATA;
    uint8_t v = inb(port);
    v |= (uint8_t)(1 << (irq & 7));
    outb(port, v);
}

void pic_unmask(int irq) {
    uint16_t port = irq < 8 ? PIC1_DATA : PIC2_DATA;
    uint8_t v = inb(port);
    v &= (uint8_t)~(1 << (irq & 7));
    outb(port, v);
}
