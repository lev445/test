/* =====================================================================
 *  QuarkOS USB keyboard driver over xHCI
 *  Minimal, polled, boot-protocol HID. No interrupts, no hubs, no OTG:
 *  find controller -> reset port -> enable/address slot -> descriptors ->
 *  configure interrupt IN ep -> poll event ring for 8-byte boot reports.
 *
 *  Written for a bet: "если напишешь драйвер на юсб - ты красавчик".
 * ===================================================================== */

#include "xhci.h"
#include "pci.h"
#include "io.h"
#include "console.h"
#include "keyboard.h"
#include "string.h"
#include "timer.h"

typedef struct { uint32_t d[4]; } trb_t;

#define CMD_TRBS   64
#define EVT_TRBS   64
#define KB_TRBS    16
#define MAX_SLOTS  8

/* ---- DMA pools (identity-mapped, below 4G, 64-byte aligned) ---- */
static uint64_t dcbaa[64]              __attribute__((aligned(64)));
static trb_t    cmd_ring[CMD_TRBS]     __attribute__((aligned(64)));
static trb_t    evt_ring[EVT_TRBS]     __attribute__((aligned(64)));
static uint64_t erst[2]                __attribute__((aligned(64))); /* 1 entry, 16B */
static uint8_t  dev_out[MAX_SLOTS + 1][4 * 64] __attribute__((aligned(64)));
static uint8_t  dev_in [MAX_SLOTS + 1][4 * 64] __attribute__((aligned(64)));
static uint8_t  ctrl_buf[256]          __attribute__((aligned(64)));
static trb_t    kb_ring[KB_TRBS]       __attribute__((aligned(64)));
static uint8_t  kb_buf[KB_TRBS][16]    __attribute__((aligned(64)));

static volatile uint8_t *cap, *op, *rt, *db;
static uint32_t stride = 32;
static int      kb_slot = 0, kb_dci = 3, kb_active = 0;
static uint32_t cmd_idx, cmd_cycle = 1, evt_idx, evt_cycle = 1, kb_idx, kb_cycle = 1;
static uint8_t  prev_report[8];
static int      kb_iface;
static int      cmd_timeouts;
static uint64_t reports_seen;

int usb_kbd_active(void) { return kb_active; }

/* ---- register helpers ---- */
static uint32_t opr(uint32_t o)        { return *(volatile uint32_t *)(op + o); }
static void     opw(uint32_t o, uint32_t v) { *(volatile uint32_t *)(op + o) = v; }
static uint32_t rtr(uint32_t o)        { return *(volatile uint32_t *)(rt + o); }
static void     rtw(uint32_t o, uint32_t v) { *(volatile uint32_t *)(rt + o) = v; }
static uint32_t capr(uint32_t o)       { return *(volatile uint32_t *)(cap + o); }
static uint64_t phys(const void *p)    { return (uint64_t)(uintptr_t)p; }

static void delay(volatile int n) { while (n-- > 0) io_wait(); }

/* ---- event ring consumption ---- */
static trb_t *next_event(void) {
    volatile trb_t *e = &evt_ring[evt_idx];
    if ((e->d[3] & 1) != evt_cycle) return 0;
    return (trb_t *)e;
}
static void advance_event(void) {
    evt_idx++;
    if (evt_idx == EVT_TRBS) {              /* wrap AFTER the last slot */
        evt_idx = 0;
        evt_cycle ^= 1;
        kprintf("[dbg] EVT WRAP -> cycle %d\n", evt_cycle);
    }
    rtw(0x38, (uint32_t)phys(&evt_ring[evt_idx]));
    rtw(0x3C, (uint32_t)(phys(&evt_ring[evt_idx]) >> 32));
}

/* wait for a command completion; returns completion code (1 = ok) */
static int wait_cmd(uint64_t cmd_trb_addr, int *slot_out) {
    for (volatile int t = 0; t < 4000000; t++) {
        (void)opr(0x04);              /* vmexit: let the VMM process rings */
        trb_t *e;
        while ((e = next_event())) {
            uint32_t type = (e->d[3] >> 10) & 0x3F;
            kprintf("[dbg] ev t=%u ptr=%lx cc=%u slot=%u ep=%u\n",
                    type,
                    (uint64_t)e->d[0] | ((uint64_t)e->d[1] << 32),
                    (e->d[2] >> 24) & 0xFF, (e->d[3] >> 24) & 0xFF,
                    (e->d[3] >> 16) & 0x1F);
            if (type == 34) {               /* port status change: ack it */
                uint32_t port = (e->d[0] >> 24) & 0xFF;
                if (port) {
                    uint32_t ps = opr(0x400 + (port - 1) * 0x10);
                    opw(0x400 + (port - 1) * 0x10, ps | 0x00020010); /* W1C changes */
                }
            } else if (type == 33 &&
                       (((uint64_t)e->d[0] | ((uint64_t)e->d[1] << 32)) == cmd_trb_addr)) {
                int code = (e->d[2] >> 24) & 0xFF;
                if (slot_out) *slot_out = (e->d[3] >> 24) & 0xFF;
                advance_event();
                return code;
            }
            advance_event();
        }
    }
    cmd_timeouts++;
    return -1;
}

static void ring_cmd(trb_t *t) {
    trb_t *dst = &cmd_ring[cmd_idx];
    t->d[3] |= cmd_cycle;
    *dst = *t;
    cmd_idx++;
    if (cmd_idx == CMD_TRBS - 1) {
        trb_t link = { { (uint32_t)phys(cmd_ring), (uint32_t)(phys(cmd_ring) >> 32),
                         0, (6u << 10) | (1u << 1) | cmd_cycle } };   /* Link, toggle cycle */
        cmd_ring[cmd_idx] = link;
        cmd_idx = 0;
        cmd_cycle ^= 1;
    }
    /* ring host controller doorbell (slot 0) */
    *(volatile uint32_t *)(db + 0) = 0;
}

static int send_cmd_ex(uint32_t d0, uint32_t d1, uint32_t d2, uint32_t type,
                       uint32_t slotid, int *slot_out) {
    trb_t t = { { d0, d1, d2, (type << 10) | (slotid << 24) } };
    uint64_t addr = phys(&cmd_ring[cmd_idx]);
    ring_cmd(&t);
    return wait_cmd(addr, slot_out);
}
static int send_cmd(uint32_t d0, uint32_t d1, uint32_t d2, uint32_t type, int *slot_out) {
    return send_cmd_ex(d0, d1, d2, type, 0, slot_out);
}

/* fire-and-forget: for mass commands whose completions we drain later */
static void send_cmd_nowait(uint32_t d0, uint32_t d1, uint32_t d2,
                            uint32_t type, uint32_t slotid) {
    trb_t t = { { d0, d1, d2, (type << 10) | (slotid << 24) } };
    ring_cmd(&t);
}

/* bounded event drain: never hang on controllers that stay silent */
static void drain_events(int rounds) {
    for (int i = 0; i < rounds; i++) {
        (void)opr(0x04);
        trb_t *e = next_event();
        if (!e) { if (i > 200000) return; continue; }
        uint32_t type = (e->d[3] >> 10) & 0x3F;
        if (type == 34) {
            uint32_t port = (e->d[0] >> 24) & 0xFF;
            if (port) {
                uint32_t ps = opr(0x400 + (port - 1) * 0x10);
                opw(0x400 + (port - 1) * 0x10, ps | 0x00020010);
            }
        }
        advance_event();
    }
}

/* ---- control transfer on ep0 ---- */
static int ep0_transfer(int slot, trb_t *setup, void *data, uint16_t len, int dir_in);

static int control(int slot, uint8_t rt_, uint8_t req, uint16_t val, uint16_t idx,
                   uint16_t len, void *data, int dir_in) {
    uint32_t trt = len ? (dir_in ? 3u : 2u) : 0u;
    trb_t setup = { { (uint32_t)rt_ | ((uint32_t)req << 8) | ((uint32_t)val << 16),
                      (uint32_t)idx | ((uint32_t)len << 16),
                      8u,                                      /* d2: length ONLY */
                      (2u << 10) | (1u << 6) | (trt << 16) } }; /* IDT=bit6, TRT in d3 */
    if (!(rt_ == 0xA1 && req == 0x01))   /* silence the 200 Hz GET_REPORT poll */
        kprintf("[dbg] ctl rt=0x%x req=0x%x val=0x%x len=%u d2=0x%x d3lo=0x%x\n",
                rt_, req, val, len, setup.d[2], setup.d[3] & 0xFFFF);
    return ep0_transfer(slot, &setup, data, len, dir_in);
}

/* ep0 transfer ring (shared, 16 TRBs) */
static trb_t   ep0_ring[KB_TRBS]    __attribute__((aligned(64)));
static uint32_t ep0_idx, ep0_cycle = 1;

static void ring_ep0(int slot, trb_t *t) {
    trb_t *dst = &ep0_ring[ep0_idx];
    t->d[3] |= ep0_cycle;
    *dst = *t;
    ep0_idx++;
    if (ep0_idx == KB_TRBS - 1) {
        trb_t link = { { (uint32_t)phys(ep0_ring), (uint32_t)(phys(ep0_ring) >> 32),
                         0, (6u << 10) | (1u << 1) | ep0_cycle } };
        ep0_ring[ep0_idx] = link;
        ep0_idx = 0;
        ep0_cycle ^= 1;
    }
    *(volatile uint32_t *)(db + slot * 4) = 1;   /* ep0 doorbell */
}

static int wait_transfer(int slot, int dci, uint64_t trb_addr, int *cc_out) {
    for (volatile int t = 0; t < 4000000; t++) {
        (void)opr(0x04);              /* vmexit: let the VMM process rings */
        trb_t *e;
        while ((e = next_event())) {
            uint32_t type = (e->d[3] >> 10) & 0x3F;
            uint32_t eslot = (e->d[3] >> 24) & 0xFF;
            uint32_t eid   = (e->d[3] >> 16) & 0x1F;
            if (type == 34) {
                uint32_t port = (e->d[0] >> 24) & 0xFF;
                if (port) {
                    uint32_t ps = opr(0x400 + (port - 1) * 0x10);
                    opw(0x400 + (port - 1) * 0x10, ps | 0x00020010);
                }
                advance_event();
                continue;
            }
            if (type == 32 && eslot == (uint32_t)slot && eid == (uint32_t)dci) {
                uint64_t p = (uint64_t)e->d[0] | ((uint64_t)e->d[1] << 32);
                int cc = (e->d[2] >> 24) & 0xFF;
                advance_event();
                if (p == trb_addr) { if (cc_out) *cc_out = cc; return 0; }
                continue;
            }
            advance_event();
        }
    }
    kprintf("[dbg] xfer timeout; event ring head:\n");
    for (int i = 0; i < 6; i++)
        kprintf("[dbg]  evt[%d]=%x %x %x %x\n", i, evt_ring[i].d[0],
                evt_ring[i].d[1], evt_ring[i].d[2], evt_ring[i].d[3]);
    return -1;
}

int ep0_transfer(int slot, trb_t *setup, void *data, uint16_t len, int dir_in) {
    uint64_t saddr = phys(&ep0_ring[ep0_idx]);
    ring_ep0(slot, setup);
    if (len) {
        trb_t dt = { { (uint32_t)phys(data), (uint32_t)(phys(data) >> 32),
                       len, (3u << 10) | ((dir_in ? 1u : 0u) << 16) } };
        ring_ep0(slot, &dt);
    }
    trb_t st = { { 0, 0, 0, (4u << 10) | ((dir_in ? 0u : 1u) << 16) | (1u << 5) } };
    uint64_t staddr = phys(&ep0_ring[ep0_idx]);
    ring_ep0(slot, &st);
    (void)saddr;
    int cc = 0;
    if (wait_transfer(slot, 1, staddr, &cc)) return -1;
    return cc == 1 ? 0 : cc;
}

/* ---- HID boot keyboard translation ---- */
static char hid_char(uint8_t usage, int shift) {
    static const char base[] = "`1234567890-=";
    if (usage >= 0x04 && usage <= 0x1D) {
        char c = (char)('a' + usage - 0x04);
        return shift ? (char)(c - 32) : c;
    }
    if (usage >= 0x1E && usage <= 0x27) {
        const char d[] = "1234567890";
        const char s[] = "!@#$%^&*()";
        int i = (usage == 0x27) ? 9 : usage - 0x1E;
        return shift ? s[i] : d[i];
    }
    switch (usage) {
    case 0x28: return '\n';
    case 0x2A: return '\b';
    case 0x2B: return '\t';
    case 0x2C: return ' ';
    case 0x2D: return shift ? '_' : '-';
    case 0x2E: return shift ? '+' : '=';
    case 0x2F: return shift ? '{' : '[';
    case 0x30: return shift ? '}' : ']';
    case 0x31: return shift ? '|' : '\\';
    case 0x33: return shift ? ':' : ';';
    case 0x34: return shift ? '"' : '\'';
    case 0x35: return shift ? '~' : '`';
    case 0x36: return shift ? '<' : ',';
    case 0x37: return shift ? '>' : '.';
    case 0x38: return shift ? '?' : '/';
    default: (void)base; return 0;
    }
}

static void kb_handle_report(const uint8_t *r) {
    int shift = (r[0] & 0x22) != 0;
    for (int i = 2; i < 8; i++) {
        uint8_t k = r[i];
        if (!k) continue;
        int was = 0;
        for (int j = 2; j < 8; j++) if (prev_report[j] == k) was = 1;
        if (was) continue;
        char c = hid_char(k, shift);
        if (c) keyboard_push_char(c);
    }
    memcpy(prev_report, r, 8);
}

/* re-arm the event ring from scratch when half full and idle:
   sidesteps producer/consumer wrap desync once and for all */
static void evt_ring_refresh_if_half(void) {
    if (evt_idx < EVT_TRBS / 2) return;
    if (next_event()) return;                 /* pending events: not idle */
    rtw(0x28, 1);
    rtw(0x30, (uint32_t)phys(erst));
    rtw(0x34, (uint32_t)(phys(erst) >> 32));
    evt_idx = 0; evt_cycle = 1;
    rtw(0x38, (uint32_t)phys(evt_ring));
    rtw(0x3C, (uint32_t)(phys(evt_ring) >> 32));
}

void usb_kbd_poll(void) {
    static uint64_t last_poll;
    if (!kb_active) return;
    evt_ring_refresh_if_half();
    if (timer_ms() - last_poll < 5) return;      /* 200 Hz polling: catches any human keypress */
    last_poll = timer_ms();
    static uint8_t rep[8];
    if (control(kb_slot, 0xA1, 0x01, 0x0200, (uint16_t)kb_iface, 8, rep, 1) == 0)
        kb_handle_report(rep);
    /* re-ring the interrupt-IN doorbell: a no-op when the ring is empty,
       but re-kicks a NAKed retry when the device finally has a report
       (some hosts/emulators never call the endpoint wakeup path) */
    *(volatile uint32_t *)(db + kb_slot * 4) = kb_dci;
    trb_t *e;
    while ((e = next_event())) {
        uint32_t type = (e->d[3] >> 10) & 0x3F;
        if (type == 32 && ((e->d[3] >> 24) & 0xFF) == (uint32_t)kb_slot &&
            ((e->d[3] >> 16) & 0x1F) == (uint32_t)kb_dci) {
            uint64_t p = (uint64_t)e->d[0] | ((uint64_t)e->d[1] << 32);
            int cc = (e->d[2] >> 24) & 0xFF;
            (void)cc;
            if (cc != 1 && cc != 13)
                kprintf("[dbg] kb transfer cc=%d\n", cc);
            advance_event();
            {   /* re-arm unconditionally: a missed re-arm kills input */
                /* which buffer? find by TRB ptr -> buffer index */
                for (int i = 0; i < KB_TRBS - 1; i++) {
                    if (p == phys(&kb_ring[i])) { kb_handle_report(kb_buf[i]); break; }
                }
                reports_seen++;
                /* re-arm: enqueue next normal TRB */
                trb_t nt = { { (uint32_t)phys(kb_buf[kb_idx]),
                               (uint32_t)(phys(kb_buf[kb_idx]) >> 32),
                               8, (1u << 10) | (1u << 5) } };
                trb_t *dst = &kb_ring[kb_idx];
                nt.d[3] |= kb_cycle;
                *dst = nt;
                kb_idx++;
                if (kb_idx == KB_TRBS - 1) {
                    kprintf("[dbg] KB WRAP -> cycle %d\n", kb_cycle ^ 1);
                    trb_t link = { { (uint32_t)phys(kb_ring), (uint32_t)(phys(kb_ring) >> 32),
                                     0, (6u << 10) | (1u << 1) | kb_cycle } };
                    kb_ring[kb_idx] = link;
                    kb_idx = 0;
                    kb_cycle ^= 1;
                }
                *(volatile uint32_t *)(db + kb_slot * 4) = kb_dci;
            }
            continue;
        }
        if (type == 34) {
            uint32_t port = (e->d[0] >> 24) & 0xFF;
            if (port) {
                uint32_t ps = opr(0x400 + (port - 1) * 0x10);
                opw(0x400 + (port - 1) * 0x10, ps | 0x00020010);
            }
        }
        advance_event();
    }
}

/* ---- enumeration ---- */
static uint32_t log2up(uint32_t v) { uint32_t r = 0; while ((1u << r) < v) r++; return r; }

static int enum_port(int port, uint32_t speed) {
    int slot = 0;
    int cc0 = send_cmd(0, 0, 0, 9, &slot);
    kprintf("[dbg] enable slot cc=%d slot=%d\n", cc0, slot);
    kprintf("[dbg] erstsz=0x%x erstba=0x%x erdp=0x%x iman=0x%x\n",
            rtr(0x28), rtr(0x30), rtr(0x38), rtr(0x20));
    kprintf("[dbg] evt0=%x %x %x %x evt1d3=%x cmd0d3=%x\n",
            evt_ring[0].d[0], evt_ring[0].d[1], evt_ring[0].d[2], evt_ring[0].d[3],
            evt_ring[1].d[3], cmd_ring[0].d[3]);
    if (cc0 != 1 || !slot) {
        /* firmware slots may be in the way: clear them, retry once */
        kprintf("[dbg] clearing firmware slots and retrying\n");
        for (uint32_t sl = 1; sl <= 8; sl++)
            send_cmd_ex(0, 0, 0, 10, sl, 0);      /* Disable Slot */
        slot = 0;
        cc0 = send_cmd(0, 0, 0, 9, &slot);
        kprintf("[dbg] enable slot retry cc=%d slot=%d\n", cc0, slot);
        if (cc0 != 1 || !slot) return -1;
    }
    if (slot > MAX_SLOTS) return -1;

    uint8_t *in = dev_in[slot], *out = dev_out[slot];
    memset(in, 0, 4 * stride);
    memset(out, 0, 4 * stride);
    dcbaa[slot] = phys(out);

    /* input control context: add slot + ep0 */
    uint32_t *ic = (uint32_t *)in;
    ic[1] = 0x3;
    /* slot context */
    uint32_t *sl = (uint32_t *)(in + stride);
    sl[0] = (1u << 27) | (speed << 20);
    sl[1] = ((uint32_t)port) << 16;
    /* ep0 context */
    uint32_t *ep = (uint32_t *)(in + 2 * stride);
    uint32_t mps = speed == 4 ? 512 : speed == 3 ? 64 : 8;
    ep[0] = 0;                                 /* interval 0 for control */
    ep[1] = (3u << 1) | (4u << 3) | (mps << 16);   /* CErr, type, MaxPacket */
    ep[2] = (uint32_t)phys(ep0_ring) | 1;      /* TR dequeue + DCS (dw2!) */
    ep[3] = (uint32_t)(phys(ep0_ring) >> 32);  /* dw3 */
    ep[4] = 8;                                 /* avg TRB length (dw4) */

    /* consumer cycle resets to 1 on every Address Device: resync producer */
    memset(ep0_ring, 0, sizeof ep0_ring);
    ep0_idx = 0; ep0_cycle = 1;
    trb_t elink = { { (uint32_t)phys(ep0_ring), (uint32_t)(phys(ep0_ring) >> 32),
                      0, (6u << 10) | (1u << 1) | 1 } };
    ep0_ring[KB_TRBS - 1] = elink;

    int cc = send_cmd_ex((uint32_t)phys(in), (uint32_t)(phys(in) >> 32), 0, 11,
                         (uint32_t)slot, 0);                    /* Address Device */
    kprintf("[dbg] address dev cc=%d\n", cc);
    if (cc == 11 || cc == 5) {          /* slot not enabled / port busy */
        for (uint32_t sl = 1; sl <= 8; sl++)
            send_cmd_ex(0, 0, 0, 10, sl, 0);   /* ALL slots, busy one included */
        slot = 0;
        cc0 = send_cmd(0, 0, 0, 9, &slot);     /* and a brand new slot */
        if (cc0 == 1 && slot) {
            dcbaa[slot] = phys(dev_out[slot]);
            cc = send_cmd_ex((uint32_t)phys(in), (uint32_t)(phys(in) >> 32), 0, 11,
                             (uint32_t)slot, 0);
        }
        kprintf("[dbg] address dev retry cc=%d slot=%d\n", cc, slot);
    }
    if (cc != 1) return -1;

    /* get device descriptor */
    int r0 = control(slot, 0x80, 6, 0x0100, 0, 18, ctrl_buf, 1);
    kprintf("[dbg] getdevdesc r=%d class=%d\n", r0, ctrl_buf[4]);
    if (r0) return -1;
    /* get config descriptor */
    if (control(slot, 0x80, 6, 0x0200, 0, 64, ctrl_buf, 1)) return -1;
    uint16_t total = ctrl_buf[2] | (ctrl_buf[3] << 8);
    if (total > sizeof(ctrl_buf)) total = sizeof(ctrl_buf);
    if (control(slot, 0x80, 6, 0x0200, 0, total, ctrl_buf, 1)) return -1;

    /* scan for HID boot keyboard interface + interrupt IN ep */
    int ep_addr = -1, ep_mps = 0, ep_int = 0, cfg = ctrl_buf[5], iface_no = -1;
    uint32_t off = 9;
    while (off + 2 <= total && ctrl_buf[off]) {
        uint8_t bl = ctrl_buf[off], bt = ctrl_buf[off + 1];
        if (bt == 4 && bl >= 9) {
            if (ctrl_buf[off + 5] == 3 && ctrl_buf[off + 6] == 1 && ctrl_buf[off + 7] == 1) {
                iface_no = ctrl_buf[off + 2];
                kb_iface = ctrl_buf[off + 2];
            }
            else iface_no = -1;
        } else if (bt == 5 && bl >= 7 && iface_no >= 0 && (ctrl_buf[off + 2] & 0x80)) {
            if ((ctrl_buf[off + 3] & 3) == 3) {
                ep_addr = ctrl_buf[off + 2];
                ep_mps = (ctrl_buf[off + 4] | (ctrl_buf[off + 5] << 8)) & 0x7FF;
                ep_int = ctrl_buf[off + 6];
            }
        }
        off += bl;
    }
    kprintf("[dbg] ep_addr=0x%x mps=%d int=%d\n", ep_addr < 0 ? 0 : ep_addr, ep_mps, ep_int);
    if (ep_addr < 0) return -1;               /* not a keyboard */

    /* set configuration */
    if (control(slot, 0x00, 9, cfg, 0, 0, 0, 0)) return -1;
    /* HID: boot protocol, idle 0 (best effort, stalls ignored) */
    if (iface_no >= 0) {
        control(slot, 0x21, 0x0B, 0, (uint16_t)iface_no, 0, 0, 0);
        control(slot, 0x21, 0x0A, 0, (uint16_t)iface_no, 0, 0, 0);
    }

    /* configure endpoint: input ctx with slot+ep0 copied from output + new ep */
    memset(in, 0, 4 * stride);
    memcpy(in + stride, out + stride, stride);          /* slot ctx (updated) */
    memcpy(in + 2 * stride, out + 2 * stride, stride);  /* ep0 ctx */
    ic = (uint32_t *)in;
    int dci = (ep_addr & 0x0F) * 2 + ((ep_addr & 0x80) ? 1 : 0);
    ic[1] = (1u << 0) | (1u << dci);
    uint32_t *sl2 = (uint32_t *)(in + stride);
    sl2[0] = (sl2[0] & ~(0x1Fu << 27)) | ((uint32_t)dci << 27);
    uint32_t *e2 = (uint32_t *)(in + (dci + 1) * stride);  /* spec: ctx i at 32*(i+1) */
    memset(e2, 0, stride);
    uint32_t interval = speed <= 2 ? 3 + log2up((uint32_t)(ep_int ? ep_int : 10))
                                 : (uint32_t)ep_int;
    e2[0] = interval << 16;
    e2[1] = (3u << 1) | (7u << 3) | ((uint32_t)ep_mps << 16);  /* CErr=3, type=7=INTR IN, mps */
    e2[2] = (uint32_t)phys(kb_ring) | 1;           /* TR dequeue + DCS (dw2!) */
    e2[3] = (uint32_t)(phys(kb_ring) >> 32);       /* dw3 */
    e2[4] = 8;                                     /* avg TRB length (dw4) */
    cc = send_cmd_ex((uint32_t)phys(in), (uint32_t)(phys(in) >> 32), 0, 12,
                     (uint32_t)slot, 0);                 /* Configure Endpoint */
    kprintf("[dbg] config ep cc=%d\n", cc);
    if (cc != 1) return -1;

    /* input path: boring & reliable GET_REPORT polling on ep0 instead of
       the interrupt-IN ring (no wrap/cycle/re-arm bugs possible at all) */
    kb_slot = slot; kb_dci = dci;
    memset(prev_report, 0, sizeof prev_report);
    kb_active = 1;
    return 0;
}

/* hard reset and rebuild all rings: needed when the controller kept
   firmware's event ring (old QEMU loads ERST only on HCRST, spec/new
   controllers load it on Run) */
static void xhci_hard_reinit(uint32_t maxports) {
    opw(0x00, opr(0x00) | 2);
    for (int i = 0; i < 200000 && (opr(0x00) & 2); i++) { }
    for (int i = 0; i < 200000 && !(opr(0x04) & 1); i++) { }
    opw(0x38, (maxports > MAX_SLOTS) ? MAX_SLOTS : maxports);
    opw(0x30, (uint32_t)phys(dcbaa));
    opw(0x34, (uint32_t)(phys(dcbaa) >> 32));
    cmd_idx = 0; cmd_cycle = 1;
    trb_t link = { { (uint32_t)phys(cmd_ring), (uint32_t)(phys(cmd_ring) >> 32),
                     0, (6u << 10) | (1u << 1) | 1 } };
    cmd_ring[CMD_TRBS - 1] = link;
    opw(0x18, (uint32_t)phys(cmd_ring) | 1);
    opw(0x1C, (uint32_t)(phys(cmd_ring) >> 32));
    evt_idx = 0; evt_cycle = 1;
    rtw(0x28, 1);
    rtw(0x30, (uint32_t)phys(erst));
    rtw(0x34, (uint32_t)(phys(erst) >> 32));
    rtw(0x38, (uint32_t)phys(evt_ring));
    rtw(0x3C, (uint32_t)(phys(evt_ring) >> 32));
    rtw(0x20, 0);
    opw(0x00, 1);
    for (int i = 0; i < 200000 && (opr(0x04) & 1); i++) { }
    kb_idx = 1; kb_cycle = 1; ep0_idx = 0; ep0_cycle = 1;
    cmd_timeouts = 0;
}

/* ---- init ---- */
int usb_kbd_init(void) {
    uint8_t bus, dev, fn;
    kb_active = 0;                      /* clean slate for rescan */
    if (!pci_find_class(0x0C, 0x03, 0x30, &bus, &dev, &fn)) return 0;

    kprintf("[dbg] xhci pci %d:%d.%d\n", bus, dev, fn);
    uint32_t bar0 = pci_read32(bus, dev, fn, 0x10);
    uint32_t bar1 = pci_read32(bus, dev, fn, 0x14);
    int bar64 = ((bar0 >> 1) & 3) == 2;
    uint64_t base = (bar0 & ~0xFULL);
    if (bar64) base |= (uint64_t)bar1 << 32;
    kprintf("[dbg] bar0=0x%x bar1=0x%x (%s)\n", bar0, bar1,
            bar64 ? "64-bit BAR" : "32-bit BAR");
    int pmstate = pci_pm_force_d0(bus, dev, fn);      /* wake from D3hot */
    kprintf("[dbg] pm: state=%d (3=D3 slept, 0=awake, -1=no PM cap)\n", pmstate);
    uint32_t cmdreg = pci_read32(bus, dev, fn, 0x04);
    pci_write32(bus, dev, fn, 0x04, (cmdreg & ~0x100u) | 0x006);  /* MEM+BM, INTx off */
    uint32_t cmdback = pci_read32(bus, dev, fn, 0x04);
    kprintf("[dbg] pci cmd was=0x%x now=0x%x (bit1 Mem+ must stick)\n",
            cmdreg, cmdback);

    /* map the 2 MiB page containing the BAR uncached (MMIO etiquette) */
    {
        uint64_t *pde = (uint64_t *)(uintptr_t)
            (0x200000ULL + (((base >> 30) & 0x1FF) << 12) + (((base >> 21) & 0x1FF) << 3));
        *pde |= 0x18ULL;                       /* PWT|PCD -> UC */
        uint64_t cr3;
        asm volatile("mov %%cr3, %0" : "=r"(cr3));
        asm volatile("mov %0, %%cr3" :: "r"(cr3));   /* TLB flush */
    }
    delay(50000);                              /* let decode settle */

    cap = (volatile uint8_t *)(uintptr_t)base;
    uint32_t caplen = capr(0) & 0xFF;
    uint32_t caplen2 = capr(0) & 0xFF;
    kprintf("[dbg] caplen read twice: 0x%x / 0x%x\n", caplen, caplen2);
    if (caplen < 0x20 || caplen > 0x40) {
        /* firmware left the >4G bridge window closed for us (Linux reopens
           it during its own enumeration). We are an OS: assign the BAR
           ourselves into a free gap of the LOW mmio hole, which is open:
           VGA/fb prove low window decodes. Candidates from user's lspci. */
        static const uint32_t cand[] = { 0xF0000000u, 0xF4000000u,
                                         0xEC000000u, 0xE8000000u };
        for (unsigned i = 0; i < sizeof cand / sizeof cand[0]; i++) {
            pci_write32(bus, dev, fn, 0x10, cand[i] | 0x4u);  /* 64-bit BAR */
            pci_write32(bus, dev, fn, 0x14, 0);
            base = cand[i];
            cap = (volatile uint8_t *)(uintptr_t)base;
            caplen = capr(0) & 0xFF;
            kprintf("[dbg] BAR relocated to 0x%lx: caplen=0x%x\n",
                    (uint64_t)base, caplen);
            if (caplen >= 0x20 && caplen <= 0x40) break;
        }
        /* re-map the new window uncached */
        {
            uint64_t *pde = (uint64_t *)(uintptr_t)
                (0x200000ULL + (((base >> 30) & 0x1FF) << 12) +
                 (((base >> 21) & 0x1FF) << 3));
            *pde |= 0x18ULL;
            uint64_t cr3;
            asm volatile("mov %%cr3, %0" : "=r"(cr3));
            asm volatile("mov %0, %%cr3" :: "r"(cr3));
        }
    }
    op = cap + caplen;
    uint32_t dboff = capr(0x14) & 0xFFFC;
    uint32_t rtsoff = capr(0x18) & 0xFFFC;
    db = cap + dboff;
    rt = cap + rtsoff;

    uint32_t hcs1 = capr(0x04);
    uint32_t maxports = (hcs1 >> 24) & 0xFF;
    uint32_t hcc1 = capr(0x10);
    stride = (hcc1 & 0x4) ? 64 : 32;

    kprintf("[dbg] base=0x%lx caplen=%u dboff=0x%x rtsoff=0x%x maxports=%u stride=%u\n",
            (uint64_t)base, caplen, dboff, rtsoff, maxports, stride);
    if (caplen < 0x20 || caplen > 0x40)
        kprintf("[dbg] WARN: caplen looks like garbage: MMIO still not decoding?\n");
    /* stop if running; reset only if the spec insists (was running).
       Resetting an already-halted controller drops port connect in some
       implementations (qemu-xhci included) and devices never re-attach. */
    int was_running = opr(0x00) & 1;
    if (was_running) {
        /* firmware left the controller running with devices attached:
           halt and take over its rings; a host reset here would drop
           statically-attached devices in some implementations */
        opw(0x00, opr(0x00) & ~1u);
        for (int i = 0; i < 100000 && !(opr(0x04) & 1); i++) { }
    } else {
        for (int i = 0; i < 100000 && !(opr(0x04) & 1); i++) { }
        opw(0x00, opr(0x00) | 2);            /* cold boot: spec reset */
        for (int i = 0; i < 100000 && (opr(0x00) & 2); i++) { }
        for (int i = 0; i < 100000 && !(opr(0x04) & 1); i++) { }
    }
    kprintf("[dbg] was_running=%d\n", was_running);

    opw(0x38, (maxports > MAX_SLOTS) ? MAX_SLOTS : maxports);   /* CONFIG */
    opw(0x30, (uint32_t)phys(dcbaa));                            /* DCBAAP */
    opw(0x34, (uint32_t)(phys(dcbaa) >> 32));

    /* command ring */
    trb_t link = { { (uint32_t)phys(cmd_ring), (uint32_t)(phys(cmd_ring) >> 32),
                     0, (6u << 10) | (1u << 1) | 1 } };
    cmd_ring[CMD_TRBS - 1] = link;
    cmd_idx = 0; cmd_cycle = 1;
    opw(0x18, (uint32_t)phys(cmd_ring) | 1);                     /* CRCR + RCS */
    opw(0x1C, (uint32_t)(phys(cmd_ring) >> 32));

    /* event ring + interrupter 0 (polled: interrupts off) */
    trb_t elink = { { (uint32_t)phys(evt_ring), (uint32_t)(phys(evt_ring) >> 32),
                      0, (6u << 10) | (1u << 1) | 1 } };
    evt_ring[EVT_TRBS - 1] = elink;
    evt_idx = 0; evt_cycle = 1;
    erst[0] = phys(evt_ring);
    erst[1] = EVT_TRBS;
    rtw(0x28, 1);                                                /* ERSTSZ */
    rtw(0x30, (uint32_t)phys(erst));                             /* ERSTBA */
    rtw(0x34, (uint32_t)(phys(erst) >> 32));
    rtw(0x38, (uint32_t)phys(evt_ring));                         /* ERDP */
    rtw(0x3C, (uint32_t)(phys(evt_ring) >> 32));
    rtw(0x20, 0);                                                /* IMAN: off */

    opw(0x00, 1);                                                /* run */
    for (int i = 0; i < 100000 && (opr(0x04) & 1); i++) { }
    kprintf("[dbg] running sts=0x%x cmd=0x%x config=0x%x dcbaap=0x%x crcr=0x%x\n",
            opr(0x04), opr(0x00), opr(0x38), opr(0x30), opr(0x18));

    /* drop every slot the firmware or our previous session left bound;
       fire-and-forget + bounded drain: silent controllers must not stall us */
    for (uint32_t sl = 1; sl <= 8; sl++)
        send_cmd_nowait(0, 0, 0, 10, sl);
    drain_events(600000);

    for (int attempt = 0; attempt < 2; attempt++) {
    if (attempt == 1) {
        if (!cmd_timeouts) return 0;      /* events flowed: nothing to reinit */
        kprintf("[dbg] commands timed out: hard reset + ring reinit\n");
        xhci_hard_reinit(maxports);
    }
    /* find a connected port, reset, enumerate */
    for (uint32_t p = 1; p <= maxports && p <= 16; p++) {
        uint32_t ps = opr(0x400 + (p - 1) * 0x10);
        if (p <= 4) kprintf("[dbg] port %u ps=0x%x\n", p, ps);
        /* wait for (re)connect: after a host reset devices re-attach async */
        for (int w = 0; w < 300 && !(ps & 1); w++) {
            if (ps & (1u << 17)) {                 /* CSC pending: ack */
                opw(0x400 + (p - 1) * 0x10, ps | (1u << 17));
            }
            delay(2000);
            ps = opr(0x400 + (p - 1) * 0x10);
        }
        if (!(ps & 1)) continue;                                 /* not connected */
        delay(20000);
        ps = opr(0x400 + (p - 1) * 0x10);
        opw(0x400 + (p - 1) * 0x10, (ps & ~0x00020010u) | (1u << 4));  /* reset */
        for (int i = 0; i < 200000 && (opr(0x400 + (p - 1) * 0x10) & (1u << 4)); i++) { }
        ps = opr(0x400 + (p - 1) * 0x10);
        opw(0x400 + (p - 1) * 0x10, ps | (1u << 5));             /* clear PRC */
        ps = opr(0x400 + (p - 1) * 0x10);
        if (!(ps & 2)) continue;                                 /* not enabled */
        uint32_t speed = (ps >> 10) & 0xF;
        if (enum_port((int)p, speed) == 0) {
            kprintf("[ ok ] USB keyboard on port %u (slot %d, ep 0x%x)\n",
                    p, kb_slot, kb_dci);
            return 1;
        }
    }
    }
    return 0;
}
