#ifndef PCI_H
#define PCI_H

#include <stdint.h>

uint32_t pci_read32(uint8_t bus, uint8_t dev, uint8_t fn, uint16_t off);
void     pci_write32(uint8_t bus, uint8_t dev, uint8_t fn, uint16_t off, uint32_t v);

/* scan for class/subclass/progif (e.g. 0x0C/0x03/0x30 = xHCI);
   returns 1 and fills out-params, 0 if not found */
int  pci_pm_force_d0(uint8_t bus, uint8_t dev, uint8_t fn);  /* prev state or -1 */
int pci_find_class(uint8_t cls, uint8_t sub, uint8_t prog,
                   uint8_t *bus, uint8_t *dev, uint8_t *fn);

#endif
