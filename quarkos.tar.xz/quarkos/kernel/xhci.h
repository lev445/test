#ifndef XHCI_H
#define XHCI_H

/* USB keyboard driver over xHCI (boot protocol, polled).
 * Returns 1 if a keyboard was found and attached. */
int  usb_kbd_init(void);
void usb_kbd_poll(void);
int  usb_kbd_active(void);

#endif
