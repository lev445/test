#ifndef SYSCALL_H
#define SYSCALL_H

#include "idt.h"

/* int 0x80 interface (legacy) and SYSCALL/SYSRET interface (fast):
 * rax = number, rdi = arg0, result in rax */
#define SYS_EXIT    0   /* rdi = status            */
#define SYS_WRITE   1   /* rdi = const char*       */
#define SYS_PUTU    2   /* rdi = unsigned long     */
#define SYS_UPTIME  3   /* returns ms in rax       */
#define SYS_SLEEP   4   /* rdi = milliseconds      */

void syscall_handler(regs_t *r);
void syscall_arch_init(void);

#endif
