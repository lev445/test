/* minimal PCI config-space access via CAM ports 0xCF8/0xCFC */
#include "pci.h"
#include "io.h"

static uint32_t addr(uint8_t bus, uint8_t dev, uint8_t fn, uint16_t off) {
    return 0x80000000u | ((uint32_t)bus << 16) | ((uint32_t)(dev & 31) << 11) |
           ((uint32_t)(fn & 7) << 8) | (off & 0xFC);
}

uint32_t pci_read32(uint8_t bus, uint8_t dev, uint8_t fn, uint16_t off) {
    uint32_t a = addr(bus, dev, fn, off);
    uint32_t v;
    /* port > 0xFF must go through DX (exactly %dx, not %edx):
       give the port a 16-bit type so gcc cannot pick anything else.
       cli/sti: an SMI (legacy-USB emulation) between the two port ops
       would otherwise reuse 0xCF8 for its own access and corrupt us */
    uint16_t pa = 0xCF8, pd = 0xCFC;
    asm volatile("cli");
    asm volatile("outl %0, %1" :: "a"(a), "d"(pa));
    asm volatile("inl %1, %0" : "=a"(v) : "d"(pd));
    asm volatile("sti");
    return v;
}

void pci_write32(uint8_t bus, uint8_t dev, uint8_t fn, uint16_t off, uint32_t v) {
    uint32_t a = addr(bus, dev, fn, off);
    uint16_t pa = 0xCF8, pd = 0xCFC;
    asm volatile("cli");
    asm volatile("outl %0, %1" :: "a"(a), "d"(pa));
    asm volatile("outl %0, %1" :: "a"(v), "d"(pd));
    asm volatile("sti");
}

/* wake a device parked in D3hot by firmware: MMIO decode is off until D0.
   returns previous power state (0..3), or -1 if no PM capability */
int pci_pm_force_d0(uint8_t bus, uint8_t dev, uint8_t fn) {
    uint16_t status = (uint16_t)(pci_read32(bus, dev, fn, 0x04) >> 16);
    if (!(status & 0x0010)) return -1;              /* no capabilities list */
    uint8_t ptr = (uint8_t)(pci_read32(bus, dev, fn, 0x34) & 0xFC);
    int hops = 0;
    while (ptr && hops++ < 24) {
        uint32_t cap = pci_read32(bus, dev, fn, ptr);
        if ((cap & 0xFF) == 0x01) {                 /* PCI Power Management */
            uint32_t pmcsr = pci_read32(bus, dev, fn, ptr + 4);
            int state = (int)(pmcsr & 0x3);
            pci_write32(bus, dev, fn, ptr + 4, pmcsr & ~0x3u);   /* -> D0 */
            for (volatile int i = 0; i < 300000; i++) { }        /* settle */
            return state;
        }
        ptr = (uint8_t)((cap >> 8) & 0xFC);
    }
    return -1;
}

int pci_find_class(uint8_t cls, uint8_t sub, uint8_t prog,
                   uint8_t *obus, uint8_t *odev, uint8_t *ofn) {
    for (uint16_t bus = 0; bus < 8; bus++)
        for (uint8_t dev = 0; dev < 32; dev++)
            for (uint8_t fn = 0; fn < 8; fn++) {
                uint32_t id = pci_read32(bus, dev, fn, 0);
                if ((id & 0xFFFF) == 0xFFFF || (id & 0xFFFF) == 0) {
                    if (fn == 0) break;          /* no device here at all */
                    continue;
                }
                uint32_t cc = pci_read32(bus, dev, fn, 8);
                if ((cc >> 24) == cls && ((cc >> 16) & 0xFF) == sub &&
                    ((cc >> 8) & 0xFF) == prog) {
                    *obus = bus; *odev = dev; *ofn = fn;
                    return 1;
                }
                if (fn == 0) {
                    uint8_t hdr = (pci_read32(bus, dev, fn, 0x0C) >> 16) & 0xFF;
                    if (!(hdr & 0x80)) break;    /* single-function device */
                }
            }
    return 0;
}
