/* =====================================================================
 *  QuarkOS ELF64 loader (static ET_EXEC, the musl-gcc -static shape)
 *
 *  Deliberately tiny: no dynamic linking, no relocations, no PIE.
 *  Load addresses must fall inside the user window 0x400000-0x800000,
 *  which is exactly where musl-gcc -static -no-pie puts things.
 * ===================================================================== */

#include "elf.h"
#include "proc.h"
#include "string.h"

#define STAGING_CAP (128u * 1024u)      /* stage-1 size cap; a streaming
                                           loader is a next-project job */
#define STACK_STRINGS 0x5FF000ULL       /* argv strings live here */
#define MMAP_BASE     0x780000ULL       /* mmap bump region top of window */
#define MMAP_LIMIT    0x800000ULL
#define BRK_SPAN      0x400000ULL       /* 4 MiB of brk headroom */

static uint8_t staging[STAGING_CAP];

void    *elf_staging(void)     { return staging; }
uint32_t elf_staging_cap(void) { return STAGING_CAP; }

typedef struct __attribute__((packed)) {
    uint8_t  ident[16];
    uint16_t type, machine;
    uint32_t version;
    uint64_t entry, phoff, shoff;
    uint32_t flags;
    uint16_t ehsize, phentsize, phnum, shentsize, shnum, shstrndx;
} Elf64_Ehdr;

typedef struct __attribute__((packed)) {
    uint32_t type, flags;
    uint64_t offset, vaddr, paddr, filesz, memsz, align;
} Elf64_Phdr;

static uint64_t brk_base, brk_cur, mmap_cur;

uint64_t linux_brk(uint64_t addr) {
    if (!brk_base) return 0;
    if (addr == 0) return brk_cur;
    if (addr < brk_base || addr > brk_base + BRK_SPAN) return brk_cur;
    brk_cur = addr;
    return brk_cur;
}

uint64_t linux_mmap(uint64_t len) {
    uint64_t a = mmap_cur;
    mmap_cur += (len + 0xFFF) & ~0xFFFULL;
    if (mmap_cur > MMAP_LIMIT) return (uint64_t)-1;
    return a;
}

int elf_load(const void *img, uint32_t len,
             int argc, char **argv,
             uint64_t *entry, uint64_t *user_rsp) {
    const Elf64_Ehdr *e = img;

    if (len < sizeof(*e) || memcmp(e->ident, "\x7f" "ELF", 4)) return -1;
    if (e->ident[4] != 2 || e->machine != 62)  return -1;   /* 64-bit x86-64 */
    if (e->type != 2) return -1;                            /* ET_EXEC only */
    if (e->phoff == 0 || e->phnum == 0 || e->phentsize < sizeof(Elf64_Phdr))
        return -1;

    /* ---- load PT_LOAD segments ---- */
    uint64_t maxend = 0;
    for (int i = 0; i < e->phnum; i++) {
        const Elf64_Phdr *p =
            (const Elf64_Phdr *)((const uint8_t *)img + e->phoff +
                                 (uint64_t)i * e->phentsize);
        if (p->type != 1) continue;                         /* PT_LOAD */
        if (p->offset + p->filesz > len) return -1;
        if (p->vaddr < USER_BASE || p->vaddr + p->memsz > MMAP_LIMIT)
            return -1;                                      /* outside window */
        memcpy((void *)p->vaddr, (const uint8_t *)img + p->offset, p->filesz);
        if (p->memsz > p->filesz)
            memset((void *)(p->vaddr + p->filesz), 0, p->memsz - p->filesz);
        if (p->vaddr + p->memsz > maxend) maxend = p->vaddr + p->memsz;
    }
    if (!maxend) return -1;

    brk_base = brk_cur = (maxend + 0xFFF) & ~0xFFFULL;
    mmap_cur = MMAP_BASE;

    /* ---- initial user stack: strings, then argv/envp/auxv array ---- */
    uint64_t strp = STACK_STRINGS;
    uint64_t argvp[8];
    int nac = argc < 8 ? argc : 8;
    for (int i = 0; i < nac; i++) {
        size_t l = strlen(argv[i]) + 1;
        strp -= l;
        memcpy((void *)strp, argv[i], l);
        argvp[i] = strp;
    }
    /* array: argc, argv[], NULL, envp NULL, aux: AT_PAGESZ,4096, AT_NULL,0 */
    int words = 1 + nac + 1 + 1 + 4;
    uint64_t *sp = (uint64_t *)((strp - (uint64_t)words * 8) & ~15ULL);
    int w = 0;
    sp[w++] = (uint64_t)nac;
    for (int i = 0; i < nac; i++) sp[w++] = argvp[i];
    sp[w++] = 0;                       /* argv terminator */
    sp[w++] = 0;                       /* envp terminator (no env) */
    sp[w++] = 6;  sp[w++] = 4096;      /* AT_PAGESZ */
    sp[w++] = 0;  sp[w++] = 0;         /* AT_NULL */

    *entry = e->entry;
    *user_rsp = (uint64_t)sp;
    return 0;
}
