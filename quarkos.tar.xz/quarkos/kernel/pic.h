#ifndef PIC_H
#define PIC_H

#include <stdint.h>

void pic_init(void);
void pic_mask(int irq);
void pic_unmask(int irq);

#endif
