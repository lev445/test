#ifndef ELF_H
#define ELF_H

#include <stdint.h>

/* staging area for ELF images read from FAT (before segment copy) */
void    *elf_staging(void);
uint32_t elf_staging_cap(void);

/* load a static ELF64 ET_EXEC image into the user window,
   build the System V initial stack (argc/argv/envp/auxv).
   returns 0 on success, fills *entry and *user_rsp */
int elf_load(const void *img, uint32_t len,
             int argc, char **argv,
             uint64_t *entry, uint64_t *user_rsp);

/* linux-ABI memory helpers (state reset per elf_load) */
uint64_t linux_brk(uint64_t addr);
uint64_t linux_mmap(uint64_t len);

#endif
