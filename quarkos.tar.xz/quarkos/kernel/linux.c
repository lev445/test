/* =====================================================================
 *  QuarkOS Linux x86_64 syscall ABI compat layer (baby edition)
 *
 *  Enough of the Linux syscall table for static musl binaries:
 *  measured with strace on musl 1.2.3 (see doc/PORT_BUSYBOX.md).
 *  Convention: rax = number, args rdi/rsi/rdx/r10/r8/r9,
 *  return value in rax, errors as -errno.
 * ===================================================================== */

#include "linux.h"
#include "proc.h"
#include "elf.h"
#include "console.h"
#include "string.h"

/* linux errno values we use */
#define ENOSYS  38
#define EINVAL  22
#define ENOTTY  25
#define EBADF   9

/* x86_64 linux syscall numbers (include/asm-generic/unistd.h) */
#define L_READ            0
#define L_WRITE           1
#define L_CLOSE           3
#define L_BRK            12
#define L_MMAP            9
#define L_MUNMAP         11
#define L_IOCTL          16
#define L_WRITEV         20
#define L_EXIT           60
#define L_ARCH_PRCTL    158
#define L_SET_TID_ADDR  218
#define L_EXIT_GROUP    231

#define ARCH_SET_FS 0x1002
#define ARCH_GET_FS 0x1003
#define TCGETS      0x5401

struct iovec { uint64_t base; uint64_t len; };

static long fd_write(const char *b, uint64_t n) {
    for (uint64_t i = 0; i < n; i++) con_putc(b[i]);   /* exact length, no NUL */
    return (long)n;
}

void linux_syscall(regs_t *r) {
    long ret;

    switch (r->rax) {
    case L_WRITE:
        ret = fd_write((const char *)r->rsi, r->rdx);
        break;

    case L_WRITEV: {
        const struct iovec *v = (const struct iovec *)r->rsi;
        long total = 0;
        for (uint64_t i = 0; i < r->rdx; i++)
            total += fd_write((const char *)v[i].base, v[i].len);
        ret = total;
        break;
    }

    case L_READ:
        ret = 0;                       /* stage 1: instant EOF; tty read later */
        break;

    case L_CLOSE:
        ret = 0;
        break;

    case L_IOCTL:
        if (r->rsi == TCGETS) {        /* isatty() probe: pretend to be a tty,
                                          otherwise musl stdio goes fully
                                          buffered and nothing shows up */
            memset((void *)r->rdx, 0, 64);
            ret = 0;
        } else {
            ret = -ENOTTY;
        }
        break;

    case L_BRK:
        ret = (long)linux_brk(r->rdi);
        break;

    case L_MMAP:
        ret = (long)linux_mmap(r->rsi);
        break;

    case L_MUNMAP:
        ret = 0;
        break;

    case L_ARCH_PRCTL:
        if (r->rdi == ARCH_SET_FS) {
            asm volatile("wrmsr" :: "c"(0xC0000100u),
                         "a"((uint32_t)r->rsi),
                         "d"((uint32_t)(r->rsi >> 32)));
            ret = 0;
        } else if (r->rdi == ARCH_GET_FS) {
            ret = -EINVAL;
        } else {
            ret = -EINVAL;
        }
        break;

    case L_SET_TID_ADDR:
        ret = 1;                       /* a proud single thread: tid 1 */
        break;

    case L_EXIT:
    case L_EXIT_GROUP:
        proc_recover(r->rdi & 0xFF);
        ret = 0;                       /* not reached */
        break;

    default:
        ret = -ENOSYS;                 /* musl degrades gracefully on these */
        break;
    }

    r->rax = (uint64_t)ret;
}
