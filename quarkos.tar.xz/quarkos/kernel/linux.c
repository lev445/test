/* =====================================================================
 *  QuarkOS Linux x86_64 syscall compatibility layer (bring-up, 2026-10)
 *
 *  Dispatched from syscall_handler() when the running task was loaded
 *  as a static Linux ELF (proc_abi == 1). Argument order follows the
 *  Linux x86_64 ABI: rdi, rsi, rdx, r10, r8, r9 (r10 in place of rcx);
 *  the result goes back in r->rax.
 *
 *  Bring-up scope: what a static musl busybox needs to reach a shell
 *  prompt and run applets read-only (open/fstat/read/getdents/lseek/
 *  brk/mmap/uname/getcwd/... ). Everything else returns -ENOSYS and is
 *  printed once per number so the next increment knows what to add.
 *  Writes still go to the kernel console (con_putc), reads on fd 0
 *  come from the keyboard ring, and exit() abandons the task through
 *  proc_recover() exactly like SYS_EXIT does (swapgs-balanced).
 * ===================================================================== */

#include "linux.h"
#include "idt.h"
#include "proc.h"
#include "console.h"
#include "keyboard.h"
#include "8259.h"
#include "elf.h"
#include "linuxfs.h"
#include "string.h"
#include "io.h"

/* ---- linux errno negatives ---- */
#define EPERM    -1
#define ENOENT   -2
#define EBADF    -9
#define EINVAL   -22
#define ENOTTY   -25
#define ERANGE   -34
#define ENOSYS   -38

/* ---- arch_prctl codes ---- */
#define ARCH_SET_GS 0x1001
#define ARCH_SET_FS 0x1002

#define AT_FDCWD (-100)

struct linux_iovec {
    uint64_t base;
    uint64_t len;
};

/* ---- blocking keyboard read with echo + backspace (cooked-ish) ---- */
static long kbd_read(char *buf, uint64_t count)
{
    uint64_t i = 0;
    while (i < count) {
        sti();
        char c = keyboard_getc();
        cli();
        if (c == '\b' || c == 0x7F) {
            if (i) {
                i--;
                con_putc('\b');
                con_putc(' ');
                con_putc('\b');
            }
            continue;
        }
        con_putc(c);                 /* echo: no tty layer yet */
        buf[i++] = c;
        if (c == '\n')
            break;
    }
    return (long)i;
}

static long do_read(int fd, char *buf, uint64_t count)
{
    if (fd == 0)
        return kbd_read(buf, count);
    if (fd == 1 || fd == 2)
        return EBADF;
    return lfs_read(fd, buf, count);
}

static long do_write(int fd, const char *buf, uint64_t count)
{
    if (fd != 1 && fd != 2)
        return EBADF;                /* stdout/stderr -> console, for now */
    for (uint64_t i = 0; i < count; i++)
        con_putc(buf[i]);
    return (long)count;
}

void linux_syscall(regs_t *r)
{
    long ret = ENOSYS;

    switch (r->rax) {

    /* ---- file descriptors ---- */
    case 0:                          /* read */
        ret = do_read((int)r->rdi, (char *)r->rsi, r->rdx);
        break;
    case 1:                          /* write */
        ret = do_write((int)r->rdi, (const char *)r->rsi, r->rdx);
        break;
    case 2:                          /* open */
        ret = lfs_open((const char *)r->rdi);
        break;
    case 3:                          /* close */
        ret = lfs_close((int)r->rdi);
        break;
    case 4:                          /* stat */
        ret = lfs_stat((const char *)r->rdi, (void *)r->rsi);
        break;
    case 5:                          /* fstat */
        ret = lfs_fstat((int)r->rdi, (void *)r->rsi);
        break;
    case 6:                          /* lstat: no symlinks, same as stat */
        ret = lfs_stat((const char *)r->rdi, (void *)r->rsi);
        break;
    case 8:                          /* lseek */
        ret = lfs_lseek((int)r->rdi, (int64_t)r->rsi, (int)r->rdx);
        break;
    case 19:                         /* readv */
    case 20: {                       /* writev */
        struct linux_iovec *iov = (struct linux_iovec *)r->rsi;
        long total = 0;
        for (uint64_t i = 0; i < r->rdx; i++) {
            long n = (r->rax == 19)
                   ? do_read((int)r->rdi, (char *)iov[i].base, iov[i].len)
                   : do_write((int)r->rdi, (const char *)iov[i].base, iov[i].len);
            if (n < 0) { total = n; break; }
            total += n;
            if ((uint64_t)n < iov[i].len)
                break;               /* short transfer ends the vector */
        }
        ret = total;
        break;
    }
    case 16:                         /* ioctl: no ttys yet */
        ret = ENOTTY;
        break;
    case 72:                         /* fcntl */
        switch (r->rsi) {
        case 0: ret = (long)r->rdi; break;          /* F_DUPFD: identity */
        case 1: ret = 0; break;                     /* F_GETFD */
        case 2: ret = 0; break;                     /* F_SETFD */
        case 3: ret = 0; break;                     /* F_GETFL: O_RDONLY */
        case 4: ret = 0; break;                     /* F_SETFL */
        default: ret = EINVAL; break;
        }
        break;
    case 217:                        /* getdents64 */
        ret = lfs_getdents((int)r->rdi, (void *)r->rsi, r->rdx);
        break;
    case 257:                        /* openat */
        (void)r->rdi;                /* AT_FDCWD or ignored: single tree */
        ret = lfs_open((const char *)r->rsi);
        break;
    case 262:                        /* newfstatat */
        ret = lfs_stat((const char *)r->rsi, (void *)r->rdx);
        break;

    /* ---- process / memory ---- */
    case 12:                         /* brk */
        r->rax = linux_brk(r->rdi);
        return;
    case 9:                          /* mmap(addr, len, prot, flags, ...) */
        r->rax = linux_mmap(r->rsi); /* anonymous bump: len is arg2 */
        return;
    case 10:                         /* mprotect: no page protections yet */
    case 11:                         /* munmap: bump allocator never reclaims */
    case 28:                         /* madvise: nothing to reclaim */
        ret = 0;
        break;
    case 39:                         /* getpid */
    case 186:                        /* gettid */
        ret = 2;                     /* kernel "idle" pid convention */
        break;
    case 60:                         /* exit */
    case 231:                        /* exit_group */
        /* leaving through proc_recover, not the sysret epilogue: undo
           the entry swapgs first, otherwise GS base stays kernel-side */
        asm volatile("swapgs");
        proc_recover(r->rdi & 0xFF);
        /* not reached */
        break;
    case 97: {                       /* getrlimit: everything is unlimited */
        uint64_t *rl = (uint64_t *)r->rsi;
        rl[0] = ~0ull;
        rl[1] = ~0ull;
        ret = 0;
        break;
    }
    case 102:                        /* getuid  */
    case 104:                        /* getgid  */
    case 107:                        /* geteuid */
    case 108:                        /* getegid: single user: root */
        ret = 0;
        break;
    case 110:                        /* getppid */
    case 111:                        /* getpgrp */
        ret = 1;
        break;
    case 63: {                       /* uname */
        char *u = (char *)r->rdi;
        static const char *fields[6] = {
            "QuarkOS", "quark", "0.2.0-xhci",
            "#1 SMP 2026-09-28", "x86_64", "(none)"
        };
        memset(u, 0, 6 * 65);
        for (int i = 0; i < 6; i++)
            memcpy(u + i * 65, fields[i], strlen(fields[i]));
        ret = 0;
        break;
    }
    case 79:                         /* getcwd */
        ret = lfs_getcwd((char *)r->rdi, r->rsi);
        break;
    case 80:                         /* chdir */
        ret = lfs_chdir((const char *)r->rdi);
        break;
    case 158:                        /* arch_prctl: musl TLS needs SET_FS */
        if (r->rdi == ARCH_SET_FS) {
            asm volatile("wrmsr" :: "c"(0xC0000100u),
                         "a"((uint32_t)r->rsi),
                         "d"((uint32_t)(r->rsi >> 32)));
            ret = 0;
        } else if (r->rdi == ARCH_SET_GS) {
            ret = 0;                 /* kernel owns GS (swapgs) */
        } else {
            ret = EINVAL;
        }
        break;
    case 218:                        /* set_tid_address */
        ret = 2;
        break;
    case 273:                        /* set_robust_list */
    case 131:                        /* sigaltstack */
    case 13:                         /* rt_sigaction */
    case 14:                         /* rt_sigprocmask */
        ret = 0;                     /* no signals yet: pretend success */
        break;
    case 35:                         /* nanosleep */
    case 230: {                      /* clock_nanosleep */
        uint64_t *ts = (uint64_t *)r->rdi;
        uint64_t ms = ts[0] * 1000 + ts[1] / 1000000;
        sti();                       /* let the timer IRQ tick */
        timer_sleep_ms(ms);
        cli();
        ret = 0;
        break;
    }
    case 302:                        /* prlimit64 */
        ret = 0;
        break;
    case 318: {                      /* getrandom: jitter, not crypto */
        uint8_t *buf = (uint8_t *)r->rdi;
        for (uint64_t i = 0; i < r->rsi; i++)
            buf[i] = (uint8_t)(timer_ms() + i * 1103515245u);
        ret = (long)r->rsi;
        break;
    }

    default: {
        static uint64_t last_unknown = 0xFFFFFFFF;
        if (r->rax != last_unknown) {
            last_unknown = r->rax;
            kprintf("[linux] ENOSYS syscall %lu (rdi=0x%lx rsi=0x%lx)\n",
                    r->rax, r->rdi, r->rsi);
        }
        ret = ENOSYS;
        break;
    }
    }

    r->rax = (uint64_t)ret;
}
