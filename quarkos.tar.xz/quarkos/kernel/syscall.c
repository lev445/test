/* =====================================================================
 *  QuarkOS syscall dispatcher (int 0x80 from ring 3)
 * ===================================================================== */

#include "syscall.h"
#include "linux.h"
#include "proc.h"
#include "console.h"
#include "8259.h"
#include "serial.h"
#include "io.h"
#include "string.h"

/* ---- MSRs of the fast syscall path ---- */
#define MSR_EFER        0xC0000080
#define MSR_STAR        0xC0000081
#define MSR_LSTAR       0xC0000082
#define MSR_FMASK       0xC0000084
#define MSR_KERNEL_GS   0xC0000102

static inline void wrmsr(uint32_t msr, uint64_t v) {
    asm volatile("wrmsr" :: "c"(msr), "a"((uint32_t)v), "d"((uint32_t)(v >> 32)));
}
static inline uint64_t rdmsr(uint32_t msr) {
    uint32_t lo, hi;
    asm volatile("rdmsr" : "=a"(lo), "=d"(hi) : "c"(msr));
    return (uint64_t)lo | ((uint64_t)hi << 32);
}

extern uint64_t proc_percpu[2];
extern void syscall_entry_msr(void);

void syscall_arch_init(void) {
    /* STAR: [47:32] = kernel selectors base (0x08),
             [63:48] = user selectors base (0x10):
             SYSRET will derive SS = base+8 = 0x18|3, CS = base+16 = 0x20|3 */
    wrmsr(MSR_STAR, (0x10ULL << 48) | (0x08ULL << 32));
    wrmsr(MSR_LSTAR, (uint64_t)syscall_entry_msr);
    wrmsr(MSR_FMASK, 0x200);            /* mask IF while in kernel */
    wrmsr(MSR_EFER, rdmsr(MSR_EFER) | 1);   /* SCE: enable SYSCALL/SYSRET */
    wrmsr(MSR_KERNEL_GS, (uint64_t)proc_percpu);
}

void syscall_handler(regs_t *r) {
    extern int proc_abi;
    if (proc_abi == 1) { linux_syscall(r); return; }
    switch (r->rax) {
    case SYS_EXIT:
        /* we are leaving through proc_recover, not through the
           sysret epilogue: undo the entry swapgs first, otherwise
           GS base stays kernel-side and the next task's swapgs
           will pair it with zero */
        asm volatile("swapgs");
        proc_recover(r->rdi & 0xFF);
        /* not reached */
        break;

    case SYS_WRITE: {
        const char *s = (const char *)r->rdi;   /* identity-mapped */
        con_puts(s);
        r->rax = strlen(s);
        break;
    }

    case SYS_PUTU:
        kprintf("%lu", r->rdi);
        r->rax = 0;
        break;

    case SYS_UPTIME:
        r->rax = timer_ms();
        break;
    case SYS_SLEEP:
        /* we are inside an interrupt gate (IF=0): re-enable so the
           timer IRQ can tick while we wait, then mask again */
        sti();
        timer_sleep_ms(r->rdi);
        cli();
        r->rax = 0;
        break;

    default:
        r->rax = (uint64_t)-1;
        break;
    }
}
