/* =====================================================================
 *  QuarkOS ATA PIO driver
 *  - IDENTIFY probing on primary/secondary, master/slave
 *  - LBA28 / LBA48 sector reads & writes (polled, no IRQ needed)
 * ===================================================================== */

#include "ata.h"
#include "io.h"
#include "console.h"
#include "string.h"

/* register offsets from IO base */
#define ATA_R_DATA      0
#define ATA_R_ERR       1   /* read: error */
#define ATA_R_FEAT      1   /* write: features */
#define ATA_R_COUNT     2
#define ATA_R_LBA0      3
#define ATA_R_LBA1      4
#define ATA_R_LBA2      5
#define ATA_R_DRIVE     6   /* drive/head */
#define ATA_R_STATUS    7   /* read: status */
#define ATA_R_CMD       7   /* write: command */

/* control block */
#define ATA_R_ALTSTATUS 0   /* offset from control base */

#define ATA_SR_ERR  0x01
#define ATA_SR_DRQ  0x08
#define ATA_SR_DF   0x20
#define ATA_SR_DRDY 0x40
#define ATA_SR_BSY  0x80

#define ATA_CMD_READ      0x20
#define ATA_CMD_READ48    0x24
#define ATA_CMD_WRITE     0x30
#define ATA_CMD_WRITE48   0x34
#define ATA_CMD_FLUSH     0xE7
#define ATA_CMD_IDENTIFY  0xEC

static const uint16_t io_base[2]     = { 0x1F0, 0x170 };
static const uint16_t ctrl_base[2]   = { 0x3F6, 0x376 };

ata_disk_t ata_disks[ATA_MAX_DISKS];

static inline void ata_delay(int ch) {
    (void)inb(ctrl_base[ch] + ATA_R_ALTSTATUS);
    (void)inb(ctrl_base[ch] + ATA_R_ALTSTATUS);
    (void)inb(ctrl_base[ch] + ATA_R_ALTSTATUS);
    (void)inb(ctrl_base[ch] + ATA_R_ALTSTATUS);
}

static int poll_bsy_drq(int ch) {
    for (int i = 0; i < 100000; i++) {
        uint8_t st = inb(io_base[ch] + ATA_R_STATUS);
        if (st & ATA_SR_BSY) continue;
        if (st & (ATA_SR_ERR | ATA_SR_DF)) return -1;
        if (st & ATA_SR_DRQ) return 0;
    }
    return -1;
}

static int poll_bsy_clear(int ch) {
    for (int i = 0; i < 100000; i++) {
        uint8_t st = inb(io_base[ch] + ATA_R_STATUS);
        if (!(st & ATA_SR_BSY)) {
            if (st & (ATA_SR_ERR | ATA_SR_DF)) return -1;
            return 0;
        }
    }
    return -1;
}

/* copy an IDENTIFY string field (big-endian word pairs) */
static void ata_string(char *dst, const uint16_t *src, int words) {
    for (int i = 0; i < words; i++) {
        dst[i * 2]     = (char)(src[i] >> 8);
        dst[i * 2 + 1] = (char)(src[i] & 0xFF);
    }
    dst[words * 2] = 0;
    /* trim trailing spaces */
    for (int i = words * 2 - 1; i >= 0 && (dst[i] == ' ' || dst[i] == 0); i--)
        dst[i] = 0;
}

static void ata_identify(int ch, int drv) {
    int idx = ch * 2 + drv;
    ata_disk_t *d = &ata_disks[idx];
    memset(d, 0, sizeof(*d));

    uint16_t base = io_base[ch];

    outb(base + ATA_R_DRIVE, (uint8_t)(0xA0 | (drv << 4)));
    ata_delay(ch);
    outb(base + ATA_R_COUNT, 0);
    outb(base + ATA_R_LBA0, 0);
    outb(base + ATA_R_LBA1, 0);
    outb(base + ATA_R_LBA2, 0);
    outb(base + ATA_R_CMD, ATA_CMD_IDENTIFY);
    ata_delay(ch);

    /* right after a soft reset the bus can read 0 for a while;
       give the device a chance to answer before declaring it absent */
    uint8_t st = inb(base + ATA_R_STATUS);
    for (int t = 0; t < 100000 && st == 0; t++)
        st = inb(base + ATA_R_STATUS);
    if (st == 0) return;                    /* no device (floating bus) */

    if (poll_bsy_clear(ch)) return;

    uint8_t lo = inb(base + ATA_R_LBA0);
    uint8_t hi = inb(base + ATA_R_LBA1);
    if (lo != 0 || hi != 0) return;         /* ATAPI or SATA signature -> skip */

    if (poll_bsy_drq(ch)) return;

    uint16_t id[256];
    insw(base + ATA_R_DATA, id, 256);

    d->present   = 1;
    d->channel   = ch;
    d->drive     = drv;
    d->sectors28 = (uint64_t)id[60] | ((uint64_t)id[61] << 16);
    d->lba48     = (id[83] & (1 << 10)) ? 1 : 0;
    if (d->lba48)
        d->sectors48 = (uint64_t)id[100] | ((uint64_t)id[101] << 16) |
                       ((uint64_t)id[102] << 32) | ((uint64_t)id[103] << 48);
    ata_string(d->serial,   &id[10], 10);
    ata_string(d->firmware, &id[23], 4);
    ata_string(d->model,    &id[27], 20);
    if (d->model[0] == 0) strcpy(d->model, "unknown");
}

void ata_init(void) {
    for (int ch = 0; ch < 2; ch++) {
        /* soft reset the channel */
        outb(ctrl_base[ch], 0x04);            /* control reg: SRST */
        ata_delay(ch);
        outb(ctrl_base[ch], 0x00);
        /* wait for BSY to drop after reset (devices need a moment) */
        for (int t = 0; t < 300000; t++) {
            if (!(inb(ctrl_base[ch] + ATA_R_ALTSTATUS) & ATA_SR_BSY)) break;
        }
        ata_identify(ch, 0);
        ata_identify(ch, 1);
    }
}

int ata_count(void) {
    int n = 0;
    for (int i = 0; i < ATA_MAX_DISKS; i++)
        if (ata_disks[i].present) n++;
    return n;
}

uint64_t ata_disk_size(const ata_disk_t *d) {
    return d->sectors48 ? d->sectors48 : d->sectors28;
}

static void select_lba(int ch, int drv, uint64_t lba, uint32_t count, uint8_t cmd28, uint8_t cmd48) {
    uint16_t base = io_base[ch];
    int use48 = (lba + count > 0x0FFFFFFFULL) || (count > 256);

    if (use48) {
        outb(base + ATA_R_DRIVE, (uint8_t)(0x40 | (drv << 4)));
        outb(base + ATA_R_COUNT, (uint8_t)(count >> 8));
        outb(base + ATA_R_LBA0, (uint8_t)(lba >> 24));
        outb(base + ATA_R_LBA1, (uint8_t)(lba >> 32));
        outb(base + ATA_R_LBA2, (uint8_t)(lba >> 40));
        outb(base + ATA_R_COUNT, (uint8_t)(count & 0xFF));
        outb(base + ATA_R_LBA0, (uint8_t)(lba & 0xFF));
        outb(base + ATA_R_LBA1, (uint8_t)((lba >> 8) & 0xFF));
        outb(base + ATA_R_LBA2, (uint8_t)((lba >> 16) & 0xFF));
        outb(base + ATA_R_CMD, cmd48);
    } else {
        outb(base + ATA_R_DRIVE, (uint8_t)(0xE0 | (drv << 4) | ((lba >> 24) & 0x0F)));
        outb(base + ATA_R_COUNT, (uint8_t)count);
        outb(base + ATA_R_LBA0, (uint8_t)(lba & 0xFF));
        outb(base + ATA_R_LBA1, (uint8_t)((lba >> 8) & 0xFF));
        outb(base + ATA_R_LBA2, (uint8_t)((lba >> 16) & 0xFF));
        outb(base + ATA_R_CMD, cmd28);
    }
}

int ata_read_sectors(int disk, uint64_t lba, uint32_t count, void *buf) {
    if (disk < 0 || disk >= ATA_MAX_DISKS || !ata_disks[disk].present) return -1;
    if (count == 0) return 0;
    ata_disk_t *d = &ata_disks[disk];
    if (lba + count > ata_disk_size(d)) return -1;

    uint16_t *out = buf;
    uint32_t done = 0;

    while (done < count) {
        uint32_t chunk = count - done;
        if (chunk > 256) chunk = 256;

        select_lba(d->channel, d->drive, lba + done, chunk,
                   ATA_CMD_READ, ATA_CMD_READ48);

        for (uint32_t s = 0; s < chunk; s++) {
            if (poll_bsy_drq(d->channel)) return -1;
            insw(io_base[d->channel] + ATA_R_DATA, out, 256);
            out += 256;
        }
        done += chunk;
    }
    return 0;
}

int ata_write_sectors(int disk, uint64_t lba, uint32_t count, const void *buf) {
    if (disk < 0 || disk >= ATA_MAX_DISKS || !ata_disks[disk].present) return -1;
    if (count == 0) return 0;
    ata_disk_t *d = &ata_disks[disk];
    if (lba + count > ata_disk_size(d)) return -1;

    const uint16_t *in = buf;
    uint32_t done = 0;

    while (done < count) {
        uint32_t chunk = count - done;
        if (chunk > 256) chunk = 256;

        select_lba(d->channel, d->drive, lba + done, chunk,
                   ATA_CMD_WRITE, ATA_CMD_WRITE48);

        for (uint32_t s = 0; s < chunk; s++) {
            if (poll_bsy_drq(d->channel)) return -1;
            outsw(io_base[d->channel] + ATA_R_DATA, in, 256);
            in += 256;
        }
        done += chunk;
    }
    return ata_flush(disk);
}

int ata_flush(int disk) {
    if (disk < 0 || disk >= ATA_MAX_DISKS || !ata_disks[disk].present) return -1;
    ata_disk_t *d = &ata_disks[disk];
    outb(io_base[d->channel] + ATA_R_DRIVE, (uint8_t)(0xE0 | (d->drive << 4)));
    outb(io_base[d->channel] + ATA_R_CMD, ATA_CMD_FLUSH);
    return poll_bsy_clear(d->channel);
}
