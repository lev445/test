/* =====================================================================
 *  QuarkOS ring-3 process support
 *
 *  Entering user mode: build an iretq frame with RPL=3 selectors and
 *  iretq into it. While the user task runs, hardware interrupts land
 *  on task_kstack (via TSS.RSP0); syscalls/exceptions can abandon the
 *  task by jumping back to the recovery label just after the iretq,
 *  which restores the callee-saved registers of the kernel caller.
 * ===================================================================== */

#include "proc.h"
#include "tss.h"
#include "console.h"

#define USER_DATA_SEL 0x1B   /* GDT user data (0x18) | RPL 3 */
#define USER_CODE_SEL 0x23   /* GDT user code (0x20) | RPL 3 */

static uint8_t task_kstack[16384] __attribute__((aligned(16)));

/* [0] = scratch for the user RSP, [1] = kernel stack top;
   referenced from isr.asm via %gs after SWAPGS */
uint64_t proc_percpu[2] __attribute__((aligned(16)));

/* 0 = legacy QuarkOS flat-binary ABI, 1 = Linux x86_64 ABI */
int proc_abi = 0;

static uint64_t rec_rsp;      /* kernel stack to restore on recover */
static uint64_t rec_rip;      /* recovery label address             */
static uint64_t rec_status;   /* exit status handed back            */

void proc_recover(uint64_t status) {
    rec_status = status;
    asm volatile(
        "sti\n\t"                 /* re-enable IRQs for the shell   */
        "movq %0, %%rsp\n\t"      /* back to the kernel caller stack */
        "jmp *%1\n\t"             /* resume right after the iretq    */
        :: "m"(rec_rsp), "m"(rec_rip)
        : "memory");
    __builtin_unreachable();
}

void proc_user_fault(regs_t *r) {
    uint64_t cr2;
    asm volatile("mov %%cr2, %0" : "=r"(cr2));
    con_set_color(VGA_LIGHT_RED, VGA_BLACK);
    kprintf("\n[proc] user task trapped: exception %lu at rip=0x%lx rsp=0x%lx\n",
            r->vector, r->rip, r->rsp);
    kprintf("[proc] err=0x%lx cr2=0x%lx (%s, %s, %s)\n",
            r->err, cr2,
            (r->err & 1) ? "protection" : "not-present",
            (r->err & 2) ? "write" : "read",
            (r->err & 4) ? "user" : "kernel");
    kprintf("[proc] CPL was 3 -> killing task, returning to kernel\n");
    con_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    proc_recover(0x100 | (r->vector & 0xFF));
}

int proc_run_user(uint64_t entry, uint64_t ustack) {
    tss_set_rsp0((uint64_t)&task_kstack[sizeof(task_kstack)]);
    proc_percpu[1] = (uint64_t)&task_kstack[sizeof(task_kstack)];

    /* normalize GS bases: user GS = 0, kernel GS = percpu
       (a previous task could have died mid-syscall leaving them swapped) */
    asm volatile(
        "wrmsr" :: "c"(0xC0000101), "a"(0), "d"(0));                  /* GS_BASE */
    asm volatile(
        "wrmsr" :: "c"(0xC0000102),
        "a"((uint32_t)(uint64_t)proc_percpu),
        "d"((uint32_t)((uint64_t)proc_percpu >> 32)));                /* KERNEL_GS_BASE */


    uint64_t status;
    asm volatile(
        /* park inputs in scratch regs (safe across the rax dance) */
        "movq %[entry],  %%rdi\n\t"
        "movq %[ustack], %%rsi\n\t"
        /* save callee-saved regs of the kernel caller */
        "pushq %%rbp\n\t"
        "pushq %%rbx\n\t"
        "pushq %%r12\n\t"
        "pushq %%r13\n\t"
        "pushq %%r14\n\t"
        "pushq %%r15\n\t"
        /* remember where to come back if the task dies / exits */
        "movq %%rsp, %[rec_rsp]\n\t"
        "leaq 0f(%%rip), %%rax\n\t"
        "movq %%rax, %[rec_rip]\n\t"
        /* ---- iretq frame into ring 3 ---- */
        "pushq $" "0x1B" "\n\t"   /* SS  = user data | 3  */
        "pushq %%rsi\n\t"         /* RSP = user stack top */
        "pushfq\n\t"
        "popq %%rax\n\t"
        "orq $0x200, %%rax\n\t"   /* force IF=1 in user mode */
        "pushq %%rax\n\t"         /* RFLAGS               */
        "pushq $" "0x23" "\n\t"   /* CS  = user code | 3  */
        "pushq %%rdi\n\t"         /* RIP = entry point    */
        "iretq\n\t"
        /* ---- recovery label: sys_exit / fault killer land here ---- */
        "0:\n\t"
        "movq %[rec_status], %%rax\n\t"
        "popq %%r15\n\t"
        "popq %%r14\n\t"
        "popq %%r13\n\t"
        "popq %%r12\n\t"
        "popq %%rbx\n\t"
        "popq %%rbp\n\t"
        : "=a"(status)
        : [rec_rsp] "m"(rec_rsp),
          [rec_rip] "m"(rec_rip),
          [entry]   "r"(entry),
          [ustack]  "r"(ustack),
          [rec_status] "m"(rec_status)
        : "rdi", "rsi", "memory");

    return (int)status;
}
