#ifndef PROC_H
#define PROC_H

#include <stdint.h>
#include "idt.h"

#define USER_BASE       0x400000ULL   /* flat user image landing zone  */
#define USER_STACK_TOP  0x600000ULL   /* top of the user stack         */
#define USER_MAX_SIZE   0x80000ULL    /* 512 KiB cap for user images   */

/* enter ring 3 at `entry` with user stack `ustack`;
   returns the exit status (low byte = sys_exit code,
   0x100|vector if the task was killed by a CPU exception) */
int  proc_run_user(uint64_t entry, uint64_t ustack);

/* abandon the current user task and resume the kernel right after
   the iretq inside proc_run_user (used by sys_exit and fault killer) */
void proc_recover(uint64_t status);

/* called by the exception dispatcher when CPL was 3 */
void proc_user_fault(regs_t *r);

#endif
